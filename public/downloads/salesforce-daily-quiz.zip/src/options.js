// Salesforce Daily Quiz settings. Six pages in one flat nav, with search. Changes save instantly.
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const send = msg => chrome.runtime.sendMessage(msg).catch(() => null);
  const slug = s => String(s).toLowerCase().replace(/<[^>]+>/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const PRIVACY = (SFDQ_CONFIG.webUrl || '').replace(/\/+$/, '') + '/privacy';
  let WEB = (SFDQ_CONFIG.webUrl || '').replace(/\/+$/, '') + '/';   // web app address for "Link that account"
  SFDQ_API.webUrl().then(u => { WEB = String(u).replace(/\/+$/, '') + '/'; });

  let settings = { ...FQ_DEFAULTS }, prefs = { ...FQ_PREFS }, stats = {}, qstats = {}, starred = new Set();
  // The extension ships no questions, so the topic list is fixed here. Names must match the server's topic names.
  const TOPICS = ['Apex OOP & Platform', 'Apex Testing', 'Apex Triggers', 'Architecture & Design', 'Assignment & Territory', 'Async Apex', 'Custom Metadata & Settings', 'Data Model', 'Deployment & DevOps', 'Exception Handling', 'Experience Cloud', 'Flows', 'Governor Limits', 'Integration', 'JavaScript', 'LWC', 'Order of Execution', 'Platform Events & CDC', 'Reports & Dashboards', 'SOQL & DML', 'Sales & Service Cloud', 'Security & Sharing', 'Validation & Formulas'];
  let frozen = false, pub = {};
  let view = { page: 'account' };
  let lb = null, lbShowCode = false, lbBusy = false, confirmKind = '', indexing = false, dlgKind = '';

  // ---------- tiny component kit ----------
  const row = (label, sub, ctl, o = {}) => `<div class="row${o.rule ? ' rule' : ''}${o.stack ? ' stack' : ''}" id="${o.id || 'r-' + slug(label)}">
      <div class="lbl"><b>${label}</b>${sub ? `<small>${sub}</small>` : ''}</div>${ctl ? `<div class="ctl">${ctl}</div>` : ''}</div>`;
  const seg = (kind, key, items, cur, label, cls = '') => `<div class="seg${cls ? ' ' + cls : ''}" role="radiogroup" aria-label="${esc(label || key)}" data-kind="${kind}" data-key="${key}">${items.map(([v, l]) =>
      `<button type="button" role="radio" data-v="${esc(JSON.stringify(v))}" aria-checked="${JSON.stringify(v) === JSON.stringify(cur)}">${l}</button>`).join('')}</div>`;
  const toggle = (kind, key, on, label) => `<label class="switch"><input type="checkbox" role="switch" aria-label="${esc(label || key)}" data-kind="${kind}" data-key="${key}" ${on ? 'checked' : ''}><i></i></label>`;
  const slider = (kind, key, min, max, step, v, unit = '', label) => `<div class="slider"><input type="range" aria-label="${esc(label || key)}" data-kind="${kind}" data-key="${key}" data-unit="${unit}" min="${min}" max="${max}" step="${step}" value="${v}"><output>${v}${unit}</output></div>`;
  const multi = (kind, key, items, cur) => `<div class="chips" data-kind="${kind}" data-key="${key}">${items.map(([v, l]) =>
      `<button type="button" class="chip" data-v="${esc(JSON.stringify(v))}" aria-pressed="${cur.map(String).includes(String(v))}">${l}</button>`).join('')}</div>`;
  const group = (title, body, note) => `<div class="group"><div class="group-head"><h3>${title}</h3>${note ? `<p>${note}</p>` : ''}</div><div class="card">${body}</div></div>`;
  let topicsOpen = false;
  const topicsRow = (id, key, kind, cur, all, blurb, sel) => {
    const n = cur.length === all.length || !cur.length ? `All ${all.length} topics` : `${cur.length} of ${all.length} topics`;
    return `<div class="row${kind === 'set' ? ' rule' : ''} stack" id="${id}"><div class="lbl"><b>Topics</b><small>${blurb}</small></div>
      <details class="topics" data-tkey="${key}" ${topicsOpen ? 'open' : ''}><summary>${n}</summary>
      <div class="tools"><button class="linkbtn" type="button" data-topics="${key}">Select all</button></div>
      ${multi(kind, key, all.map(t => [t, esc(t)]), cur)}</details></div>`;
  };
  // Advanced settings: one disclosure per page, state remembered per page in localStorage (never required).
  const ADV_KEY = 'sfdq.settingsAdvanced';
  let advOpen = {};
  try { advOpen = JSON.parse(localStorage.getItem(ADV_KEY) || '{}') || {}; } catch (_) { advOpen = {}; }
  const advSave = () => { try { localStorage.setItem(ADV_KEY, JSON.stringify(advOpen)); } catch (_) {} };
  const adv = (page, body, word = 'advanced settings') => `<details class="adv" data-adv="${page}" ${advOpen[page] ? 'open' : ''}><summary><span class="when-closed">Show ${word}</span><span class="when-open">Hide ${word}</span></summary><div class="adv-body">${body}</div></details>`;
  const more = (title, body) => `<details class="more"><summary>${title}</summary><div class="card">${body}</div></details>`;

  // In-page two-step confirm: a trigger button becomes "question + confirm + cancel".
  const CONFIRMS = {
    signout: ['Sign out of this device?', 'Sign out'],
    delete: ['This cannot be undone.', 'Yes, delete everything'],
    clearStars: ['Remove all bookmarks?', 'Yes, remove'],
    resetProgress: ['This cannot be undone.', 'Yes, reset progress'],
    resetAll: ['This erases settings, progress and bookmarks.', 'Yes, reset everything']
  };
  const ask = (kind, label, cls = 'ghost', disabled = false) => confirmKind === kind
    ? `<span class="confirm-text">${CONFIRMS[kind][0]}</span><button class="btn danger" type="button" data-do="${kind}">${CONFIRMS[kind][1]}</button><button class="btn ghost" type="button" data-cancel>Cancel</button>`
    : `<button class="btn ${cls}" type="button" data-ask="${kind}" ${disabled ? 'disabled' : ''}>${label}</button>`;

  // ---------- saving ----------
  let savedTimer = 0;
  function flash(msg = 'Saved', err = false) {
    const el = $('saved'); el.textContent = msg; el.classList.toggle('err', err); el.classList.add('show');
    clearTimeout(savedTimer); savedTimer = setTimeout(() => el.classList.remove('show'), err ? 3200 : 1200);
  }
  async function saveSettings(patch, rerender) {
    const res = await send({ type: 'fq:saveSettings', settings: patch });
    if (res && res.ok) {
      settings = res.settings; pub = { ...pub, ...res };
      flash(res.partial ? 'Saved the parts that are not frozen' : 'Saved');
      paintDerived();
      if (rerender) renderView();
    } else {
      flash((res && res.reason) || 'Could not save', true);
      renderView();
    }
  }
  async function savePrefs(patch) {
    prefs = { ...prefs, ...patch };
    await chrome.storage.local.set({ prefs });
    flash(); paintDerived();
  }
  // Settings whose change alters what else is shown on the page.
  const STRUCTURAL = ['blockerOn', 'scheduleOn', 'sound', 'theme', 'warnAt'];
  const lastSecs = {};
  const saveBy = (kind, key, value) => {
    // Appearance mode is System / Light / Dark; the stored value stays a theme id.
    if (kind === 'pref' && key === 'theme' && ['auto', 'light', 'dark'].includes(value)) value = FQ_theme.themeFor(value, prefs);
    // Question timers: one switch; the seconds picker only exists while it is on.
    if (kind === 'pref' && key === 'practiceTimerOn') { value = value ? lastSecs.practice || 30 : 0; if (!value) lastSecs.practice = prefs.practiceTimer | 0; return savePrefs({ practiceTimer: value }).then(renderView); }
    if (kind === 'set' && key === 'questionTimerOn') { if (!value) lastSecs.unlock = settings.questionTimer | 0; return saveSettings({ questionTimer: value ? lastSecs.unlock || 30 : 0 }, true); }
    // One Lifelines control sets both 50:50 and Swap.
    if (kind === 'set' && key === 'lifelines') return saveSettings({ fiftyCount: value, skipCount: value }, true);
    return saveByRaw(kind, key, value);
  };
  const saveByRaw = (kind, key, value) => kind === 'pref' ? savePrefs({ [key]: value }).then(() => STRUCTURAL.includes(key) && renderView()) : saveSettings({ [key]: value }, STRUCTURAL.includes(key));

  // ---------- pages ----------
  const P = {};
  const liShort = v => esc(String(v || '').replace(/^https?:\/\/(www\.)?/, ''));
  
  // --- daily and account ---
  const sentBody = () => `<p class="dlg-lead">Your name and scores reach the leaderboard only if you join. Nothing else leaves your device.</p><div class="sent-grid">
      <div class="sent-col"><h4>Sent to the leaderboard</h4><ul><li>Your display name</li><li>Your LinkedIn link, only if you add one</li><li>Your daily scores and times</li><li>An anonymous device code (your recovery code)</li></ul></div>
      <div class="sent-col never"><h4>Never sent</h4><ul><li>Your browsing history</li><li>The sites you visit</li><li>Your practice progress and bookmarks. Practice requests send only your filters and a random seed.</li><li>Your settings</li></ul></div></div>`;
  const whatSentRow = () => row('What is sent', 'What the leaderboard receives, and what never leaves your device.', '<button class="btn ghost" type="button" data-dlg="sent">View</button>');
  P.account = () => lb
    ? group('Profile', `
        ${row('Display name', lb.anon ? 'A random name was picked for you. Set your own name and LinkedIn link any time.' : 'Shown on the public leaderboard.', `<input class="text" id="lbName" aria-label="Display name" maxlength="30" autocomplete="off" placeholder="${lb.name ? '' : 'Loading profile'}" value="${esc(lb.name)}">`)}
        ${row('LinkedIn link', 'Optional. Your name links to it. Clear it to remove the link.', `<input class="text" id="lbLinkedin" aria-label="LinkedIn link" maxlength="200" autocomplete="off" placeholder="linkedin.com/in/yourname" value="${liShort(lb.linkedin)}"><button class="btn" type="button" id="lbSave">Save</button>`)}
        <p class="note card-note" id="lbMsg" role="status"></p>`)
      + group('Recovery and reminder', `
        ${row('Recovery code', 'Keep it to sign in on another computer or browser.',
          `<code class="lb-codebox" id="lbCode">${lbShowCode ? esc(lb.code) : /^SFDQ-\w{4}-\w{4}(-\w{4})?$/.test(lb.code) ? 'SFDQ' + lb.code.slice(4).replace(/\w/g, '•') : 'SFDQ-' + '•'.repeat(12)}</code><button class="btn ghost" type="button" id="lbReveal">${lbShowCode ? 'Hide' : 'Show'}</button><button class="btn ghost" type="button" id="lbCopy">Copy</button>`)}
        ${row('Continue on your phone', 'Open today\'s quiz on your phone, already signed in.', '<button class="btn ghost" type="button" id="phoneShow">Show QR code</button>')}
        ${row('Daily reminder', 'Once a day, a small prompt opens with a Play button.', toggle('pref', 'dailyPrompt', prefs.dailyPrompt !== false, 'Daily reminder'))}
        ${whatSentRow()}`)
      + adv('account', group('Sign out and delete', `
        ${row('Sign out', 'Forgets the recovery code on this device. Your scores stay on the board.', ask('signout', 'Sign out'))}
        ${row('Delete my data', 'Removes your name, LinkedIn link and scores from the leaderboard, then signs this device out.', ask('delete', 'Delete my data', 'danger'))}
        <p class="note err card-note" id="lbDeleteMsg" role="alert"></p>`))
    : `<p class="page-note">The daily challenge is ranked, so it needs a name. Practice and the focus timer never need an account.</p>
      <div class="card join" id="r-join">
        <label class="fld"><span>Name</span><input class="text" id="lbName" maxlength="30" autocomplete="off" placeholder="e.g. Raj"></label>
        <details class="li"><summary>Add LinkedIn (optional)</summary><input class="text" id="lbLinkedin" aria-label="LinkedIn link" maxlength="200" autocomplete="off" placeholder="linkedin.com/in/yourname"></details>
        <p class="fine">Your name, optional LinkedIn link and daily scores appear on the public leaderboard. Nothing else leaves your device. <button class="linkbtn" type="button" data-dlg="sent">What is sent</button> <a href="${esc(PRIVACY)}" target="_blank" rel="noopener">Privacy</a></p>
        <div class="join-actions"><button class="btn" type="button" id="lbJoin">Join</button><span class="note err" id="lbMsg" role="alert"></span></div>
        <p class="alt quiet"><button class="linkbtn" type="button" id="lbSkip">Skip and play with a random name</button></p>
        <p class="alt"><button class="linkbtn" type="button" id="lbRestoreToggle" aria-expanded="false" aria-controls="restoreBox">Use a recovery code</button></p>
        <div class="restore" id="restoreBox" hidden><b class="restore-title">Use a recovery code</b><p class="fine">Only needed on a different computer or browser. On the same browser your account is linked automatically.</p><input class="text mono" id="lbRestoreCode" aria-label="Recovery code" autocomplete="off" spellcheck="false" maxlength="64" placeholder="SFDQ-XXXX-XXXX"><button class="btn ghost" type="button" id="lbRestore">Continue</button><span class="note err" id="lbRestoreMsg" role="alert"></span></div>
        <p class="alt quiet"><a href="${esc(WEB)}" target="_blank" rel="noopener">Played on the web already? Link that account.</a></p>
      </div>`;

  // --- practice ---
  // Keeps a value the stored setting already has (an older choice) visible in a fixed list.
  const withCur = (list, cur) => list.includes(cur) || cur == null ? list : [...list, cur].sort((a, b) => a - b);
  const practiceSummary = () => {
    const n = prefs.practiceLength, t = prefs.practiceTopics && prefs.practiceTopics.length && prefs.practiceTopics.length < TOPICS.length ? prefs.practiceTopics.length : 0;
    const d = prefs.practiceDifficulty, sec = prefs.practiceTimer | 0, a = settings.fiftyCount | 0, b = settings.skipCount | 0;
    const life = a === b ? (a ? `${a} lifeline${a === 1 ? '' : 's'} each` : 'no lifelines') : `50:50 x${a}, swap x${b}`;
    return `${n} questions, ${t ? t + (t === 1 ? ' topic' : ' topics') : 'all topics'}, ${d === 'any' ? 'any difficulty' : d + ' only'}, ${sec ? sec + ' s per question' : 'no timer'}, ${life}`;
  };
  P.practice = () => {
    const cur = prefs.practiceTopics && prefs.practiceTopics.length ? prefs.practiceTopics : TOPICS;
    const timer = prefs.practiceTimer | 0, timerOn = timer > 0;
    const a = settings.fiftyCount | 0, b = settings.skipCount | 0, same = a === b;
    const life = withCur([0, 1, 2, 3], same ? a : null).map(x => [x, x === 0 ? 'None' : x]);
    return `<p class="page-note">These rules apply to Practice only. The daily challenge is the same for everyone.</p><div class="summary lead" id="pSummary">${esc(practiceSummary())}</div>`
      + group('What to play', `
        ${topicsRow('r-topics', 'practiceTopics', 'pref', cur, TOPICS, 'Which topics Practice draws from.')}
        ${row('Length', 'Questions in a round.', seg('pref', 'practiceLength', [5, 10, 20, 30, 50].map(n => [n, n]), prefs.practiceLength, 'Length'))}`)
      + group('How hard', `
        ${row('Difficulty', 'Filter questions by level.', seg('pref', 'practiceDifficulty', [['any', 'Any'], ['easy', 'Easy'], ['medium', 'Medium'], ['hard', 'Hard']], prefs.practiceDifficulty, 'Difficulty'))}
        ${row('Question timer', 'Limit the time on each question. Running out counts as wrong.', toggle('pref', 'practiceTimerOn', timerOn, 'Question timer'))}
        ${timerOn || indexing ? row('Seconds per question', '', seg('pref', 'practiceTimer', withCur([15, 30, 60], timer || null).map(s => [s, s + 's']), timer, 'Seconds per question'), { id: 'r-seconds-per-question' }) : ''}
        ${row('Lifelines', same ? 'Per round. Applies to both 50:50 and Swap.' : `Currently 50:50 x${a}, Swap x${b}. Pick a number to set both.`, seg('set', 'lifelines', life, same ? a : null, 'Lifelines per round'), { rule: true })}`)
      + group('Bookmarks', row('Bookmarked questions', starred.size ? `${starred.size} bookmarked.` : 'None yet. Bookmark a question during a round.',
          `<button class="btn ghost" type="button" data-open="starred" ${starred.size ? '' : 'disabled'}>Practise bookmarked</button>${ask('clearStars', 'Clear', 'danger', !starred.size)}`));
  };

  // --- focus timer ---
  let sitesOpen = false;
  P.focus = () => {
    const head = `<div class="card head-card">${row('Focus timer', 'Limit time on social sites and unlock more with a short quiz. Off by default.', toggle('set', 'blockerOn', settings.blockerOn, 'Focus timer'), { id: 'r-focus-timer' })}</div>`;
    if (!settings.blockerOn && !indexing) return head;
    const off = settings.disabledSites;
    const builtins = FQ_SITES.map(s => `<label class="site"><input type="checkbox" data-site="${s.id}" ${off.includes(s.id) ? '' : 'checked'}><span>${s.name}</span></label>`).join('');
    const customs = settings.customSites.map(c => `<div class="item"><span>${esc(c.name)}</span><small>${off.includes(c.id) ? 'paused' : 'tracked'}</small><button class="x" type="button" data-rm-site="${esc(c.id)}" title="Remove" aria-label="Remove ${esc(c.name)}">&times;</button></div>`).join('');
    const allows = settings.allowList.map((p, i) => `<div class="item"><span>${esc(p)}</span><button class="x" type="button" data-rm-allow="${i}" title="Remove" aria-label="Remove ${esc(p)}">&times;</button></div>`).join('');
    const nTracked = FQ_SITES.filter(s => !off.includes(s.id)).length + settings.customSites.filter(c => !off.includes(c.id)).length, nAll = FQ_SITES.length + settings.customSites.length;
    const qt = settings.questionTimer | 0, topics = TOPICS;
    return head
      + group('Time', `
        ${row('Daily limit', 'Time on tracked sites before a quiz.', slider('set', 'limitMinutes', 5, 240, 5, settings.limitMinutes, ' min', 'Daily limit'), { rule: true })}
        ${row('Reward minutes', 'What each passed quiz unlocks.', slider('set', 'rewardMinutes', 5, 240, 5, settings.rewardMinutes, ' min', 'Reward minutes'), { rule: true })}
        <div class="row rule stack sitesrow" id="r-tracked-sites">
          <details class="disc rowlike" ${sitesOpen ? 'open' : ''}><summary><span class="lbl"><b>Tracked sites</b><small>Ticked sites share one timer.</small></span><span class="val">${nTracked} of ${nAll}</span></summary>
            <div class="sites">${builtins}</div>
            <div class="site-add" id="r-add-a-site"><b>Add a site</b><small>Chrome asks permission for that one site.</small>
              <div class="addrow"><input class="text" id="siteInput" aria-label="Site address" placeholder="e.g. netflix.com" autocomplete="off"><button class="btn" type="button" id="siteAdd">Add</button></div>
              ${customs ? `<div class="list">${customs}</div>` : ''}<p class="note" id="siteMsg"></p></div>
          </details></div>`)
      + group('Unlock quiz', `
        ${row('Questions', 'Length of the unlock quiz.', slider('set', 'questionsPerQuiz', 3, 50, 1, settings.questionsPerQuiz, '', 'Questions in the unlock quiz'), { rule: true })}
        ${row('Pass mark', '', slider('set', 'passPercent', 40, 100, 5, settings.passPercent, '%', 'Pass mark'), { rule: true })}
        ${row('Lives', 'On: the quiz ends once passing is no longer possible.', toggle('set', 'livesOn', settings.livesOn, 'Lives'), { rule: true })}
        <div class="summary" id="quizSummary"></div>`)
      + adv('focus', group('Emergency passes', `
        ${row('Passes per week', 'A pass unlocks like a passed quiz. You type a phrase to confirm.', seg('set', 'emergencyPerWeek', [[0, 'None'], [1, '1'], [2, '2'], [3, '3'], [5, '5'], [7, '7']], settings.emergencyPerWeek, 'Emergency passes per week'), { rule: true })}
        <p class="note card-note">If you fail an unlock quiz, the next attempt repeats the same questions until you pass.</p>`)
      + group('Schedule', `
        ${row('Only during set hours', 'Outside these hours nothing counts and nothing locks.', toggle('set', 'scheduleOn', settings.scheduleOn, 'Only during set hours'), { rule: true })}
        ${settings.scheduleOn || indexing ? `
        ${row('Presets', '', `<div class="chips"><button class="chip" type="button" data-preset="work">Work hours</button><button class="chip" type="button" data-preset="study">Evenings</button><button class="chip" type="button" data-preset="school">Weekdays, daytime</button></div>`, { rule: true, id: 'r-schedule-presets' })}
        ${row('Days', '', multi('set', 'scheduleDays', FQ_WEEKDAYS.map((d, i) => [i, d]), settings.scheduleDays), { rule: true })}
        ${row('Hours', 'Overnight windows work, e.g. 21:00 to 02:00.', `<span class="range"><label>From <input type="time" class="text" aria-label="From" data-time="scheduleFrom" value="${settings.scheduleFrom}"></label><label>to <input type="time" class="text" aria-label="To" data-time="scheduleTo" value="${settings.scheduleTo}"></label></span>`, { rule: true })}
        <div class="summary" id="schedNow"></div>` : ''}`)
      + group('Allow-list', `
        ${row('Allow-list', 'Pages that never count or lock, like a learning channel. Use * as a wildcard.', `<div class="addrow"><input class="text" id="allowInput" aria-label="Allowed page" placeholder="e.g. youtube.com/@salesforce" autocomplete="off"><button class="btn" type="button" id="allowAdd">Allow</button></div>
           ${allows ? `<div class="list">${allows}</div>` : ''}`, { rule: true, stack: true })}`)
      + group('Unlock quiz options', `
        ${row('Question timer', 'Limit the time on each unlock question. Running out counts as wrong.', toggle('set', 'questionTimerOn', qt > 0, 'Unlock question timer'), { rule: true, id: 'r-unlock-timer' })}
        ${qt > 0 || indexing ? row('Seconds per question', '', seg('set', 'questionTimer', withCur([15, 30, 45, 60, 90], qt || null).map(s => [s, s + 's']), qt, 'Unlock seconds per question'), { rule: true, id: 'r-unlock-seconds' }) : ''}
        ${row('Difficulty', 'Ramp starts easy and climbs. Hard skips the easy ones.', seg('set', 'difficulty', [['ramp', 'Ramp'], ['mixed', 'Mixed'], ['easy', 'Gentle'], ['hard', 'Hard']], settings.difficulty, 'Difficulty'), { rule: true, id: 'r-unlock-difficulty' })}
        ${topicsRow('r-unlock-topics', 'lockTopics', 'set', settings.lockTopics || topics, topics, 'Which topics the unlock quiz draws from.')}`)
      + group('Warnings and reset', `
        ${row('Fresh start every midnight', 'Refill the daily limit at 00:00, even if a quiz is pending.', toggle('set', 'dailyReset', settings.dailyReset, 'Fresh start every midnight'), { rule: true })}
        ${row('Heads-up warnings', 'A small notice before the quiz appears. None turns warnings off.', multi('set', 'warnAt', [[15, '15 min'], [10, '10 min'], [5, '5 min'], [1, '1 min']], settings.warnAt), { rule: true })}
        ${settings.warnAt.length || indexing ? row('Warning position', '', seg('set', 'toastPosition', [['tl', 'Top left'], ['tr', 'Top right'], ['bl', 'Bottom left'], ['br', 'Bottom right']], settings.toastPosition, 'Warning position'), { rule: true }) : ''}
        ${row('Your why', 'Shown when the timer asks for a quiz.', `<textarea class="text prose" data-text="why" aria-label="Your why" maxlength="240" placeholder="e.g. Land a Salesforce architect role by March.">${esc(settings.why)}</textarea>`, { stack: true })}`));
  };

  // --- progress ---
  const FOCUS_ACH = ['first-unlock', 'clutch', 'no-help', 'comeback', 'ten-unlocks'];
  const achList = () => FQ_ACHIEVEMENTS.filter(a => a.id !== 'author' && ((stats.achievements || {})[a.id] || settings.blockerOn || !FOCUS_ACH.includes(a.id)));
  const topicRows = () => {
    const agg = {};
    for (const s of Object.values(qstats || {})) { if (!s || !s.seen || !s.topic) continue; const t = agg[s.topic] = agg[s.topic] || { seen: 0, ok: 0 }; t.seen += s.seen; t.ok += s.correct || 0; }
    return Object.entries(agg).sort((a, b) => a[1].ok / a[1].seen - b[1].ok / b[1].seen || b[1].seen - a[1].seen);
  };
  const barRow = ([t, v]) => `<div class="bar-row"><div class="bar-head"><span>${esc(t)}</span><b>${Math.round(v.ok / v.seen * 100)}%</b></div><div class="bar"><i style="width:${v.ok / v.seen * 100}%"></i></div></div>`;
  P.progress = () => {
    const ds = FQ_dailyStats(stats.daily), xp = stats.xp || 0, lv = FQ_levelOf(xp);
    const acc = stats.answered ? Math.round(stats.correct / stats.answered * 100) + '%' : '–';
    const tiles = [[lv[1], `${xp.toLocaleString()} XP`, ' lv'], [ds.current, 'daily streak'], [acc, 'accuracy'], [ds.best, 'best streak'], [ds.perfect, 'perfect days'], [(stats.answered || 0).toLocaleString(), 'questions answered']]
      .map(([b, s, c]) => `<div class="tile${c || ''}"><b>${esc(b)}</b><span>${s}</span></div>`).join('');
    const week = []; for (let i = 6; i >= 0; i--) { const t = Date.now() - i * 864e5, k = FQ_utcDay(t), r = (stats.daily || {})[k]; week.push({ k, r, name: new Date(k + 'T12:00:00Z').toLocaleDateString([], { weekday: 'short', timeZone: 'UTC' }) }); }
    const strip = `<div class="week" role="list">${week.map(d => `<div class="day${d.r ? (d.r.score === d.r.total ? ' perfect' : ' played') : ''}" role="listitem" aria-label="${d.name}: ${d.r ? d.r.score + ' of ' + d.r.total : 'not played'}"><span>${d.name}</span><b>${d.r ? `${d.r.score}/${d.r.total}` : '–'}</b></div>`).join('')}</div>`;
    const rows = topicRows(), got = stats.achievements || {}, ach = achList();
    const earned = ach.filter(a => got[a.id]).sort((x, y) => got[y.id] - got[x.id]);
    const SHOW = 10;
    const chips = earned.slice(0, SHOW).map(a => `<span class="tag" title="${esc(a.desc)}">${esc(a.name)}</span>`).join('') + (earned.length > SHOW ? `<span class="tag more-tag">+${earned.length - SHOW} more</span>` : '');
    return `<div class="tiles" id="r-stats">${tiles}</div>`
      + group('This week', strip, 'Daily challenge results, UTC days.')
      + `<div class="duo">
        <div class="group" id="r-weakest-topics"><div class="group-head"><h3>Weakest topics</h3><button class="linkbtn" type="button" data-dlg="topics" ${rows.length ? '' : 'disabled'}>All topics</button></div>
          <div class="card pad">${rows.length ? `<div class="bars">${rows.slice(0, 5).map(barRow).join('')}</div>` : '<p class="note">Answer a few questions to see this.</p>'}</div></div>
        <div class="group" id="r-achievements"><div class="group-head"><h3>Achievements</h3><button class="linkbtn" type="button" data-dlg="ach">View all</button></div>
          <div class="card pad"><p class="ach-count"><b>${earned.length}</b> of ${ach.length} earned</p>${earned.length ? `<div class="tags">${chips}</div>` : '<p class="note">Nothing earned yet. Play a round to get started.</p>'}</div></div></div>`;
  };
  const topicsDlg = () => ({ title: 'All topics', body: `<p class="dlg-lead">Weakest first. Based on the questions you answered.</p><div class="bars one">${topicRows().map(barRow).join('')}</div>` });
  const achDlg = () => {
    const got = stats.achievements || {}, ach = achList();
    const order = [...ach.filter(a => got[a.id]).sort((x, y) => got[y.id] - got[x.id]), ...ach.filter(a => !got[a.id])];
    return { title: `Achievements, ${ach.filter(a => got[a.id]).length} of ${ach.length} earned`, body: `<ul class="ach-grid">${order.map(a => `<li class="${got[a.id] ? 'got' : 'locked'}"><b>${esc(a.name)}</b><span>${esc(a.desc)}</span><time>${got[a.id] ? esc(new Date(got[a.id]).toLocaleDateString()) : 'Locked'}</time></li>`).join('')}</ul>` };
  };
  const DLG = { sent: () => ({ title: 'What is sent', body: sentBody() }), topics: topicsDlg, ach: achDlg };


  // --- appearance ---
  P.appearance = () => {
    const cur = prefs.theme || 'auto';
    const themes = FQ_THEMES.map(t => `<button class="theme" type="button" data-theme="${t.id}" aria-pressed="${cur === t.id}">
        <div class="pv" style="background:${t.bg}"><i class="l1" style="background:${t.text}"></i><i class="l2" style="background:${t.text3}"></i><span class="pill" style="background:${t.accent}"></span></div>
        <div class="nm">${t.name} <small>${t.dark ? 'dark' : 'light'}</small></div></button>`).join('');
    const ACC = ['#4c8dff', '#0176d3', '#2bb3a3', '#3ecf8e', '#e9b44c', '#f07f4f', '#f0616d', '#a78bfa', '#18181b'];
    return group('Theme', `
        ${row('Mode', 'System follows your device.', seg('pref', 'theme', FQ_theme.MODES, FQ_theme.modeOf(prefs), 'Mode', 'mode-pill'))}
        <div class="themes" id="r-themes">${themes}</div>`)
      + group('Accent', `
        ${row('Accent', 'Buttons, progress and highlights.', `<div class="accents"><button class="chip" type="button" data-accent="" aria-pressed="${!prefs.accent}">Theme default</button>
          ${ACC.map(c => `<button class="dot" type="button" data-accent="${c}" style="--c:${c}" aria-label="Accent ${c}" aria-pressed="${prefs.accent === c}"></button>`).join('')}
          <input type="color" id="accentPick" value="${prefs.accent || '#4c8dff'}" title="Any colour" aria-label="Pick any accent colour"></div>`, { stack: true })}`)
      + adv('appearance', group('Look', `
        ${row('Font', '', seg('pref', 'font', [['theme', 'Default'], ['system', 'Inter / System'], ['serif', 'Serif'], ['mono', 'Mono'], ['readable', 'Readable']], prefs.font || 'theme', 'Font'))}
        ${row('Text size', 'Scales the quiz and this page.', slider('pref', 'scale', 85, 130, 5, prefs.scale || 100, '%', 'Text size'))}
        ${row('Corners', '', seg('pref', 'radius', [['sharp', 'Sharp'], ['round', 'Rounded'], ['pill', 'Soft']], prefs.radius || 'round', 'Corners'))}`)
      + group('Sound and motion', `
        ${row('Sound effects', '', toggle('pref', 'sound', prefs.sound !== false, 'Sound effects'))}
        ${prefs.sound !== false ? row('Volume', '', slider('pref', 'volume', 0, 100, 5, prefs.volume ?? 70, '%', 'Volume') + '<button class="btn ghost" type="button" id="testSound">Play sample</button>') : ''}
        ${row('Motion', 'Calm is subtle. Off removes all animation.', seg('pref', 'motion', [['full', 'Full'], ['calm', 'Calm'], ['off', 'Off']], prefs.motion || 'calm', 'Motion'))}
        ${row('Confetti', 'A small burst when you pass.', toggle('pref', 'confetti', prefs.confetti === true, 'Confetti'))}`));
  };

  // --- data ---
  P.data = () => group('Backup', `
        ${row('Export backup', 'Settings, appearance, progress and bookmarks, in one file.', '<button class="btn" type="button" id="exportAll">Export backup</button>')}
        ${row('Restore backup', 'Replaces your settings, progress and bookmarks with the file.', '<button class="btn ghost" type="button" id="importAll">Choose file</button>')}`, 'Everything is stored only in this browser.')
    + adv('data', group('Reset', `
        ${row('Reset progress', 'Clears XP, stats, achievements and bookmarks. Keeps settings.', ask('resetProgress', 'Reset progress', 'danger'))}
        ${row('Reset everything', 'Returns to a fresh install.', ask('resetAll', 'Reset everything', 'danger'))}`, 'These cannot be undone. Export a backup first.'));

  const PAGES = [
    { id: 'account', t: 'Daily and account', d: '' },
    { id: 'practice', t: 'Practice', d: '' },
    { id: 'focus', t: 'Focus timer', d: '' },
    { id: 'progress', t: 'Progress', d: 'Streaks, accuracy and achievements.' },
    { id: 'appearance', t: 'Appearance', d: 'Theme, text, sound and motion.' },
    { id: 'data', t: 'Data', d: 'Back up, restore or reset.' }
  ];
  // Old anchors (v2 and v3 pages) still land somewhere sensible.
  const LEGACY = { overview: 'account', leaderboard: 'account', profile: 'account', you: 'account', quiz: 'focus', bank: 'practice', library: 'practice', look: 'appearance',
    time: 'focus', sites: 'focus', schedule: 'focus', limits: 'focus', about: 'data' };

  // ---------- rendering ----------
  let lastPage = '';
  const focusKey = el => el && el !== document.body && el.closest('#view') ? { id: el.id, key: (el.closest('[data-key]') || {}).dataset?.key, v: el.dataset.v, theme: el.dataset.theme, accent: el.dataset.accent, ask: el.dataset.ask, site: el.dataset.site, open: el.dataset.open } : null;
  function restoreFocus(k) {
    if (!k) return;
    const all = [...$('view').querySelectorAll('button, input, textarea, summary')];
    const hit = all.find(e => (k.id && e.id === k.id) || (k.key && k.v !== undefined && e.dataset.v === k.v && (e.closest('[data-key]') || {}).dataset?.key === k.key) || (k.key && k.v === undefined && !k.id && e.dataset.key === k.key && e.type === 'checkbox')
      || (k.theme && e.dataset.theme === k.theme) || (k.accent !== undefined && k.accent !== null && e.dataset.accent === k.accent) || (k.ask && e.dataset.ask === k.ask) || (k.site && e.dataset.site === k.site));
    if (hit) hit.focus({ preventScroll: true });
  }
  function renderView(scrollTo) {
    const page = PAGES.find(p => p.id === view.page) || PAGES[0];
    const fk = focusKey(document.activeElement), sy = window.scrollY, changed = lastPage !== page.id;
    if (changed) confirmKind = '';
    $('view').innerHTML = `<header class="page-head"><h2>${page.t}</h2>${page.d ? `<p>${page.d}</p>` : ''}</header>${P[page.id]()}`;
    $('view').classList.toggle('frozen', frozen);
    document.querySelectorAll('[data-nav]').forEach(a => { a.classList.toggle('on', a.dataset.nav === page.id); if (a.dataset.nav === page.id) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    $('lockbar').hidden = !frozen;
    $('rank').textContent = FQ_levelOf(stats.xp || 0)[1];
    const h = '#' + page.id;
    if (location.hash !== h) history[pushNext ? 'pushState' : 'replaceState'](null, '', h);
    pushNext = false; lastPage = page.id;
    paintDerived();
    if (scrollTo) {
      const el = document.getElementById(scrollTo);
      if (el) { for (let d = el.closest('details'); d; d = d.parentElement && d.parentElement.closest('details')) d.open = true; el.scrollIntoView({ block: 'center' }); el.classList.add('hit'); setTimeout(() => el.classList.remove('hit'), 1600); }
    } else if (changed) window.scrollTo(0, 0); else window.scrollTo(0, sy);
    restoreFocus(fk);
  }
  let pushNext = false;
  const navigate = (page, scrollTo) => { view = { page }; pushNext = true; renderView(scrollTo); };

  function paintDerived() {
    const qs = $('quizSummary');
    if (qs) {
      const n = settings.questionsPerQuiz, need = Math.ceil(n * settings.passPercent / 100);
      qs.innerHTML = `Score <b>${need} of ${n}</b> to pass. ${settings.livesOn ? `You can miss ${n - need}, so you get <b>${n - need + 1}</b> lives.` : 'Without lives, every question is answered.'}`;
    }
    const ps = $('pSummary'); if (ps) ps.textContent = practiceSummary();
    const sn = $('schedNow');
    if (sn) sn.innerHTML = FQ_inSchedule(settings) ? 'Right now: <b>active</b>. Time on tracked sites counts.' : 'Right now: <b>outside your hours</b>. Nothing counts.';
  }

  // ---------- search ----------
  // Indexes setting labels and descriptions only. Question text is never part of the page, so it is never indexed.
  function searchIndex() {
    const out = [], tmp = document.createElement('div');
    indexing = true;
    const saveLb = lb;
    try {
      for (const p of PAGES) {
        try { tmp.innerHTML = P[p.id](); } catch (_) { continue; }
        tmp.querySelectorAll('.row').forEach(r => {
          const b = r.querySelector('.lbl b'); if (!b) return;
          out.push({ page: p.id, id: r.id, label: b.textContent.trim(), sub: (r.querySelector('.lbl small') || {}).textContent || '', where: p.t + (r.closest('.adv') ? ', advanced' : '') });
        });
      }
    } finally { indexing = false; lb = saveLb; }
    out.push({ page: 'progress', id: 'r-stats', label: 'Stats, daily streak and accuracy', sub: 'Level, XP, best streak, perfect days, questions answered, this week.', where: 'Progress' });
    out.push({ page: 'progress', id: 'r-weakest-topics', label: 'Weakest topics', sub: 'Topic accuracy, weakest first.', where: 'Progress' });
    out.push({ page: 'progress', id: 'r-achievements', label: 'Achievements', sub: 'Earned and locked achievements.', where: 'Progress' });
    out.push({ page: 'focus', id: 'r-tracked-sites', label: 'Add a site', sub: 'Track another website. Chrome asks permission for that one site.', where: 'Focus timer' });
    if (!lb) out.push({ page: 'account', id: 'r-join', label: 'What is sent', sub: 'What the leaderboard receives, and what never leaves your device.', where: 'Daily and account' });
    if (!lb) out.push({ page: 'account', id: 'r-join', label: 'Join or use a recovery code', sub: 'Join the leaderboard, or sign in with a recovery code on another computer or browser.', where: 'Daily and account' });
    return out;
  }
  function runSearch(q) {
    const box = $('searchResults');
    q = q.trim().toLowerCase();
    if (!q) { box.hidden = true; box.innerHTML = ''; return; }
    const hits = searchIndex().filter(x => (x.label + ' ' + x.sub + ' ' + x.where).toLowerCase().includes(q)).slice(0, 8);
    box.hidden = false;
    box.innerHTML = hits.length ? hits.map(h => `<button type="button" class="hit-item" data-hit="${h.page}|${h.id}"><b>${esc(h.label)}</b><span>${esc(h.where)}</span></button>`).join('') : '<p class="note">No matching settings.</p>';
  }

  // ---------- files ----------
  function download(name, text, type = 'application/json') {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function pickFile(accept, cb) {
    const inp = $('fileInput'); inp.accept = accept; inp.value = '';
    inp.onchange = async () => { const f = inp.files[0]; if (f) cb(await f.text(), f.name); };
    inp.click();
  }

  // ---------- confirmed actions ----------
  const ACTIONS = {
    signout: async () => { lbShowCode = false; await SFDQ_API.clearIdentity(); lb = null; flash('Signed out of this device'); },
    delete: async () => {
      if (lbBusy) return; lbBusy = true;
      try { await SFDQ_API.deleteMe(); lb = null; lbShowCode = false; flash('Your leaderboard data was deleted'); }
      catch (e) { confirmKind = ''; renderView(); setMsg('lbDeleteMsg', e.message); lbBusy = false; return 'kept'; }
      lbBusy = false;
    },
    clearStars: async () => { starred = new Set(); await chrome.storage.local.set({ starred: [] }); flash('Bookmarks cleared'); },
    resetProgress: async () => { const r = await send({ type: 'fq:reset', scope: 'progress' }); if (r && r.ok) { flash('Progress reset'); await loadAll(); return 'loaded'; } flash((r && r.reason) || 'Could not reset', true); },
    resetAll: async () => { const r = await send({ type: 'fq:reset', scope: 'all' }); if (r && r.ok) { flash('Everything reset'); await loadAll(); return 'loaded'; } flash((r && r.reason) || 'Could not reset', true); }
  };

  // ---------- dialogs ----------
  // One native <dialog>: focus is trapped, Escape closes, and focus returns to the button that opened it.
  function openDlg(kind, opener) {
    const d = $('dlg'), c = DLG[kind]; if (!c) return;
    const { title, body } = c();
    $('dlgTitle').textContent = title; $('dlgBody').innerHTML = body; $('dlgBody').scrollTop = 0;
    dlgKind = kind; d.dataset.kind = kind;
    if (!d.open) d.showModal();
  }
  $('dlg').addEventListener('close', () => {
    const b = document.querySelector(`[data-dlg="${dlgKind}"]`); if (b && !b.disabled) b.focus({ preventScroll: true });
  });

  // ---------- events ----------
  document.addEventListener('click', async e => {
    const t = e.target;
    const dl = t.closest('[data-dlg]');
    if (dl) return openDlg(dl.dataset.dlg, dl);
    if (t.id === 'dlgClose') return $('dlg').close();
    if (t === $('dlg')) return $('dlg').close();   // backdrop click: the dialog box itself fills its card, so only the backdrop hits it
    const navA = t.closest('[data-nav]');
    if (navA) { e.preventDefault(); return navigate(navA.dataset.nav); }
    const hit = t.closest('[data-hit]');
    if (hit) { const [p, id] = hit.dataset.hit.split('|'); $('search').value = ''; runSearch(''); return navigate(p, id); }
    const askBtn = t.closest('[data-ask]');
    if (askBtn) { confirmKind = askBtn.dataset.ask; renderView(); const c = $('view').querySelector('[data-cancel]'); if (c) c.focus(); return; }
    if (t.closest('[data-cancel]')) { const k = confirmKind; confirmKind = ''; renderView(); const b = $('view').querySelector(`[data-ask="${k}"]`); if (b) b.focus(); return; }
    const doBtn = t.closest('[data-do]');
    if (doBtn) {
      const k = doBtn.dataset.do; confirmKind = '';
      const r = await ACTIONS[k]();
      if (r !== 'kept' && r !== 'loaded') renderView();
      return;
    }
    const on = t.closest('[data-set-on]');
    if (on) return saveSettings({ [on.dataset.setOn]: true }, true);
    const segBtn = t.closest('.seg button');
    if (segBtn) {
      const g = segBtn.parentElement;
      g.querySelectorAll('button').forEach(b => b.setAttribute('aria-checked', b === segBtn));
      return saveBy(g.dataset.kind, g.dataset.key, JSON.parse(segBtn.dataset.v));
    }
    const chipBtn = t.closest('.chips[data-key] .chip');
    if (chipBtn) {
      const g = chipBtn.parentElement, key = g.dataset.key, isPref = g.dataset.kind === 'pref';
      chipBtn.setAttribute('aria-pressed', chipBtn.getAttribute('aria-pressed') !== 'true');
      const vals = [...g.querySelectorAll('.chip[aria-pressed="true"]')].map(b => JSON.parse(b.dataset.v));
      const topicKey = key === 'lockTopics' || key === 'practiceTopics';
      if (topicKey && !vals.length) { chipBtn.setAttribute('aria-pressed', 'true'); return flash('Keep at least one topic', true); }
      const val = topicKey && vals.length === g.querySelectorAll('.chip').length ? null : vals;
      const sum = g.closest('details.topics') && g.closest('details.topics').querySelector('summary');
      if (sum) sum.textContent = val === null ? `All ${vals.length} topics` : `${vals.length} of ${g.querySelectorAll('.chip').length} topics`;
      return isPref ? savePrefs({ [key]: val }) : saveSettings({ [key]: val }, key === 'warnAt');
    }
    const th = t.closest('.theme');
    if (th) { await savePrefs({ theme: th.dataset.theme }); return renderView(); }
    const acc = t.closest('[data-accent]');
    if (acc) { await savePrefs({ accent: acc.dataset.accent }); return renderView(); }
    const open = t.closest('[data-open]');
    if (open) return send({ type: 'fq:openPractice', query: 'pmode=' + open.dataset.open });
    const rmSite = t.closest('[data-rm-site]');
    if (rmSite) {
      const id = rmSite.dataset.rmSite, c = settings.customSites.find(x => x.id === id);
      await saveSettings({ customSites: settings.customSites.filter(x => x.id !== id), disabledSites: settings.disabledSites.filter(x => x !== id) }, true);
      if (c) chrome.permissions.remove({ origins: c.hosts.flatMap(h => [`*://${h}/*`, `*://*.${h}/*`]) }).catch(() => {});
      return;
    }
    const rmAllow = t.closest('[data-rm-allow]');
    if (rmAllow) return saveSettings({ allowList: settings.allowList.filter((_, i) => i !== +rmAllow.dataset.rmAllow) }, true);
    const preset = t.closest('[data-preset]');
    if (preset) {
      const PR = { work: { scheduleOn: true, scheduleDays: [1, 2, 3, 4, 5], scheduleFrom: '09:00', scheduleTo: '18:00' }, study: { scheduleOn: true, scheduleDays: [0, 1, 2, 3, 4, 5, 6], scheduleFrom: '18:00', scheduleTo: '23:00' },
        school: { scheduleOn: true, scheduleDays: [1, 2, 3, 4, 5], scheduleFrom: '07:00', scheduleTo: '21:00' } }[preset.dataset.preset];
      return saveSettings(PR, true);
    }
    const tp = t.closest('[data-topics]');
    if (tp) {
      const key = tp.dataset.topics;
      return key === 'practiceTopics' ? savePrefs({ practiceTopics: null }).then(renderView) : saveSettings({ [key]: null }, true);
    }

    switch (t.id) {
      case 'siteAdd': return addSite();
      case 'allowAdd': return addAllow();
      case 'testSound': return testSound();
      case 'exportAll': { const b = await send({ type: 'fq:export' }); return download(`salesforce-daily-quiz-backup-${FQ_dayKey()}.json`, JSON.stringify(b, null, 2)); }
      case 'importAll': return pickFile('.json', async text => {
        let b; try { b = JSON.parse(text); } catch (_) { return flash('That file is not valid JSON', true); }
        const r = await send({ type: 'fq:import', backup: b });
        if (r && r.ok) { flash('Backup restored'); await loadAll(); } else flash((r && r.reason) || 'Restore failed', true);
      });
      case 'lbJoin': return lbJoin(false);
      case 'lbSkip': return lbJoin(true);
      case 'lbSave': return lbSave();
      case 'lbRestore': return lbRestore();
      case 'lbRestoreToggle': { const b = $('restoreBox'); b.hidden = !b.hidden; t.setAttribute('aria-expanded', String(!b.hidden)); if (!b.hidden) $('lbRestoreCode').focus(); return; }
      case 'lbReveal': lbShowCode = !lbShowCode; return renderView();
      case 'phoneShow': return SFDQ_PHONE.open(t);
      case 'lbCopy': try { await navigator.clipboard.writeText(lb.code); flash('Recovery code copied'); } catch (_) { flash('Could not copy', true); } return;
    }
  });

  document.addEventListener('toggle', e => {
    const t = e.target;
    if (!t.matches) return;
    if (t.matches('details.topics')) topicsOpen = t.open;
    if (t.matches('details.disc')) sitesOpen = t.open;
    if (t.matches('details.adv')) { advOpen[t.dataset.adv] = t.open; advSave(); }
  }, true);
  document.addEventListener('change', e => {
    const t = e.target;
    if (t.matches('.switch input')) return saveBy(t.dataset.kind, t.dataset.key, t.checked);
    if (t.matches('input[type="range"]')) return saveBy(t.dataset.kind, t.dataset.key, Number(t.value));
    if (t.matches('[data-site]')) {
      const off = new Set(settings.disabledSites);
      t.checked ? off.delete(t.dataset.site) : off.add(t.dataset.site);
      return saveSettings({ disabledSites: [...off] }, true);
    }
    if (t.matches('[data-time]')) return saveSettings({ [t.dataset.time]: t.value });
    if (t.matches('[data-text]')) return saveSettings({ [t.dataset.text]: t.value.trim() });
    if (t.id === 'accentPick') return savePrefs({ accent: t.value }).then(() => renderView());
  });
  document.addEventListener('input', e => {
    const t = e.target;
    if (t.matches('input[type="range"]')) {
      t.nextElementSibling.textContent = t.value + (t.dataset.unit || '');
      if (t.dataset.key === 'questionsPerQuiz' || t.dataset.key === 'passPercent') { settings = { ...settings, [t.dataset.key]: +t.value }; paintDerived(); }
    }
    if (t.id === 'search') runSearch(t.value);
  });
  document.addEventListener('keydown', e => {
    if (e.key === '/' && !/^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); $('search').focus(); return; }
    if (e.target.id === 'search' && e.key === 'Escape') { e.target.value = ''; runSearch(''); return; }
    if (e.target.id === 'search' && e.key === 'Enter') { const f = document.querySelector('.hit-item'); if (f) f.click(); return; }
    if (e.key !== 'Enter') return;
    if (e.target.id === 'siteInput') addSite();
    if (['lbName', 'lbLinkedin'].includes(e.target.id)) return lb ? lbSave() : lbJoin(false);
    if (e.target.id === 'lbRestoreCode') return lbRestore();
    if (e.target.id === 'allowInput') addAllow();
  });

  // ---------- account actions ----------
  const setMsg = (id, text, cls = 'note err') => { const el = $(id); if (el) { el.textContent = text || ''; el.className = cls; } };
  async function lbJoin(skip) {
    if (lbBusy) return; setMsg('lbMsg', '');
    if (!skip && !$('lbName').value.trim()) { setMsg('lbMsg', 'Enter a display name, or skip and play with a random name.'); $('lbName').focus(); return; }
    lbBusy = true;
    const btn = $('lbJoin'); btn.disabled = true; $('lbSkip').disabled = true;
    try {
      await SFDQ_API.register(skip ? { consent: true } : { name: $('lbName').value, linkedin: $('lbLinkedin').value, consent: true });
      lb = await SFDQ_API.identity(); lbShowCode = false;
      renderView(); flash('Joined');
    } catch (e) { btn.disabled = false; $('lbSkip').disabled = false; setMsg('lbMsg', e.message); }
    lbBusy = false;
  }
  async function lbSave() {
    if (lbBusy) return; lbBusy = true; setMsg('lbMsg', '');
    try {
      await SFDQ_API.updateMe({ name: $('lbName').value, linkedin: $('lbLinkedin').value });
      lb = await SFDQ_API.identity(); renderView(); flash('Profile saved');
    } catch (e) {
      if (e.code === 'unauthorized') setMsg('lbMsg', 'The server does not accept the saved recovery code. Sign out and use a recovery code.');
      else setMsg('lbMsg', e.message);
    }
    lbBusy = false;
  }
  async function lbRestore() {
    if (lbBusy) return; lbBusy = true; setMsg('lbRestoreMsg', '');
    try { await SFDQ_API.restore($('lbRestoreCode').value); lb = await SFDQ_API.identity(); renderView(); flash('Signed in as ' + lb.name); }
    catch (e) { setMsg('lbRestoreMsg', e.message); }
    lbBusy = false;
  }

  function addSite() {
    const inp = $('siteInput'), msg = $('siteMsg');
    const host = FQ_normalizeHost(inp.value);
    msg.className = 'note err';
    if (!host) { msg.textContent = 'That does not look like a website address.'; return; }
    if (FQ_siteForHost(host)) { msg.textContent = `${host} is already built in. Tick it above.`; return; }
    if (settings.customSites.some(c => c.hosts.includes(host))) { msg.textContent = `${host} is already on your list.`; return; }
    // permissions.request must run straight from the click, before any other await.
    chrome.permissions.request({ origins: [`*://${host}/*`, `*://*.${host}/*`] }).then(async granted => {
      if (!granted) { msg.textContent = 'Chrome permission was not granted, so Salesforce Daily Quiz cannot see that site.'; return; }
      await saveSettings({ customSites: settings.customSites.concat({ name: host, emoji: '', hosts: [host] }) }, true);
      const m = $('siteMsg'); if (m) { m.className = 'note ok'; m.textContent = `Now tracking ${host}. Open tabs pick it up right away.`; }
    }).catch(err => { msg.textContent = String(err.message || err); });
  }
  function addAllow() {
    const v = $('allowInput').value.trim();
    if (!v) return;
    if (settings.allowList.includes(v)) return flash('Already allowed', true);
    saveSettings({ allowList: settings.allowList.concat(v) }, true);
  }
  function testSound() {
    if (prefs.sound === false) return flash('Sound is off', true);
    const c = new AudioContext(), vol = (prefs.volume ?? 70) / 100;
    [523, 659, 784, 1047].forEach((f, i) => {
      const o = c.createOscillator(), g = c.createGain();
      o.type = prefs.soundPack === 'retro' ? 'square' : prefs.soundPack === 'soft' ? 'sine' : 'triangle';
      const v = .14 * vol * (prefs.soundPack === 'retro' ? .4 : prefs.soundPack === 'soft' ? .6 : 1);
      o.frequency.value = f * (prefs.soundPack === 'soft' ? .8 : 1);
      g.gain.setValueAtTime(.0001, c.currentTime + i * .09); g.gain.exponentialRampToValueAtTime(Math.max(.0002, v), c.currentTime + i * .09 + .02);
      g.gain.exponentialRampToValueAtTime(.0001, c.currentTime + i * .09 + .35);
      o.connect(g).connect(c.destination); o.start(c.currentTime + i * .09); o.stop(c.currentTime + i * .09 + .4);
    });
  }

  // ---------- readable text on the accent colour ----------
  const lum = hex => { const m = /^#?([0-9a-f]{6})$/i.exec(String(hex).trim()); if (!m) return null; const v = [0, 2, 4].map(i => parseInt(m[1].slice(i, i + 2), 16) / 255).map(c => c <= .03928 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4); return .2126 * v[0] + .7152 * v[1] + .0722 * v[2]; };
  function fixOnAccent() {
    const l = lum(getComputedStyle(document.documentElement).getPropertyValue('--accent'));
    if (l === null) return;
    // White text needs a luminance of 0.183 or less on the accent for 4.5:1; otherwise use near-black.
    document.documentElement.style.setProperty('--on-accent', l <= .183 ? '#ffffff' : '#0b0c0e');
  }

  // ---------- nav ----------
  function buildNav() {
    $('nav').innerHTML = PAGES.map(p => `<a href="#${p.id}" data-nav="${p.id}">${p.t}</a>`).join('');
  }

  // ---------- boot ----------
  async function loadAll() {
    const [st, local] = await Promise.all([send({ type: 'fq:state' }), chrome.storage.local.get(['prefs', 'qstats', 'starred'])]);
    pub = st || {}; settings = { ...FQ_DEFAULTS, ...(pub.settings || {}) }; stats = pub.stats || {};
    prefs = { ...FQ_PREFS, ...(local.prefs || {}) }; qstats = local.qstats || {}; starred = new Set(local.starred || []);
    lb = (await SFDQ_API.identity()) || null;
    // adopt() also swaps a long legacy recovery code for a short one (silent, bounded wait, old code kept on failure).
    if (lb && lb.code) { try { lb = (await Promise.race([SFDQ_API.adopt(), new Promise(r => setTimeout(() => r(lb), 2500))])) || null; } catch (_) {} }
    frozen = !!pub.locked;
    buildNav();
    fromHash();
    renderView(view.target);
  }
  function fromHash() {
    const p = location.hash.slice(1).split('/')[0];
    const id = PAGES.some(x => x.id === p) ? p : LEGACY[p];
    view = { page: id || 'account', target: location.hash.slice(1).split('/')[1] || '' };
  }
  window.addEventListener('hashchange', () => { fromHash(); renderView(view.target); });
  $('search').value = ''; // Chrome restores form fields on reload
  $('homeLink').href = FQ_HOME;
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;
  FQ_theme.boot(fixOnAccent);
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.timer) { const was = frozen; frozen = !!(ch.timer.newValue && ch.timer.newValue.locked); if (was !== frozen) { $('lockbar').hidden = !frozen; $('view').classList.toggle('frozen', frozen); } }
    if (ch.lb) { lb = ch.lb.newValue || null; if (lb && lb.code && !lb.name) SFDQ_API.adopt(); if (view.page === 'account' && !(document.activeElement && document.activeElement.closest('#view input'))) renderView(); }
    if (ch.prefs) { prefs = { ...FQ_PREFS, ...(ch.prefs.newValue || {}) }; if (view.page === 'appearance' && !(document.activeElement && document.activeElement.closest('#view'))) renderView(); }
  });
  loadAll();
})();
