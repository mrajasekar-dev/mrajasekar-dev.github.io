// Salesforce Daily Quiz options. One page at a time, split into short tabs, with search. Changes save instantly.
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rich = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>');
  const send = msg => chrome.runtime.sendMessage(msg).catch(() => null);
  const KEYS = 'ABCDEF';
  const mins = ms => { const m = Math.round(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };
  const slug = s => String(s).toLowerCase().replace(/<[^>]+>/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

  let pub = {}, settings = { ...FQ_DEFAULTS }, prefs = { ...FQ_PREFS }, stats = {}, qstats = {}, starred = new Set();
  let builtin = [], custom = [];
  let frozen = false;
  let libQuery = '', libTopic = '', libLimit = 40;
  let view = { page: 'overview', tab: '' };

  // ---------- tiny component kit ----------
  const row = (label, sub, ctl, o = {}) => `<div class="row${o.rule ? ' rule' : ''}${o.stack ? ' stack' : ''}" id="${o.id || 'r-' + slug(label)}">
      <div class="lbl"><b>${label}</b>${sub ? `<small>${sub}</small>` : ''}</div><div class="ctl">${ctl}</div></div>`;
  const seg = (kind, key, items, cur) => `<div class="seg" role="radiogroup" data-kind="${kind}" data-key="${key}">${items.map(([v, l]) =>
      `<button type="button" role="radio" data-v="${esc(JSON.stringify(v))}" aria-checked="${JSON.stringify(v) === JSON.stringify(cur)}">${l}</button>`).join('')}</div>`;
  const toggle = (kind, key, on) => `<label class="switch"><input type="checkbox" role="switch" data-kind="${kind}" data-key="${key}" ${on ? 'checked' : ''}><i></i></label>`;
  const slider = (kind, key, min, max, step, v, unit = '') => `<div class="slider"><input type="range" data-kind="${kind}" data-key="${key}" data-unit="${unit}" min="${min}" max="${max}" step="${step}" value="${v}"><output>${v}${unit}</output></div>`;
  const multi = (key, items, cur) => `<div class="chips" data-key="${key}">${items.map(([v, l]) =>
      `<button type="button" class="chip" data-v="${esc(JSON.stringify(v))}" aria-pressed="${cur.map(String).includes(String(v))}">${l}</button>`).join('')}</div>`;
  const group = (title, body, note) => `<div class="group"><div class="group-head"><h3>${title}</h3>${note ? `<p>${note}</p>` : ''}</div><div class="card">${body}</div></div>`;
  const more = (title, body) => `<details class="more"><summary>${title}</summary><div class="card">${body}</div></details>`;
  const go = (page, tab, label) => `<button class="btn ghost sm" type="button" data-go="${page}${tab ? '/' + tab : ''}">${label}</button>`;

  // ---------- saving ----------
  let savedTimer = 0;
  function flash(msg = 'Saved', err = false) {
    const el = $('saved'); el.textContent = msg; el.classList.toggle('err', err); el.classList.add('show');
    clearTimeout(savedTimer); savedTimer = setTimeout(() => el.classList.remove('show'), err ? 3200 : 1200);
  }
  async function saveSettings(patch, rerender) {
    const res = await send({ type: 'fq:saveSettings', settings: patch });
    if (res && res.ok) {
      settings = res.settings; pub = { ...pub, ...res };
      flash(res.partial ? 'Saved the parts that are not frozen' : 'Saved');
      paintDerived();
      if (rerender) renderView();
    } else {
      flash((res && res.reason) || 'Could not save', true);
      renderView();
    }
  }
  async function savePrefs(patch) {
    prefs = { ...prefs, ...patch };
    await chrome.storage.local.set({ prefs });
    flash();
  }
  // Settings whose change alters what else is shown on the page.
  const STRUCTURAL = ['blockerOn', 'bankSource', 'livesOn', 'scheduleOn', 'sound'];
  const saveBy = (kind, key, value) => kind === 'pref' ? savePrefs({ [key]: value }).then(() => STRUCTURAL.includes(key) && renderView()) : saveSettings({ [key]: value }, STRUCTURAL.includes(key));

  // ---------- pages ----------
  const onOff = v => v ? '<span class="pill on">On</span>' : '<span class="pill">Off</span>';
  const themeName = () => ((prefs.theme === 'auto' ? FQ_THEME_AUTO : FQ_THEMES.find(t => t.id === prefs.theme)) || FQ_THEMES[0]).name;
  const trackedCount = () => FQ_SITES.filter(s => !settings.disabledSites.includes(s.id)).length + settings.customSites.filter(s => !settings.disabledSites.includes(s.id)).length;

  const P = {};

  P.overview = () => {
    const dk = FQ_dayKey(), done = (stats.daily || {})[dk];
    const need = Math.ceil(settings.questionsPerQuiz * settings.passPercent / 100);
    const cards = [
      { t: 'Daily challenge', s: done ? `Today: ${done.score}/${done.total}. Streak ${FQ_dailyStreak(stats.daily)}.` : `Not played yet today. Streak ${FQ_dailyStreak(stats.daily)}.`,
        a: '<button class="btn sm" type="button" data-open="daily">' + (done ? 'Review' : 'Play now') + '</button>' + go('profile', '', 'Settings') },
      { t: 'Focus timer', s: settings.blockerOn ? `${settings.limitMinutes} min on ${trackedCount()} sites, then a ${settings.questionsPerQuiz}-question quiz.${settings.scheduleOn ? ' On a schedule.' : ''}` : 'Off. Turn it on to pause social media after a time limit until you pass a quiz.',
        a: toggle('set', 'blockerOn', settings.blockerOn) + go('focus', '', 'Configure'), badge: onOff(settings.blockerOn) },
      { t: 'Quiz rules', s: `${settings.questionsPerQuiz} questions, pass at ${need}. ${settings.livesOn ? `${settings.questionsPerQuiz - need + 1} lives.` : 'No lives.'} ${settings.questionTimer ? settings.questionTimer + 's per question.' : 'No timer.'}`, a: go('quiz', '', 'Change') },
      { t: 'Questions', s: `${settings.bankSource === 'custom' ? 'Your questions' : settings.bankSource === 'both' ? 'Built-in and yours' : 'Built-in'}: ${bank().length} questions. ${starred.size} bookmarked.`, a: go('bank', 'import', 'Import') + go('bank', 'library', 'Browse') },
      { t: 'Appearance', s: `${themeName()} theme${prefs.accent ? ', custom accent' : ''}. Sound ${prefs.sound !== false ? 'on' : 'off'}.`, a: go('look', '', 'Change') },
      { t: 'Progress', s: `${FQ_levelOf(stats.xp || 0)[1]}, ${(stats.xp || 0).toLocaleString()} XP. ${stats.answered ? Math.round(stats.correct / stats.answered * 100) + '% accuracy.' : 'No answers yet.'}`, a: go('progress', '', 'View') }
    ];
    return `<div class="ov">${cards.map(c => `<div class="ov-card"><div class="ov-top"><h3>${c.t}</h3>${c.badge || ''}</div><p>${c.s}</p><div class="ov-actions">${c.a}</div></div>`).join('')}</div>`;
  };

  // --- focus timer ---
  const focusOff = () => `<div class="empty-state">
      <h3>The focus timer is off</h3>
      <p>Right now you get the daily challenge and practice, and nothing is ever blocked. Turn the timer on and YouTube and social media share one time allowance. When it runs out, those tabs pause until you pass a short quiz.</p>
      <ul><li>You choose the allowance, the sites and the hours.</li><li>Learning pages can be allowed so they never count.</li><li>Turn it off again at any time, unless a quiz is due.</li></ul>
      <button class="btn" type="button" data-set-on="blockerOn">Turn on the focus timer</button></div>`;
  P.focus = {
    tabs: [['time', 'Time'], ['sites', 'Sites'], ['schedule', 'Schedule'], ['limits', 'When time runs out']],
    head: () => row('Focus timer', 'Pause tracked sites after your allowance, until you pass a quiz.', toggle('set', 'blockerOn', settings.blockerOn)),
    gate: () => settings.blockerOn ? '' : focusOff(),
    time: () => group('Allowance', `
        ${row('Social time before a quiz', 'Counts only while a tracked site is open and you are active.', slider('set', 'limitMinutes', 5, 240, 5, settings.limitMinutes, ' min'), { rule: true })}
        ${row('Time earned per pass', 'What each passed quiz unlocks. Shorter means more frequent quizzes.', slider('set', 'rewardMinutes', 5, 240, 5, settings.rewardMinutes, ' min'), { rule: true })}
        ${row('Fresh start every midnight', 'Refill the allowance at 00:00, even if a quiz is pending.', toggle('set', 'dailyReset', settings.dailyReset), { rule: true })}`),
    sites: () => {
      const builtins = FQ_SITES.map(s => `<label class="site"><input type="checkbox" data-site="${s.id}" ${settings.disabledSites.includes(s.id) ? '' : 'checked'}><span>${s.name}</span></label>`).join('');
      const customs = settings.customSites.map(c => `<div class="item"><span>${esc(c.name)}</span><small>${settings.disabledSites.includes(c.id) ? 'paused' : 'tracked'}</small><button class="x" type="button" data-rm-site="${esc(c.id)}" title="Remove" aria-label="Remove ${esc(c.name)}">✕</button></div>`).join('');
      const allows = settings.allowList.map((p, i) => `<div class="item"><span>${esc(p)}</span><button class="x" type="button" data-rm-allow="${i}" title="Remove" aria-label="Remove ${esc(p)}">✕</button></div>`).join('');
      return group('Tracked sites', `<div class="row rule stack" id="r-tracked-sites"><div class="lbl"><b>Built-in sites</b><small>Ticked sites share one timer.</small></div><div class="sites">${builtins}</div></div>`)
        + group('Your own sites', row('Add a site', 'Netflix, news, shopping. Chrome asks permission for that one site.',
          `<div class="addrow"><input class="text" id="siteInput" placeholder="e.g. netflix.com" autocomplete="off"><button class="btn" type="button" id="siteAdd">Add</button></div>
           <div class="list">${customs || '<p class="note">No custom sites yet.</p>'}</div><p class="note" id="siteMsg"></p>`, { rule: true, stack: true }))
        + group('Always allowed', row('Allowed pages', 'Pages that never count or lock, like a learning channel. Use * as a wildcard.',
          `<div class="addrow"><input class="text" id="allowInput" placeholder="e.g. youtube.com/@salesforce" autocomplete="off"><button class="btn" type="button" id="allowAdd">Allow</button></div>
           <div class="list">${allows || '<p class="note">Nothing allowed yet.</p>'}</div>`, { rule: true, stack: true }));
    },
    schedule: () => group('Active hours', `
        ${row('Only enforce on a schedule', 'Outside these hours nothing counts and nothing locks.', toggle('set', 'scheduleOn', settings.scheduleOn), { rule: true })}
        ${settings.scheduleOn ? `
        ${row('Presets', '', `<div class="chips"><button class="chip" type="button" data-preset="work">Work hours</button><button class="chip" type="button" data-preset="study">Evenings</button><button class="chip" type="button" data-preset="school">Weekdays, daytime</button></div>`, { rule: true })}
        ${row('Days', '', multi('scheduleDays', FQ_WEEKDAYS.map((d, i) => [i, d]), settings.scheduleDays), { rule: true })}
        ${row('Hours', 'Overnight windows work, e.g. 21:00 to 02:00.', `<input type="time" class="text" data-time="scheduleFrom" value="${settings.scheduleFrom}"> <span class="to">to</span> <input type="time" class="text" data-time="scheduleTo" value="${settings.scheduleTo}">`, { rule: true })}` : ''}
        <div class="summary" id="schedNow"></div>`),
    limits: () => group('Warnings', `
        ${row('Heads-up warnings', 'A small notice before the quiz appears.', multi('warnAt', [[15, '15 min'], [10, '10 min'], [5, '5 min'], [1, '1 min']], settings.warnAt), { rule: true })}
        ${row('Warning position', '', seg('set', 'toastPosition', [['tl', 'Top left'], ['tr', 'Top right'], ['bl', 'Bottom left'], ['br', 'Bottom right']], settings.toastPosition), { rule: true })}`)
      + group('Escape hatches', `
        ${row('Emergency passes per week', 'Skip the quiz for a few minutes. You type a phrase to confirm.', seg('set', 'emergencyPerWeek', [[0, 'None'], [1, '1'], [2, '2'], [3, '3'], [5, '5'], [7, '7']], settings.emergencyPerWeek), { rule: true })}
        ${row('Emergency pass length', '', seg('set', 'emergencyMinutes', [[1, '1 min'], [3, '3 min'], [5, '5 min'], [10, '10 min'], [15, '15 min']], settings.emergencyMinutes), { rule: true })}
        ${row('Cooldown after a failed quiz', 'A pause before the next attempt, to discourage guessing.', seg('set', 'retryCooldown', [[0, 'None'], [1, '1 min'], [2, '2 min'], [5, '5 min'], [10, '10 min']], settings.retryCooldown), { rule: true })}`)
  };

  // --- quiz rules ---
  P.quiz = {
    tabs: [['basics', 'Basics'], ['help', 'Lifelines and timer'], ['content', 'Questions shown']],
    intro: 'These rules apply to the focus-timer quiz. Practice rounds let you pick length and topics each time, and the daily challenge is always five questions.',
    basics: () => group('Length and pass mark', `
        ${row('Questions per quiz', '', slider('set', 'questionsPerQuiz', 3, 60, 1, settings.questionsPerQuiz, ''), { rule: true })}
        ${row('Pass mark', '', slider('set', 'passPercent', 40, 100, 5, settings.passPercent, '%'), { rule: true })}
        ${row('Lives', 'On: the round ends once passing is no longer possible. Off: you answer every question.', toggle('set', 'livesOn', settings.livesOn), { rule: true })}
        <div class="summary" id="quizSummary"></div>`),
    help: () => group('Lifelines', `
        ${row('50:50', 'Removes two wrong answers. Halves the points for that question.', seg('set', 'fiftyCount', [0, 1, 2, 3, 5].map(n => [n, n === 0 ? 'None' : n]), settings.fiftyCount), { rule: true })}
        ${row('Swap', 'Replace the current question with another.', seg('set', 'skipCount', [0, 1, 2, 3, 5].map(n => [n, n === 0 ? 'None' : n]), settings.skipCount), { rule: true })}`)
      + group('Timer', row('Time per question', 'Running out counts as wrong. Quick answers earn a 25% bonus.', seg('set', 'questionTimer', [[0, 'Off'], [15, '15s'], [30, '30s'], [45, '45s'], [60, '60s'], [90, '90s']], settings.questionTimer), { rule: true })),
    content: () => {
      const topics = [...new Set(bank().map(q => q.topic))].sort();
      const counts = {}; bank().forEach(q => counts[q.topic] = (counts[q.topic] || 0) + 1);
      return group('Difficulty and feedback', `
          ${row('Difficulty', 'Ramp starts easy and climbs. Hard skips the easy ones.', seg('set', 'difficulty', [['ramp', 'Ramp'], ['mixed', 'Mixed'], ['easy', 'Gentle'], ['hard', 'Hard']], settings.difficulty), { rule: true })}
          ${row('Explanations', 'When to show the reasoning after an answer.', seg('set', 'explanations', [['always', 'Always'], ['wrong', 'When wrong'], ['never', 'Never']], settings.explanations), { rule: true })}`)
        + more('Advanced', `
          ${row('Auto-advance after correct answers', 'Moves on by itself. Wrong answers always wait for you.', toggle('set', 'autoAdvance', settings.autoAdvance), { rule: true })}
          ${row('Shuffle answer order', 'Turn off for banks with "All of the above" options.', toggle('set', 'shuffleOptions', settings.shuffleOptions), { rule: true })}
          <div class="row rule stack" id="r-topics"><div class="lbl"><b>Topics</b><small>Which topics the focus-timer quiz draws from. <button class="linkbtn" type="button" data-topics="all">Select all</button></small></div>
          ${multi('lockTopics', topics.map(t => [t, `${esc(t)}<small>${counts[t]}</small>`]), settings.lockTopics || topics)}</div>`);
    }
  };

  // --- question bank ---
  P.bank = {
    tabs: [['source', 'Source'], ['import', 'Import'], ['library', 'Library']],
    source: () => group('Where questions come from', row('Question source', `Built-in: ${builtin.length} Salesforce scenarios. Yours: ${custom.length}.`, seg('set', 'bankSource', [['builtin', 'Built-in'], ['custom', 'Mine'], ['both', 'Both']], settings.bankSource), { rule: true })
        + row('Your questions', custom.length ? `${custom.length} imported.` : 'None yet.', `<button class="btn ghost" type="button" id="exportMine" ${custom.length ? '' : 'disabled'}>Export</button><button class="btn danger" type="button" id="clearMine" ${custom.length ? '' : 'disabled'}>Delete</button>`, { rule: true })),
    import: () => group('Import questions', `<div class="row rule stack" id="r-import-questions" style="border:0">
          <div class="drop" id="drop" tabindex="0" role="button"><b>Drop a .json or .csv file</b> or click to choose<br><small>Any subject works.</small></div>
          <textarea class="text" id="pasteBox" placeholder='Or paste JSON or CSV here'></textarea>
          <div class="ctl"><button class="btn" type="button" id="importAdd">Add to my questions</button><button class="btn ghost" type="button" id="importReplace">Replace my questions</button></div>
          <p class="note" id="importMsg">Not sure of the format? Start from a template.</p>
          <div class="ctl"><button class="btn ghost sm" type="button" id="tplJson">JSON template</button><button class="btn ghost sm" type="button" id="tplCsv">CSV template</button></div></div>`)
      + more('Format reference', `<div class="fmt"><p><b>JSON:</b> an array of <code>{ q, options, answer, explanation, topic, difficulty, code }</code>. <code>options</code> holds 2 to 6 answers. <code>answer</code> is a 0-based index or a letter. <code>difficulty</code> is easy, medium or hard. Only <code>q</code>, <code>options</code> and <code>answer</code> are required.</p>
          <p><b>CSV:</b> columns <code>question, a, b, c, d, answer, explanation, topic, difficulty</code>, where <code>answer</code> is a letter.</p></div>`),
    library: () => {
      const topics = [...new Set(bank().map(q => q.topic))].sort();
      return `<div class="lib-tools"><input class="text" id="libSearch" placeholder="Search ${bank().length} questions" value="${esc(libQuery)}" autocomplete="off">
          <select class="text" id="libTopic"><option value="">All topics</option>${topics.map(t => `<option ${t === libTopic ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>
        <div class="ctl lib-actions"><button class="btn sm" type="button" data-open="starred">Practise ${starred.size} bookmarked</button><button class="btn ghost sm" type="button" data-open="mistakes">Practise mistakes</button></div>
        <div class="lib" id="lib"></div>`;
    }
  };

  // --- appearance ---
  P.look = {
    tabs: [['theme', 'Theme'], ['text', 'Text and motion'], ['sound', 'Sound']],
    note: 'Appearance can be changed any time, even while a quiz is due.',
    theme: () => {
      const cur = prefs.theme || 'auto';
      const themes = [...FQ_THEMES, FQ_THEME_AUTO].map(t => {
        if (t.id === 'auto') return `<button class="theme" type="button" data-theme="auto" aria-pressed="${cur === 'auto'}">
          <div class="pv" style="background:linear-gradient(135deg,#0e0f11 50%,#f3f4f6 50%)"><i class="l1" style="background:#ececee"></i><i class="l2" style="background:#7c8491"></i><span class="pill" style="background:#4c8dff"></span></div>
          <div class="nm">Auto <small>system</small></div></button>`;
        return `<button class="theme" type="button" data-theme="${t.id}" aria-pressed="${cur === t.id}">
          <div class="pv" style="background:${t.bg}"><i class="l1" style="background:${t.text}"></i><i class="l2" style="background:${t.text3}"></i><span class="pill" style="background:${t.accent}"></span></div>
          <div class="nm">${t.name} <small>${t.dark ? 'dark' : 'light'}</small></div></button>`;
      }).join('');
      const ACC = ['#4c8dff', '#0176d3', '#2bb3a3', '#3ecf8e', '#e9b44c', '#f07f4f', '#f0616d', '#a78bfa', '#18181b'];
      return group('Theme', `<div class="themes">${themes}</div>`)
        + group('Accent colour', row('Accent', 'Buttons, progress and highlights.', `<div class="accents"><button class="chip" type="button" data-accent="" aria-pressed="${!prefs.accent}">Theme default</button>
          ${ACC.map(c => `<button class="dot" type="button" data-accent="${c}" style="background:${c}" aria-label="Accent ${c}" aria-pressed="${prefs.accent === c}"></button>`).join('')}
          <input type="color" id="accentPick" value="${prefs.accent || '#4c8dff'}" title="Any colour" aria-label="Pick any accent colour"></div>`, { stack: true }));
    },
    text: () => group('Text', `
        ${row('Font', '', seg('pref', 'font', [['theme', 'Default'], ['system', 'Inter / System'], ['serif', 'Serif'], ['mono', 'Mono'], ['readable', 'Readable']], prefs.font || 'theme'))}
        ${row('Text size', 'Scales the quiz and this page.', slider('pref', 'scale', 85, 130, 5, prefs.scale || 100, '%'))}`)
      + group('Shape and motion', `
        ${row('Corners', '', seg('pref', 'radius', [['sharp', 'Sharp'], ['round', 'Rounded'], ['pill', 'Soft']], prefs.radius || 'round'))}
        ${row('Motion', 'Calm is subtle. Off removes all animation.', seg('pref', 'motion', [['full', 'Full'], ['calm', 'Calm'], ['off', 'Off']], prefs.motion || 'calm'))}
        ${row('Background', '', seg('pref', 'background', [['plain', 'Plain'], ['grid', 'Grid']], ['plain', 'grid'].includes(prefs.background) ? prefs.background : 'plain'))}
        ${row('Confetti', 'A small burst when you pass.', toggle('pref', 'confetti', prefs.confetti === true))}`),
    sound: () => group('Sound', `
        ${row('Sound effects', '', toggle('pref', 'sound', prefs.sound !== false))}
        ${prefs.sound !== false ? `${row('Style', '', seg('pref', 'soundPack', [['soft', 'Soft'], ['arcade', 'Classic'], ['retro', '8-bit']], prefs.soundPack || 'arcade') + '<button class="btn ghost sm" type="button" id="testSound">Play sample</button>')}
        ${row('Volume', '', slider('pref', 'volume', 0, 100, 5, prefs.volume ?? 70, '%'))}` : ''}`)
  };

  // --- profile ---
  P.profile = () => group('Daily challenge', `
      ${row('Questions per day', 'Five is the standard set everyone plays. Longer sets add more on top.', seg('pref', 'dailyCount', [[5, '5 · Standard'], [10, '10'], [15, '15'], [20, '20']], prefs.dailyCount || 5))}
      ${row('Daily reminder', 'Once a day, the popup opens with your streak and a Play button.', toggle('pref', 'dailyPrompt', prefs.dailyPrompt !== false))}`)
    + group('About you', `
      ${row('Your name', 'Used in greetings and warnings.', `<input class="text" data-text="displayName" maxlength="40" value="${esc(settings.displayName)}" placeholder="e.g. Raj" style="max-width:280px">`)}
      ${row('Your why', 'Shown when the focus timer asks for a quiz.', `<textarea class="text prose" data-text="why" maxlength="240" placeholder="e.g. Land a Salesforce architect role by March.">${esc(settings.why)}</textarea>`, { stack: true })}`)
    + group('Goals', row('Daily question goal', 'Questions to answer each day, across all modes. 0 turns it off.', slider('set', 'dailyGoal', 0, 200, 5, settings.dailyGoal, '')));

  // --- progress ---
  const days30 = () => { const d = []; for (let i = 29; i >= 0; i--) d.push(Date.now() - i * 864e5); return d; };
  const chart = (by, fmt) => {
    const days = days30(), vals = days.map(t => (by || {})[FQ_dayKey(t)] || 0), max = Math.max(...vals, 1);
    return `<div class="chart">${vals.map((v, i) => `<div class="c${i === 29 ? ' t' : ''}" title="${new Date(days[i]).toDateString()}: ${fmt(v)}"><i style="height:${Math.max(2, v / max * 100)}%"></i></div>`).join('')}</div>
      <div class="chart-legend"><span>30 days ago</span><span>Today</span></div>`;
  };
  P.progress = {
    tabs: [['summary', 'Summary'], ['activity', 'Activity'], ['achievements', 'Achievements']],
    summary: () => {
      const acc = stats.answered ? Math.round(stats.correct / stats.answered * 100) + '%' : '—';
      const tiles = [
        [FQ_levelOf(stats.xp || 0)[1], `${(stats.xp || 0).toLocaleString()} XP`], [FQ_dailyStreak(stats.daily), 'daily streak'], [Object.keys(stats.daily || {}).length, 'daily sets played'],
        [(stats.answered || 0).toLocaleString(), 'questions answered'], [acc, 'accuracy'], [stats.bestStreak || 0, 'best answer streak'],
        [stats.quizzesPassed || 0, 'focus quizzes passed'], [stats.quizzesTaken || 0, 'rounds played']
      ].map(([b, s]) => `<div class="tile"><b>${b}</b><span>${s}</span></div>`).join('');
      const topicAgg = {};
      for (const q of bank()) { const s = qstats[q.id]; if (!s) continue; const t = topicAgg[q.topic] = topicAgg[q.topic] || { seen: 0, ok: 0 }; t.seen += s.seen; t.ok += s.correct; }
      const rows = Object.entries(topicAgg).sort((a, b) => a[1].ok / a[1].seen - b[1].ok / b[1].seen);
      return `<div class="tiles">${tiles}</div>` + group('Topic mastery', `<div class="bars">${rows.map(([t, v]) => `<div><div class="bar-head"><span>${esc(t)}</span><b>${Math.round(v.ok / v.seen * 100)}%</b></div><div class="bar"><i style="width:${v.ok / v.seen * 100}%"></i></div></div>`).join('') || '<p class="note">Answer a few questions to see this.</p>'}</div>`, 'Weakest first.');
    },
    activity: () => {
      const names = Object.fromEntries(FQ_SITES.concat(settings.customSites).map(s => [s.id, s.name]));
      const perSite = Object.entries(stats.perSite || {}).sort((a, b) => b[1] - a[1]);
      const siteMax = perSite.length ? perSite[0][1] : 1;
      const hist = (stats.history || []).slice(-12).reverse().map(h => `<tr><td>${new Date(h.at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</td><td>${{ lock: 'Focus quiz', daily: 'Daily', practice: 'Practice' }[h.mode] || h.mode}</td><td>${h.score}/${h.total}</td><td class="${h.passed ? 'pass' : 'failc'}">${h.passed ? 'Pass' : 'Below'}</td></tr>`).join('');
      return group('Questions answered', chart(stats.answeredByDay, v => v + ' questions'), 'Last 30 days.')
        + group('Social time', chart(stats.byDay, mins) + `<div class="bars" style="margin-top:14px">${perSite.map(([id, ms]) => `<div><div class="bar-head"><span>${esc(names[id] || id)}</span><b>${mins(ms)}</b></div><div class="bar"><i style="width:${ms / siteMax * 100}%"></i></div></div>`).join('') || '<p class="note">Tracked only while the focus timer is on.</p>'}</div>`, 'Last 30 days, and totals by site.')
        + group('Recent rounds', hist ? `<table class="hist"><tr><th>When</th><th>Type</th><th>Score</th><th>Result</th></tr>${hist}</table>` : '<p class="note">No rounds yet.</p>');
    },
    achievements: () => {
      const got = stats.achievements || {};
      return group(`${Object.keys(got).length} of ${FQ_ACHIEVEMENTS.length} unlocked`, `<div class="trophies">${FQ_ACHIEVEMENTS.map(a => `<div class="trophy${got[a.id] ? ' got' : ''}"><div><b>${esc(a.name)}</b><small>${esc(a.desc)}${got[a.id] ? `<br>Unlocked ${new Date(got[a.id]).toLocaleDateString()}` : ''}</small></div></div>`).join('')}</div>`);
    }
  };

  // --- data & about ---
  P.data = {
    tabs: [['backup', 'Backup'], ['reset', 'Reset'], ['about', 'About']],
    backup: () => group('Backup', `
        ${row('Export', 'Settings, appearance, progress, bookmarks and your questions, in one file.', '<button class="btn" type="button" id="exportAll">Export backup</button>')}
        ${row('Restore', 'Replaces everything in the file. The current timer is kept.', '<button class="btn ghost" type="button" id="importAll">Choose file</button>', { rule: true })}`, 'Everything is stored only in this browser.'),
    reset: () => group('Reset', `
        ${row('Reset progress', 'Clears XP, stats, achievements and bookmarks. Keeps settings and your questions.', '<button class="btn danger" type="button" id="resetProgress">Reset progress</button>', { rule: true })}
        ${row('Reset everything', 'Returns to a fresh install. Your questions are deleted too.', '<button class="btn danger" type="button" id="resetAll">Reset everything</button>', { rule: true })}`, 'These cannot be undone. Export a backup first.'),
    about: () => group('Salesforce Daily Quiz', `<div class="about-hero"><img src="../icons/sfdq-128.png" alt=""><div><h3>Version ${chrome.runtime.getManifest().version}</h3><p>Made by Rajasekar M. No accounts, servers or tracking.</p></div></div>
        <div class="ctl" style="justify-content:flex-start;padding-bottom:14px"><a class="btn" href="${FQ_HOME}" target="_blank" rel="noopener">Website</a><a class="btn ghost" href="${FQ_PRIVACY}" target="_blank" rel="noopener">Privacy policy</a><button class="btn ghost" type="button" data-open="welcome">Welcome page</button></div>`)
      + group('Keyboard shortcuts', `<div class="keys">
        <span><span class="kbd">Alt</span> <span class="kbd">Shift</span> <span class="kbd">F</span></span><span>Open the popup</span>
        <span><span class="kbd">Alt</span> <span class="kbd">Shift</span> <span class="kbd">P</span></span><span>Start a practice round</span>
        <span><span class="kbd">Alt</span> <span class="kbd">Shift</span> <span class="kbd">O</span></span><span>Open these options</span>
        <span><span class="kbd">A</span>–<span class="kbd">F</span> or <span class="kbd">1</span>–<span class="kbd">6</span></span><span>Answer</span>
        <span><span class="kbd">Enter</span></span><span>Next question</span>
        <span><span class="kbd">F</span> <span class="kbd">W</span> <span class="kbd">B</span> <span class="kbd">M</span></span><span>50:50, swap, bookmark, mute</span>
      </div><div class="ctl" style="justify-content:flex-start;padding-bottom:14px"><button class="btn ghost sm" type="button" id="shortcuts">Change shortcuts in Chrome</button></div>`)
  };

  const PAGES = [
    { id: 'overview', t: 'Overview', g: '', d: 'What is on, at a glance. Each card links to where you change it.' },
    { id: 'focus', t: 'Focus timer', g: 'Behaviour', d: 'Optionally pause social media after a time limit, until you pass a quiz.' },
    { id: 'quiz', t: 'Quiz rules', g: 'Behaviour', d: 'How the focus-timer quiz works.' },
    { id: 'bank', t: 'Questions', g: 'Behaviour', d: 'Built-in Salesforce questions, your own, or both.' },
    { id: 'look', t: 'Appearance', g: 'Personal', d: 'Theme, text and sound.' },
    { id: 'profile', t: 'Daily and goals', g: 'Personal', d: 'Daily challenge length and reminder, your name and your goal.' },
    { id: 'progress', t: 'Progress', g: 'Insights', d: 'Streaks, accuracy and activity.' },
    { id: 'data', t: 'Backup and about', g: 'Data', d: 'Export, restore, reset, and app details.' }
  ];

  // ---------- rendering ----------
  function pageHTML(pageId, tabId) {
    const def = P[pageId];
    if (typeof def === 'function') return { body: def(), tabs: null };
    const tabs = def.tabs, tab = tabs.some(t => t[0] === tabId) ? tabId : tabs[0][0];
    const gate = def.gate ? def.gate() : '';
    const top = (def.head ? `<div class="card head-card">${def.head()}</div>` : '') + (def.intro ? `<p class="page-note">${def.intro}</p>` : '') + (def.note ? `<p class="page-note">${def.note}</p>` : '');
    if (gate) return { body: gate, tabs: null, tab };
    return { body: top + `<div class="subtabs" role="tablist">${tabs.map(([id, t]) => `<button type="button" role="tab" data-tab="${id}" aria-selected="${id === tab}">${t}</button>`).join('')}</div><div class="tabbody">${def[tab]()}</div>`, tabs, tab };
  }

  function renderView(scrollTo) {
    const page = PAGES.find(p => p.id === view.page) || PAGES[0];
    const { body, tab } = pageHTML(page.id, view.tab);
    view.tab = tab || '';
    $('view').innerHTML = `<header class="page-head"><h2>${page.t}</h2><p>${page.d}</p></header>${body}`;
    $('view').classList.toggle('frozen', frozen);
    document.querySelectorAll('[data-nav]').forEach(a => a.classList.toggle('on', a.dataset.nav === page.id));
    $('lockbar').hidden = !frozen;
    $('rank').textContent = FQ_levelOf(stats.xp || 0)[1];
    const h = '#' + page.id + (view.tab ? '/' + view.tab : '');
    if (location.hash !== h) history[pushNext ? 'pushState' : 'replaceState'](null, '', h);
    pushNext = false;
    if ($('lib')) renderLib();
    paintDerived();
    if (scrollTo) {
      const el = document.getElementById(scrollTo);
      if (el) { const d = el.closest('details'); if (d) d.open = true; el.scrollIntoView({ block: 'center' }); el.classList.add('hit'); setTimeout(() => el.classList.remove('hit'), 1600); }
    } else window.scrollTo(0, 0);
  }
  let pushNext = false;
  const navigate = (page, tab, scrollTo) => { view = { page, tab: tab || '' }; pushNext = true; renderView(scrollTo); };
  const renderAll = () => renderView();

  function paintDerived() {
    const qs = $('quizSummary');
    if (qs) {
      const n = settings.questionsPerQuiz, need = Math.ceil(n * settings.passPercent / 100);
      qs.innerHTML = `Score <b>${need} of ${n}</b> to pass. ${settings.livesOn ? `You can miss ${n - need}, so you get <b>${n - need + 1}</b> lives.` : 'Without lives, every question is answered.'}`;
    }
    const sn = $('schedNow');
    if (sn) sn.innerHTML = settings.scheduleOn
      ? (FQ_inSchedule(settings) ? 'Right now: <b>active</b>. Time on tracked sites counts.' : 'Right now: <b>outside your hours</b>. Nothing counts.')
      : 'No schedule. The timer is active at all hours.';
  }

  // ---------- search ----------
  function searchIndex() {
    const out = [], tmp = document.createElement('div');
    for (const p of PAGES) {
      const def = P[p.id];
      const tabs = typeof def === 'function' ? [[null, null]] : def.tabs;
      for (const [tid, tname] of tabs) {
        try { tmp.innerHTML = typeof def === 'function' ? def() : def[tid](); } catch (_) { continue; }
        tmp.querySelectorAll('.row').forEach(r => {
          const b = r.querySelector('.lbl b'); if (!b) return;
          out.push({ page: p.id, tab: tid, id: r.id, label: b.textContent.trim(), sub: (r.querySelector('.lbl small') || {}).textContent || '', where: p.t + (tname ? ' › ' + tname : '') });
        });
        if (!tmp.querySelector('.row')) out.push({ page: p.id, tab: tid, id: '', label: tname || p.t, sub: p.d, where: p.t });
      }
    }
    return out;
  }
  function runSearch(q) {
    const box = $('searchResults');
    q = q.trim().toLowerCase();
    if (!q) { box.hidden = true; box.innerHTML = ''; return; }
    const hits = searchIndex().filter(x => (x.label + ' ' + x.sub + ' ' + x.where).toLowerCase().includes(q)).slice(0, 8);
    box.hidden = false;
    box.innerHTML = hits.length ? hits.map(h => `<button type="button" class="hit-item" data-hit="${h.page}|${h.tab || ''}|${h.id}"><b>${esc(h.label)}</b><span>${esc(h.where)}</span></button>`).join('') : '<p class="note">No matching settings.</p>';
  }

  function renderLib() {
    const box = $('lib'); if (!box) return;
    const q = libQuery.trim().toLowerCase();
    const list = bank().filter(x => (!libTopic || x.topic === libTopic) && (!q || (x.q + ' ' + x.options.join(' ') + ' ' + (x.explanation || '')).toLowerCase().includes(q)));
    box.innerHTML = list.slice(0, libLimit).map(x => {
      const s = qstats[x.id];
      return `<details class="lq"><summary><button class="st" type="button" data-star="${esc(x.id)}" aria-pressed="${starred.has(x.id)}" title="Bookmark">${starred.has(x.id) ? '★' : '☆'}</button><span class="t">${rich(x.q)}</span><span class="tag">${esc(x.topic)}</span></summary>
        <div class="body"><ol type="A">${x.options.map((o, i) => `<li class="${i === x.answer ? 'ok' : ''}">${rich(o)}</li>`).join('')}</ol>${x.explanation ? `<p>${rich(x.explanation)}</p>` : ''}
        <p class="note">${x.difficulty} · ${s ? `seen ${s.seen} times, right ${s.correct}` : 'not seen yet'}</p></div></details>`;
    }).join('') + (list.length > libLimit ? `<button class="btn ghost" type="button" id="libMore">Show more (${list.length - libLimit} left)</button>` : '') || '<p class="note">No questions match.</p>';
  }

  // ---------- data ----------
  const bank = () => settings.bankSource === 'custom' && custom.length ? custom : settings.bankSource === 'both' ? builtin.concat(custom) : builtin;

  function normalize(q, i) {
    if (!q || typeof q !== 'object') return { err: 'not an object' };
    const text = q.q || q.question;
    let options = Array.isArray(q.options) ? q.options : ['a', 'b', 'c', 'd', 'e', 'f'].map(k => q[k] ?? q['option ' + k] ?? q['option' + k.toUpperCase()]).filter(v => v !== undefined && v !== '');
    options = options.map(String).filter(o => o.trim()).slice(0, 6);
    let ans = q.answer ?? q.correct;
    if (typeof ans === 'string' && /^[A-Fa-f]$/.test(ans.trim())) ans = KEYS.indexOf(ans.trim().toUpperCase());
    else if (typeof ans === 'string' && /^\d+$/.test(ans.trim())) ans = Number(ans) - (q.__csv ? 1 : 0);
    else if (typeof ans === 'string') ans = options.findIndex(o => o.trim().toLowerCase() === ans.trim().toLowerCase());
    ans = Number(ans);
    if (!text) return { err: 'missing question text' };
    if (options.length < 2) return { err: 'needs at least 2 options' };
    if (!(ans >= 0 && ans < options.length)) return { err: 'answer does not point at an option' };
    const diff = String(q.difficulty || 'medium').toLowerCase();
    return { q: {
      id: 'u-' + Date.now().toString(36) + '-' + i, topic: String(q.topic || 'My questions').slice(0, 60),
      difficulty: ['easy', 'medium', 'hard'].includes(diff) ? diff : 'medium', q: String(text), code: q.code ? String(q.code) : undefined,
      options, answer: ans, explanation: q.explanation ? String(q.explanation) : ''
    } };
  }
  function parseCSV(text) {
    const rows = []; let row = [], f = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"' && text[i + 1] === '"') { f += '"'; i++; } else if (c === '"') q = false; else f += c; }
      else if (c === '"') q = true;
      else if (c === ',') { row.push(f); f = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(f); rows.push(row); row = []; f = ''; }
      else f += c;
    }
    if (f || row.length) { row.push(f); rows.push(row); }
    const clean = rows.filter(r => r.some(x => x.trim()));
    if (!clean.length) return [];
    const head = clean[0].map(h => h.trim().toLowerCase().replace(/^option\s*/, ''));
    return clean.slice(1).map(r => { const o = { __csv: true }; head.forEach((h, i) => { o[h === 'question' ? 'q' : h] = (r[i] || '').trim(); }); return o; });
  }
  function parseAny(text) {
    const t = text.trim();
    if (!t) return { items: [], errors: ['Nothing to import.'] };
    let raw;
    if (t[0] === '[' || t[0] === '{') {
      try { raw = JSON.parse(t); } catch (e) { return { items: [], errors: ['That JSON did not parse: ' + e.message] }; }
      if (!Array.isArray(raw)) raw = raw.questions || raw.data || [raw];
    } else raw = parseCSV(t);
    const items = [], errors = [];
    raw.forEach((r, i) => { const n = normalize(r, i); if (n.q) items.push(n.q); else errors.push(`Row ${i + 1}: ${n.err}`); });
    return { items, errors };
  }
  async function importText(text, replace) {
    const msg = $('importMsg');
    const { items, errors } = parseAny(text);
    if (!items.length) { msg.className = 'note err'; msg.textContent = errors.slice(0, 4).join(' · ') || 'No valid questions found.'; return; }
    const next = replace ? items : custom.concat(items);
    const res = await send({ type: 'fq:setCustomBank', bank: next });
    if (!res || !res.ok) { msg.className = 'note err'; msg.textContent = (res && res.reason) || 'Import failed.'; return; }
    custom = next;
    if (settings.bankSource === 'builtin') await saveSettings({ bankSource: 'both' });
    msg.className = 'note ok';
    msg.textContent = `Imported ${items.length} question${items.length === 1 ? '' : 's'}${errors.length ? `, skipped ${errors.length} (${errors.slice(0, 2).join('; ')})` : ''}. You now have ${custom.length}.`;
    const keep = msg.outerHTML;
    renderView();
    if ($('importMsg')) $('importMsg').outerHTML = keep;
  }
  function download(name, text, type = 'application/json') {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function pickFile(accept, cb) {
    const inp = $('fileInput'); inp.accept = accept; inp.value = '';
    inp.onchange = async () => { const f = inp.files[0]; if (f) cb(await f.text(), f.name); };
    inp.click();
  }

  // ---------- events ----------
  document.addEventListener('click', async e => {
    const t = e.target;
    const goBtn = t.closest('[data-go]');
    if (goBtn) { const [p, tb] = goBtn.dataset.go.split('/'); return navigate(p, tb); }
    const navA = t.closest('[data-nav]');
    if (navA) { e.preventDefault(); return navigate(navA.dataset.nav); }
    const tabBtn = t.closest('[data-tab]');
    if (tabBtn) { view.tab = tabBtn.dataset.tab; pushNext = true; return renderView(); }
    const hit = t.closest('[data-hit]');
    if (hit) { const [p, tb, id] = hit.dataset.hit.split('|'); $('search').value = ''; runSearch(''); return navigate(p, tb, id); }
    const on = t.closest('[data-set-on]');
    if (on) return saveSettings({ [on.dataset.setOn]: true }, true);
    const segBtn = t.closest('.seg button');
    if (segBtn) {
      const g = segBtn.parentElement;
      g.querySelectorAll('button').forEach(b => b.setAttribute('aria-checked', b === segBtn));
      const v = JSON.parse(segBtn.dataset.v);
      if (g.dataset.key === 'bankSource') return saveBy(g.dataset.kind, g.dataset.key, v, ['bank', 'quiz']);
      return saveBy(g.dataset.kind, g.dataset.key, v);
    }
    const chipBtn = t.closest('.chips[data-key] .chip');
    if (chipBtn) {
      const g = chipBtn.parentElement;
      chipBtn.setAttribute('aria-pressed', chipBtn.getAttribute('aria-pressed') !== 'true');
      const vals = [...g.querySelectorAll('.chip[aria-pressed="true"]')].map(b => JSON.parse(b.dataset.v));
      if (g.dataset.key === 'lockTopics' && !vals.length) { chipBtn.setAttribute('aria-pressed', 'true'); return flash('Keep at least one topic', true); }
      const all = g.querySelectorAll('.chip').length;
      return saveSettings({ [g.dataset.key]: g.dataset.key === 'lockTopics' && vals.length === all ? null : vals });
    }
    const th = t.closest('.theme');
    if (th) { document.querySelectorAll('.theme').forEach(b => b.setAttribute('aria-pressed', b === th)); return savePrefs({ theme: th.dataset.theme }); }
    const acc = t.closest('[data-accent]');
    if (acc) { await savePrefs({ accent: acc.dataset.accent }); return renderView(); }
    const open = t.closest('[data-open]');
    if (open) {
      const w = open.dataset.open;
      if (w === 'welcome' || w === 'daily') return chrome.tabs.create({ url: chrome.runtime.getURL('src/quiz.html?mode=' + w) });
      return send({ type: 'fq:openPractice', query: w === 'practice' ? '' : 'pmode=' + w });
    }
    const star = t.closest('[data-star]');
    if (star) {
      e.preventDefault();
      const id = star.dataset.star;
      starred.has(id) ? starred.delete(id) : starred.add(id);
      star.textContent = starred.has(id) ? '★' : '☆'; star.setAttribute('aria-pressed', starred.has(id));
      return chrome.storage.local.set({ starred: [...starred] });
    }
    const rmSite = t.closest('[data-rm-site]');
    if (rmSite) {
      const id = rmSite.dataset.rmSite, c = settings.customSites.find(x => x.id === id);
      await saveSettings({ customSites: settings.customSites.filter(x => x.id !== id), disabledSites: settings.disabledSites.filter(x => x !== id) }, ['sites']);
      if (c) chrome.permissions.remove({ origins: c.hosts.flatMap(h => [`*://${h}/*`, `*://*.${h}/*`]) }).catch(() => {});
      return;
    }
    const rmAllow = t.closest('[data-rm-allow]');
    if (rmAllow) return saveSettings({ allowList: settings.allowList.filter((_, i) => i !== +rmAllow.dataset.rmAllow) }, ['sites']);
    const preset = t.closest('[data-preset]');
    if (preset) {
      const P = { work: { scheduleOn: true, scheduleDays: [1, 2, 3, 4, 5], scheduleFrom: '09:00', scheduleTo: '18:00' }, study: { scheduleOn: true, scheduleDays: [0, 1, 2, 3, 4, 5, 6], scheduleFrom: '18:00', scheduleTo: '23:00' },
        school: { scheduleOn: true, scheduleDays: [1, 2, 3, 4, 5], scheduleFrom: '07:00', scheduleTo: '21:00' }, always: { scheduleOn: false } }[preset.dataset.preset];
      return saveSettings(P, ['schedule']);
    }
    const tp = t.closest('[data-topics]');
    if (tp) {
      if (tp.dataset.topics === 'none') return flash('Keep at least one topic: tap the ones you want', true);
      return saveSettings({ lockTopics: null }, true);
    }

    switch (t.id) {
      case 'siteAdd': return addSite();
      case 'allowAdd': return addAllow();
      case 'testSound': return testSound();
      case 'libMore': libLimit += 40; return renderLib();
      case 'drop': return pickFile('.json,.csv,.txt', text => importText(text, false));
      case 'importAdd': return importText($('pasteBox').value, false);
      case 'importReplace': return importText($('pasteBox').value, true);
      case 'tplJson': return download('salesforce-daily-quiz-questions-template.json', JSON.stringify([
        { topic: 'Geography', difficulty: 'easy', q: 'What is the capital of Australia?', options: ['Sydney', 'Canberra', 'Melbourne', 'Perth'], answer: 1, explanation: 'Canberra was purpose-built as the capital in 1913.' },
        { topic: 'JavaScript', difficulty: 'medium', q: 'What does this log?', code: 'console.log(typeof null);', options: ['"null"', '"object"', '"undefined"', 'It throws'], answer: 'B', explanation: 'A long-standing quirk: typeof null is "object".' }
      ], null, 2));
      case 'tplCsv': return download('salesforce-daily-quiz-questions-template.csv', 'question,a,b,c,d,answer,explanation,topic,difficulty\n"What is the capital of Australia?",Sydney,Canberra,Melbourne,Perth,B,"Canberra was purpose-built as the capital in 1913.",Geography,easy\n"Which planet is known as the Red Planet?",Venus,Jupiter,Mars,Saturn,C,"Iron oxide dust gives Mars its colour.",Science,easy\n', 'text/csv');
      case 'exportMine': return download('salesforce-daily-quiz-my-questions.json', JSON.stringify(custom.map(({ id, ...q }) => q), null, 2));
      case 'clearMine':
        if (!confirm(`Delete all ${custom.length} of your questions?`)) return;
        { const r = await send({ type: 'fq:setCustomBank', bank: [] }); if (r && r.ok) { custom = []; if (settings.bankSource === 'custom') await saveSettings({ bankSource: 'builtin' }); renderView(); flash('Deleted'); } else flash((r && r.reason) || 'Could not delete', true); }
        return;
      case 'exportAll': { const b = await send({ type: 'fq:export' }); return download(`salesforce-daily-quiz-backup-${FQ_dayKey()}.json`, JSON.stringify(b, null, 2)); }
      case 'importAll': return pickFile('.json', async text => {
        let b; try { b = JSON.parse(text); } catch (_) { return flash('That file is not valid JSON', true); }
        const r = await send({ type: 'fq:import', backup: b });
        if (r && r.ok) { flash('Backup restored ✓'); await loadAll(); } else flash((r && r.reason) || 'Restore failed', true);
      });
      case 'resetProgress':
        if (!confirm('Reset XP, stats, achievements and bookmarks? This cannot be undone.')) return;
        { const r = await send({ type: 'fq:reset', scope: 'progress' }); if (r && r.ok) { flash('Progress reset'); await loadAll(); } else flash((r && r.reason) || 'Could not reset', true); }
        return;
      case 'resetAll':
        if (!confirm('Reset EVERYTHING back to a fresh install? Settings, progress and your questions will be erased.')) return;
        { const r = await send({ type: 'fq:reset', scope: 'all' }); if (r && r.ok) { flash('Everything reset'); await loadAll(); } else flash((r && r.reason) || 'Could not reset', true); }
        return;
      case 'shortcuts': return chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
    }
  });

  document.addEventListener('change', e => {
    const t = e.target;
    if (t.matches('.switch input')) return saveBy(t.dataset.kind, t.dataset.key, t.checked);
    if (t.matches('input[type="range"]')) return saveBy(t.dataset.kind, t.dataset.key, Number(t.value));
    if (t.matches('[data-site]')) {
      const off = new Set(settings.disabledSites);
      t.checked ? off.delete(t.dataset.site) : off.add(t.dataset.site);
      return saveSettings({ disabledSites: [...off] });
    }
    if (t.matches('[data-time]')) return saveSettings({ [t.dataset.time]: t.value });
    if (t.matches('[data-text]')) return saveSettings({ [t.dataset.text]: t.value.trim() });
    if (t.id === 'accentPick') return savePrefs({ accent: t.value }).then(() => renderView());
    if (t.id === 'libTopic') { libTopic = t.value; libLimit = 40; return renderLib(); }
  });
  document.addEventListener('input', e => {
    const t = e.target;
    if (t.matches('input[type="range"]')) {
      t.nextElementSibling.textContent = t.value + (t.dataset.unit || '');
      if (t.dataset.key === 'questionsPerQuiz' || t.dataset.key === 'passPercent') { settings = { ...settings, [t.dataset.key]: +t.value }; paintDerived(); }
    }
    if (t.id === 'libSearch') { libQuery = t.value; libLimit = 40; renderLib(); }
    if (t.id === 'search') runSearch(t.value);
  });
  document.addEventListener('keydown', e => {
    if (e.key === '/' && document.activeElement === document.body) { e.preventDefault(); $('search').focus(); return; }
    if (e.target.id === 'search' && e.key === 'Escape') { e.target.value = ''; runSearch(''); return; }
    if (e.target.id === 'search' && e.key === 'Enter') { const f = document.querySelector('.hit-item'); if (f) f.click(); return; }
    if (e.key !== 'Enter') return;
    if (e.target.id === 'siteInput') addSite();
    if (e.target.id === 'allowInput') addAllow();
    if (e.target.id === 'drop') $('drop').click();
  });
  document.addEventListener('dragover', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) { e.preventDefault(); d.classList.add('over'); } });
  document.addEventListener('dragleave', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) d.classList.remove('over'); });
  document.addEventListener('drop', async e => {
    const d = e.target.closest && e.target.closest('#drop'); if (!d) return;
    e.preventDefault(); d.classList.remove('over');
    const f = e.dataTransfer.files[0]; if (f) importText(await f.text(), false);
  });

  function addSite() {
    const inp = $('siteInput'), msg = $('siteMsg');
    const host = FQ_normalizeHost(inp.value);
    msg.className = 'note err';
    if (!host) { msg.textContent = 'That does not look like a website address.'; return; }
    if (FQ_siteForHost(host)) { msg.textContent = `${host} is already built in. Tick it above.`; return; }
    if (settings.customSites.some(c => c.hosts.includes(host))) { msg.textContent = `${host} is already on your list.`; return; }
    // permissions.request must run straight from the click, before any other await.
    chrome.permissions.request({ origins: [`*://${host}/*`, `*://*.${host}/*`] }).then(async granted => {
      if (!granted) { msg.textContent = 'Chrome permission was not granted, so Salesforce Daily Quiz cannot see that site.'; return; }
      await saveSettings({ customSites: settings.customSites.concat({ name: host, emoji: '', hosts: [host] }) }, ['sites']);
      const m = $('siteMsg'); if (m) { m.className = 'note ok'; m.textContent = `Now tracking ${host}. Open tabs pick it up right away.`; }
    }).catch(err => { msg.textContent = String(err.message || err); });
  }
  function addAllow() {
    const v = $('allowInput').value.trim();
    if (!v) return;
    if (settings.allowList.includes(v)) return flash('Already allowed', true);
    saveSettings({ allowList: settings.allowList.concat(v) }, ['sites']);
  }
  function testSound() {
    if (prefs.sound === false) return flash('Sound is off', true);
    const c = new AudioContext(), vol = (prefs.volume ?? 70) / 100;
    [523, 659, 784, 1047].forEach((f, i) => {
      const o = c.createOscillator(), g = c.createGain();
      o.type = prefs.soundPack === 'retro' ? 'square' : prefs.soundPack === 'soft' ? 'sine' : 'triangle';
      const v = .14 * vol * (prefs.soundPack === 'retro' ? .4 : prefs.soundPack === 'soft' ? .6 : 1);
      o.frequency.value = f * (prefs.soundPack === 'soft' ? .8 : 1);
      g.gain.setValueAtTime(.0001, c.currentTime + i * .09); g.gain.exponentialRampToValueAtTime(Math.max(.0002, v), c.currentTime + i * .09 + .02);
      g.gain.exponentialRampToValueAtTime(.0001, c.currentTime + i * .09 + .35);
      o.connect(g).connect(c.destination); o.start(c.currentTime + i * .09); o.stop(c.currentTime + i * .09 + .4);
    });
  }

  // ---------- nav ----------
  function buildNav() {
    let last = null, html = '';
    for (const p of PAGES) {
      if (p.g !== last) { if (p.g) html += `<div class="nav-group">${p.g}</div>`; last = p.g; }
      html += `<a href="#${p.id}" data-nav="${p.id}">${p.t}</a>`;
    }
    $('nav').innerHTML = html;
  }

  // ---------- boot ----------
  async function loadAll() {
    const [st, local] = await Promise.all([send({ type: 'fq:state' }), chrome.storage.local.get(['prefs', 'qstats', 'starred', 'customBank'])]);
    pub = st || {}; settings = { ...FQ_DEFAULTS, ...(pub.settings || {}) }; stats = pub.stats || {};
    prefs = { ...FQ_PREFS, ...(local.prefs || {}) }; qstats = local.qstats || {}; starred = new Set(local.starred || []);
    custom = (local.customBank || []).map((q, i) => ({ ...q, id: q.id || `u-${i}` }));
    if (!builtin.length) { try { builtin = await (await fetch(chrome.runtime.getURL('data/questions.json'))).json(); } catch (_) { builtin = []; } }
    frozen = !!pub.locked;
    buildNav();
    fromHash();
    renderView();
  }
  function fromHash() {
    const [p, tb] = location.hash.slice(1).split('/');
    // Old v2 anchors (#quiz, #sites, #look...) still land somewhere sensible.
    const legacy = { time: ['focus', 'time'], sites: ['focus', 'sites'], schedule: ['focus', 'schedule'], you: ['profile'], about: ['data', 'about'] }[p];
    if (legacy) view = { page: legacy[0], tab: legacy[1] || '' };
    else if (PAGES.some(x => x.id === p)) view = { page: p, tab: tb || '' };
  }
  window.addEventListener('hashchange', () => { fromHash(); renderView(); });
  $('search').value = ''; // Chrome restores form fields on reload
  $('homeLink').href = FQ_HOME;
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.timer) { const was = frozen; frozen = !!(ch.timer.newValue && ch.timer.newValue.locked); if (was !== frozen) { $('lockbar').hidden = !frozen; $('view').classList.toggle('frozen', frozen); } }
    if (ch.prefs) { prefs = { ...FQ_PREFS, ...(ch.prefs.newValue || {}) }; if (view.page === 'look' && !(document.activeElement && document.activeElement.closest('#view'))) renderView(); }
  });
  loadAll();
})();
