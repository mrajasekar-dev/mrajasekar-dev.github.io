// Leaderboard API client (global SFDQ_API). Loaded by quiz.html, popup.html and options.html, never by the service worker.
// Identity lives in chrome.storage.local under "lb": { code, name, linkedin, joinedAt }. The recovery code is the only credential.
// "lbChangedAt" (ms) and "lbSignedOut" (bool) record the last identity change; src/link.js uses them to keep this
// extension and the web app in step on the same device (last writer wins). A code with an empty name is a code that came
// from the web app: adopt() fills in the profile.
// Every method resolves with the parsed JSON body or rejects with a normalised { code, message, network } object.
const SFDQ_API = (() => {
  const TIMEOUT_MS = 8000;
  let adopting = null;   // in-flight adopt() promise
  let upgrading = null;  // in-flight upgradeCode() promise
  const SHORT_CODE = /^SFDQ-[0-9A-HJKMNP-TV-Z]{4}-[0-9A-HJKMNP-TV-Z]{4}$/;
  const UPGRADE_RETRY_MS = 10 * 60 * 1000;   // after a failed attempt, wait before trying again (stored, so every page shares it)
  const HAS_STORAGE = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  // Plain-page fallback so the quiz can still be previewed outside the extension.
  const mem = {
    get: async k => { const all = JSON.parse(localStorage.sfdqApi || '{}'); return k in all ? { [k]: all[k] } : {}; },
    set: async o => { localStorage.sfdqApi = JSON.stringify({ ...JSON.parse(localStorage.sfdqApi || '{}'), ...o }); },
    remove: async k => { const all = JSON.parse(localStorage.sfdqApi || '{}'); delete all[k]; localStorage.sfdqApi = JSON.stringify(all); }
  };
  const store = HAS_STORAGE ? chrome.storage.local : mem;

  const baseUrl = async () => {
    const { apiBase } = await store.get('apiBase');
    return String(apiBase || SFDQ_CONFIG.apiBase).replace(/\/+$/, '');
  };
  const webUrl = async () => {
    const { apiBase } = await store.get('apiBase');
    // With a dev API override the web app is assumed to live on the same origin.
    return String(apiBase || SFDQ_CONFIG.webUrl).replace(/\/+$/, '');
  };

  async function identity() { return (await store.get('lb')).lb || null; }
  async function saveIdentity(patch) {
    const cur = (await identity()) || {};
    const next = { code: cur.code, name: '', linkedin: '', joinedAt: Date.now(), ...cur, ...patch };
    await store.set({ lb: next });
    return next;
  }
  // Every identity change (join, restore, sign out, delete) stamps lbChangedAt so src/link.js can propagate it.
  const setIdentity = lb => store.set({ lb, lbChangedAt: Date.now(), lbSignedOut: false });
  // Flag first, then remove the code, so nobody ever sees "no code and not signed out".
  async function clearIdentity() {
    await store.set({ lbSignedOut: true, lbChangedAt: Date.now() });
    await store.remove('lb');
  }

  const err = (code, message, network = false, status = 0) => ({ code, message, network, status });

  // Recovery codes: SFDQ-XXXX-XXXX (8 Crockford base32 characters; new accounts). Earlier SFDQ-XXXX-XXXX-XXXX (12) and legacy
  // SFDQ + 40 character codes still work and are kept as they are.
  // Accepts lower case, spaces, missing dashes and the usual O/I/L/U typos. Returns the canonical code, or '' when it cannot be a code.
  function normalizeCode(input) {
    let s = String(input || '').toUpperCase().replace(/[\s_-]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1').replace(/U/g, 'V');
    if (!/^[0-9A-HJKMNP-TV-Z]+$/.test(s)) return '';
    // "SFDQ" + 8 and a bare 12-character code are the same length: a leading SFDQ is read as the prefix (the server tries both readings).
    if (s.startsWith('SFDQ') && (s.length === 12 || s.length === 16 || s.length === 44)) s = s.slice(4);
    if (s.length === 8 || s.length === 12) return 'SFDQ-' + s.match(/.{4}/g).join('-');
    if (s.length === 40) return 'SFDQ-' + s;
    return '';
  }


  // Players with a long legacy code get a short SFDQ-XXXX-XXXX one, silently. Signed in only, one request at a time, and the old
  // code is kept on any failure (offline, 404, 401, bad reply). A failed attempt is not repeated for 10 minutes.
  // Stamps lbChangedAt so src/link.js hands the new code to the web page. Always resolves with the current identity.
  function upgradeCode() {
    if (upgrading) return upgrading;
    // One request across every open extension page: the server issues a new code per request, so two pages asking at once would
    // leave this device holding a code the server has already replaced. The lock makes the second page see the finished result.
    const run = fn => (typeof navigator !== 'undefined' && navigator.locks) ? navigator.locks.request('sfdq-upgrade-code', fn) : fn();
    upgrading = run(async () => {
      const lb = await identity();
      if (!lb || !lb.code || SHORT_CODE.test(lb.code)) return lb;
      const { lbUpgradeTry } = await store.get('lbUpgradeTry');
      if (lbUpgradeTry && Date.now() - lbUpgradeTry < UPGRADE_RETRY_MS) return lb;
      await store.set({ lbUpgradeTry: Date.now() });
      try {
        const r = await call('POST', '/api/me/code', { auth: true, body: {} });
        const next = normalizeCode(r && r.code);
        if (!SHORT_CODE.test(next)) return lb;
        const cur = await identity();
        if (!cur || cur.code !== lb.code) return cur;        // signed out or changed while we waited
        await store.set({ lb: { ...cur, code: next }, lbChangedAt: Date.now(), lbSignedOut: false });
        await store.remove('lbUpgradeTry');
        return await identity();
      } catch (_) { return lb; }
    }).catch(() => identity()).finally(() => { upgrading = null; });
    return upgrading;
  }

  async function call(method, path, { body, auth = false, query } = {}) {
    const headers = {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (auth) {
      const lb = await identity();
      if (!lb || !lb.code) throw err('not_joined', 'Join the leaderboard first.');
      headers.Authorization = 'Bearer ' + lb.code;
    }
    const qs = query ? '?' + Object.entries(query).filter(([, v]) => v !== undefined && v !== null).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&') : '';
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
    let res;
    try {
      res = await fetch((await baseUrl()) + path + qs, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: ctl.signal, cache: 'no-store' });
    } catch (e) {
      clearTimeout(timer);
      throw ctl.signal.aborted ? err('timeout', 'The leaderboard took too long to respond.', true) : err('network', 'Could not reach the leaderboard. Check your connection.', true);
    }
    let data = null;
    try { data = await res.json(); } catch (_) { /* non-JSON body */ }
    clearTimeout(timer);
    if (!res.ok) {
      const e = err((data && data.error) || (res.status === 401 ? 'unauthorized' : 'http_' + res.status), (data && data.message) || 'Something went wrong. Try again in a moment.', res.status >= 500 && !(data && data.error), res.status);
      if (data && data.result) e.result = data.result; // 409 already_played carries the stored result
      throw e;
    }
    return data || {};
  }

  return {
    identity, normalizeCode, isJoined: async () => !!((await identity()) || {}).code, clearIdentity, webUrl,

    // With no name the server picks a friendly one (r.anonymous is true). The recovery code is the device identity.
    async register({ name, linkedin, consent }) {
      const given = String(name || '').trim();
      const body = { consent: consent === true };
      if (given) { body.name = given; if (linkedin) body.linkedin = linkedin; }
      const r = await call('POST', '/api/register', { body });
      await setIdentity({ code: r.code, name: r.player.name, linkedin: r.player.linkedin || '', joinedAt: r.player.created || Date.now(), anon: r.anonymous === true });
      return r;
    },
    async restore(code) {
      const clean = normalizeCode(code);
      if (!clean) throw err('bad_code', 'That recovery code is not valid. Check it and try again.');
      const r = await call('POST', '/api/restore', { body: { code: clean } });
      await setIdentity({ code: clean, name: r.player.name, linkedin: r.player.linkedin || '', joinedAt: r.player.created || Date.now() });
      return r;
    },
    me: () => call('GET', '/api/me', { auth: true }),
    // A code that came from the web app has no profile yet. Fetch it once and store the full identity.
    // Keeps the code and resolves quietly when offline, so the next call retries. Always resolves with the current identity.
    adopt() {
      if (adopting) return adopting;
      adopting = (async () => {
        let lb = await identity();
        if (lb && lb.code && !lb.name) {
          try {
            const r = await call('GET', '/api/me', { auth: true });
            const cur = await identity();
            if (!cur || cur.code !== lb.code) return cur;     // changed while we waited
            lb = await saveIdentity({ name: r.player.name, linkedin: r.player.linkedin || '', joinedAt: r.player.created || cur.joinedAt });
          } catch (_) { return lb; }                           // offline or not accepted: keep the code, retry next time
        }
        return (await upgradeCode()) || lb;
      })().finally(() => { adopting = null; });
      return adopting;
    },
    upgradeCode,
    async updateMe(patch) {
      const r = await call('PATCH', '/api/me', { auth: true, body: patch });
      await saveIdentity({ name: r.player.name, linkedin: r.player.linkedin || '', anon: false });
      return r;
    },
    // Deletes everything on the server, then forgets the code on this device.
    async deleteMe() {
      try { await call('DELETE', '/api/me', { auth: true }); }
      catch (e) { if (e.code !== 'unauthorized') throw e; } // code already invalid: nothing left to delete
      await clearIdentity();
      return { ok: true };
    },
    dailyInfo: () => call('GET', '/api/daily', { auth: true }),
    dailyStart: () => call('POST', '/api/daily/start', { auth: true, body: {} }),
    dailyAnswer: (day, i, choice) => call('POST', '/api/daily/answer', { auth: true, body: { day, i, choice } }),
    // Public board; sends the code when joined so the response includes your own result in "me".
    async board({ day, limit } = {}) {
      const auth = await isJoinedNow();
      return call('GET', '/api/board', { auth, query: { day, limit } });
    },
    review: day => call('GET', '/api/review', { auth: true, query: { day } }),
    report: (day, i, reason, note) => call('POST', '/api/report', { auth: true, body: { day, i, reason, note } }),
    reportPlayer: (pid, reason, note) => call('POST', '/api/report-player', { auth: true, body: { pid, reason, note } })
  };
  async function isJoinedNow() { return !!((await identity()) || {}).code; }
})();
