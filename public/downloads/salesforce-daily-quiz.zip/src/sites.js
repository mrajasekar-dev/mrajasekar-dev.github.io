// FocusQuest shared core: tracked sites, default rules, ranks, achievements and small helpers.
// Loaded by the background worker, content script, quiz, popup and options pages.
// Every built-in host must also be covered by content_scripts.matches in manifest.json.
(function (g) {
  const HOME_URL = 'https://rajasekar-m.vercel.app/products/salesforce-daily-quiz';
  const PRIVACY_URL = HOME_URL + '/privacy';

  const SITES = [
    { id: 'youtube',   name: 'YouTube',   emoji: '', hosts: ['youtube.com'] },
    { id: 'instagram', name: 'Instagram', emoji: '', hosts: ['instagram.com'] },
    { id: 'facebook',  name: 'Facebook',  emoji: '', hosts: ['facebook.com'] },
    { id: 'x',         name: 'X / Twitter', emoji: '', hosts: ['x.com', 'twitter.com'] },
    { id: 'tiktok',    name: 'TikTok',    emoji: '', hosts: ['tiktok.com'] },
    { id: 'reddit',    name: 'Reddit',    emoji: '', hosts: ['reddit.com'] },
    { id: 'linkedin',  name: 'LinkedIn',  emoji: '', hosts: ['linkedin.com'] },
    { id: 'snapchat',  name: 'Snapchat',  emoji: '', hosts: ['snapchat.com'] },
    { id: 'pinterest', name: 'Pinterest', emoji: '', hosts: ['pinterest.com'] },
    { id: 'threads',   name: 'Threads',   emoji: '', hosts: ['threads.net', 'threads.com'] },
    { id: 'tumblr',    name: 'Tumblr',    emoji: '', hosts: ['tumblr.com'] },
    { id: 'twitch',    name: 'Twitch',    emoji: '', hosts: ['twitch.tv'] },
    { id: 'quora',     name: 'Quora',     emoji: '', hosts: ['quora.com'] },
    { id: '9gag',      name: '9GAG',      emoji: '', hosts: ['9gag.com'] }
  ];

  const hostMatches = (h, d) => h === d || h.endsWith('.' + d);

  // customSites: [{ id, name, emoji, hosts }] from settings.
  function siteForHost(hostname, customSites) {
    const h = String(hostname || '').toLowerCase();
    return SITES.find(s => s.hosts.some(d => hostMatches(h, d)))
      || (customSites || []).find(s => s.hosts.some(d => hostMatches(h, d)))
      || null;
  }

  // "https://www.Netflix.com/browse" -> "netflix.com"
  function normalizeHost(input) {
    let s = String(input || '').trim().toLowerCase();
    s = s.replace(/^[a-z]+:\/\//, '').replace(/^\*\./, '').split(/[/?#]/)[0].replace(/:\d+$/, '').replace(/^www\./, '');
    return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(s) ? s : '';
  }

  const DEFAULTS = {
    blockerOn: false,          // focus timer that locks social sites; off = daily quiz + practice only
    // time
    limitMinutes: 60,          // allowance before the first quiz of a cycle
    rewardMinutes: 60,         // time earned by each pass
    dailyReset: false,         // refill the allowance at midnight (clears a pending quiz)
    warnAt: [10, 5, 1],
    toastPosition: 'br',       // br | bl | tr | tl
    retryCooldown: 0,          // minutes to wait after a failed round
    emergencyPerWeek: 1,       // "break glass" passes
    emergencyMinutes: 5,
    // sites
    disabledSites: ['linkedin'], // LinkedIn is off by default: it's a job-hunting tool as much as a feed.
    customSites: [],
    allowList: [],             // URL patterns that never count, e.g. youtube.com/@salesforce
    // schedule
    scheduleOn: false,
    scheduleDays: [1, 2, 3, 4, 5],
    scheduleFrom: '09:00',
    scheduleTo: '18:00',
    // quiz
    questionsPerQuiz: 10,
    passPercent: 70,
    livesOn: true,
    fiftyCount: 1,
    skipCount: 1,
    questionTimer: 0,          // seconds per question, 0 = off
    difficulty: 'ramp',        // ramp | mixed | easy | hard
    lockTopics: null,          // null = every topic
    explanations: 'always',    // always | wrong | never
    autoAdvance: false,
    shuffleOptions: true,
    bankSource: 'builtin',     // builtin | custom | both
    // you
    displayName: '',
    why: '',
    dailyGoal: 20,
    sound: true
  };

  const PREFS = {
    theme: 'auto', accent: '', dailyPrompt: true, font: 'theme', scale: 100, radius: 'round',
    motion: 'calm', background: 'plain', confetti: false,
    sound: true, soundPack: 'arcade', volume: 70,
    // Practice rules (Settings > Practice). Practice only: the daily and the focus-timer quiz ignore these.
    practiceLength: 10, practiceDifficulty: 'any', practiceTimer: 0, practiceTopics: null
  };

  // XP thresholds for the rank shown in the quiz and popup.
  const LEVELS = [
    [0, 'Trailhead Rookie', ''], [2000, 'Admin Apprentice', ''], [6000, 'Flow Wrangler', ''],
    [12000, 'Apex Artisan', ''], [22000, 'Governor Guru', ''], [36000, 'Integration Ninja', ''],
    [55000, 'Platform Architect', ''], [80000, 'CTA Legend', ''], [120000, 'Ohana Oracle', ''], [180000, 'Cloud Titan', '']
  ];
  const levelOf = xp => { let l = LEVELS[0]; for (const x of LEVELS) if (xp >= x[0]) l = x; return l; };

  const dayKey = (t = Date.now()) => {
    const d = new Date(t);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  // The shared daily puzzle runs on UTC days (same set for everyone, new set at 00:00 UTC).
  // Everything about the daily challenge uses this key; timer resets, passes and goals stay on local days (dayKey).
  const utcDay = (t = Date.now()) => new Date(t).toISOString().slice(0, 10);
  const nextUtcMidnight = (t = Date.now()) => (Math.floor(t / 864e5) + 1) * 864e5;

  // Consecutive days (ending today, or yesterday if today isn't done yet) that hit the daily goal.
  function dayStreak(answeredByDay, goal) {
    const by = answeredByDay || {};
    const hit = t => (by[dayKey(t)] || 0) >= Math.max(1, goal || 1);
    let t = Date.now(), n = 0;
    if (!hit(t)) t -= 864e5;
    while (hit(t)) { n++; t -= 864e5; }
    return n;
  }

  // Consecutive days with a finished daily challenge (today or yesterday counts as current).
  function dailyStreak(daily) {
    const d = daily || {};
    let t = Date.now(), n = 0;
    if (!d[utcDay(t)]) t -= 864e5;
    while (d[utcDay(t)]) { n++; t -= 864e5; }
    return n;
  }

  // Wordle-style numbers for the daily challenge.
  function dailyStats(daily) {
    const d = daily || {}, keys = Object.keys(d).sort();
    let best = 0, run = 0, prev = null;
    for (const k of keys) {
      const t = Date.parse(k + 'T12:00:00Z');
      run = prev !== null && Math.round((t - prev) / 864e5) === 1 ? run + 1 : 1;
      best = Math.max(best, run); prev = t;
    }
    const pcts = keys.map(k => d[k].total ? d[k].score / d[k].total : 0);
    return {
      played: keys.length, current: dailyStreak(d), best,
      avg: pcts.length ? Math.round(pcts.reduce((a, b) => a + b, 0) / pcts.length * 100) : 0,
      perfect: keys.filter(k => d[k].score === d[k].total).length
    };
  }

  const toMin = hhmm => { const [h, m] = String(hhmm || '0:0').split(':').map(Number); return (h || 0) * 60 + (m || 0); };
  // Is the rule "on" right now? Outside the schedule nothing is counted or locked.
  function inSchedule(settings, t = Date.now()) {
    if (!settings.scheduleOn) return true;
    const d = new Date(t);
    const now = d.getHours() * 60 + d.getMinutes();
    const from = toMin(settings.scheduleFrom), to = toMin(settings.scheduleTo);
    const days = settings.scheduleDays || [];
    if (from === to) return days.includes(d.getDay());
    if (from < to) return days.includes(d.getDay()) && now >= from && now < to;
    // overnight window, e.g. 21:00 → 02:00 belongs to the day it started
    if (now >= from) return days.includes(d.getDay());
    return now < to && days.includes((d.getDay() + 6) % 7);
  }

  // Allow-list patterns: plain substrings, "*" wildcards.
  function urlAllowed(url, patterns) {
    const u = String(url || '').toLowerCase().replace(/^[a-z]+:\/\/(www\.)?/, '');
    return (patterns || []).some(p => {
      const s = String(p || '').trim().toLowerCase().replace(/^[a-z]+:\/\/(www\.)?/, '');
      if (!s) return false;
      if (!s.includes('*')) return u.includes(s);
      const re = new RegExp(s.split('*').map(x => x.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*'));
      return re.test(u);
    });
  }

  // Achievements. `check(ctx)` gets { stats, round, now } after each finished round.
  const ACHIEVEMENTS = [
    { id: 'first-unlock', emoji: '', name: 'Earned It', desc: 'Pass your first lock-screen quiz.', check: c => c.round.lock && c.round.passed },
    { id: 'perfect', emoji: '', name: 'Flawless', desc: 'Score 100% on a round of 10 or more.', check: c => c.round.total >= 10 && c.round.score === c.round.total },
    { id: 'streak10', emoji: '', name: 'On Fire', desc: 'Answer 10 in a row correctly.', check: c => c.round.bestStreak >= 10 },
    { id: 'streak25', emoji: '', name: 'Meteor', desc: 'Answer 25 in a row correctly.', check: c => c.round.bestStreak >= 25 },
    { id: 'clutch', emoji: '', name: 'Clutch', desc: 'Pass a lock quiz with one life left.', check: c => c.round.lock && c.round.passed && c.round.livesOn && c.round.livesLeft === 1 },
    { id: 'no-help', emoji: '', name: 'No Help Needed', desc: 'Pass a lock quiz without using a lifeline.', check: c => c.round.lock && c.round.passed && !c.round.lifelines },
    { id: 'speedy', emoji: '', name: 'Speed Demon', desc: 'Get 10 speed bonuses in one round.', check: c => c.round.speedy >= 10 },
    { id: 'polymath', emoji: '', name: 'Polymath', desc: 'Answer correctly in 10 different topics in one round.', check: c => c.round.topicsRight >= 10 },
    { id: 'comeback', emoji: '', name: 'Comeback', desc: 'Pass a lock quiz right after failing one.', check: c => c.round.lock && c.round.passed && c.prevLockFailed },
    { id: 'night-owl', emoji: '', name: 'Night Owl', desc: 'Finish a round between midnight and 4am.', check: c => new Date(c.now).getHours() < 4 },
    { id: 'early-bird', emoji: '', name: 'Early Bird', desc: 'Finish a round between 5am and 7am.', check: c => { const h = new Date(c.now).getHours(); return h >= 5 && h < 7; } },
    { id: 'century', emoji: '', name: 'Century', desc: 'Answer 100 questions.', check: c => c.stats.answered >= 100 },
    { id: 'big-brain', emoji: '', name: 'Big Brain', desc: 'Answer 1,000 questions.', check: c => c.stats.answered >= 1000 },
    { id: 'goal', emoji: '', name: 'Goal Getter', desc: 'Hit your daily question goal.', check: c => c.goalHit },
    { id: 'week', emoji: '', name: 'Week Warrior', desc: 'Hit your daily goal 7 days in a row.', check: c => c.dayStreak >= 7 },
    { id: 'habit', emoji: '', name: 'Habit Formed', desc: 'Hit your daily goal 30 days in a row.', check: c => c.dayStreak >= 30 },
    { id: 'xp10k', emoji: '', name: '10K Club', desc: 'Earn 10,000 XP.', check: c => c.stats.xp >= 10000 },
    { id: 'xp100k', emoji: '', name: 'Six Figures', desc: 'Earn 100,000 XP.', check: c => c.stats.xp >= 100000 },
    { id: 'ten-unlocks', emoji: '', name: 'Frequent Flyer', desc: 'Pass 10 lock-screen quizzes.', check: c => c.stats.quizzesPassed >= 10 },
    { id: 'author', emoji: '', name: 'Author', desc: 'Import your own question bank.', check: c => c.stats.imported > 0 }
  ];

  const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  Object.assign(g, {
    FQ_HOME: HOME_URL, FQ_PRIVACY: PRIVACY_URL,
    FQ_SITES: SITES, FQ_LEVELS: LEVELS, FQ_DEFAULTS: DEFAULTS, FQ_PREFS: PREFS, FQ_ACHIEVEMENTS: ACHIEVEMENTS, FQ_WEEKDAYS: WEEKDAYS,
    FQ_siteForHost: siteForHost, FQ_normalizeHost: normalizeHost, FQ_levelOf: levelOf, FQ_dayKey: dayKey, FQ_utcDay: utcDay, FQ_nextUtcMidnight: nextUtcMidnight,
    FQ_dayStreak: dayStreak, FQ_dailyStreak: dailyStreak, FQ_dailyStats: dailyStats, FQ_inSchedule: inSchedule, FQ_urlAllowed: urlAllowed
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
