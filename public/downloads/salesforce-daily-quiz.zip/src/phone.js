// "Continue on your phone": a small dialog with a QR code that opens the web app already signed in. Shared by Settings and the
// Daily result screen (src/options.js, src/quiz.js). The QR code is drawn on this device from src/qrcode.js: no network, no
// external library calls. The recovery code goes only into the URL fragment (after #), which browsers never send to a server.
// Hidden until asked for, and closes itself after three minutes.
const SFDQ_PHONE = (() => {
  const AUTO_CLOSE_MS = 3 * 60 * 1000;
  let root = null, timer = 0, opener = null, copyTimer = 0;

  // The link the QR code holds: <web app>/#/continue?code=<recovery code>
  async function link() {
    const lb = await SFDQ_API.identity();
    if (!lb || !lb.code) return '';
    const web = String(await SFDQ_API.webUrl()).replace(/\/+$/, '');
    return web + '/#/continue?code=' + encodeURIComponent(lb.code);
  }

  // Module matrix -> one SVG path. Black on white with a four-module quiet zone, whatever the theme, so every camera reads it.
  function qrSvg(text) {
    const qr = qrcode(0, 'M');
    qr.addData(text, 'Byte');
    qr.make();
    const n = qr.getModuleCount(), q = 4;
    let d = '';
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (qr.isDark(y, x)) d += `M${x + q} ${y + q}h1v1h-1z`;
    return { svg: `<svg viewBox="0 0 ${n + 2 * q} ${n + 2 * q}" role="img" aria-label="QR code" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`, size: n };
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* fall through */ }
    try {
      const t = document.createElement('textarea'); t.value = text; t.setAttribute('readonly', ''); t.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
      document.body.appendChild(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok;
    } catch (_) { return false; }
  }

  function close() {
    clearTimeout(timer); clearTimeout(copyTimer);
    if (root) { root.remove(); root = null; }
    document.removeEventListener('keydown', onKey, true);
    if (opener && opener.isConnected) { try { opener.focus({ preventScroll: true }); } catch (_) {} }
    opener = null;
  }
  function onKey(e) {
    if (!root) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
    else if (e.key === 'Tab') {   // keep focus inside the dialog
      const f = [...root.querySelectorAll('button')]; if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }

  async function open(from) {
    if (root) return;
    const url = await link();
    if (!url) return;   // not signed in: nothing to show
    let art;
    try { art = qrSvg(url); } catch (_) { return; }
    opener = from || document.activeElement;
    root = document.createElement('div');
    root.className = 'phone-modal';
    root.innerHTML = `<div class="phone-card" role="dialog" aria-modal="true" aria-labelledby="phoneTitle">
        <h2 id="phoneTitle">Continue on your phone</h2>
        <div class="phone-qr" id="phoneQr" data-url="${url.replace(/&/g, '&amp;').replace(/"/g, '&quot;')}">${art.svg}</div>
        <p class="phone-note">Scan with your phone camera to open today's quiz already signed in. Anyone who sees this code can sign in as you, so close it when done.</p>
        <div class="phone-actions"><button type="button" class="btn ghost" id="phoneCopy">Copy link</button><button type="button" class="btn primary" id="phoneHide">Hide</button></div>
      </div>`;
    document.body.appendChild(root);
    root.addEventListener('mousedown', e => { if (e.target === root) close(); });
    root.querySelector('#phoneHide').addEventListener('click', close);
    root.querySelector('#phoneCopy').addEventListener('click', async e => {
      const b = e.currentTarget, ok = await copyText(await link());
      b.textContent = ok ? 'Copied' : 'Could not copy';
      clearTimeout(copyTimer); copyTimer = setTimeout(() => { if (b.isConnected) b.textContent = 'Copy link'; }, 1800);
    });
    document.addEventListener('keydown', onKey, true);
    timer = setTimeout(close, AUTO_CLOSE_MS);
    root.querySelector('#phoneHide').focus({ preventScroll: true });
  }

  return { open, close, link, qrSvg, isOpen: () => !!root };
})();
