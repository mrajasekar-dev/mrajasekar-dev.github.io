// Links the player's identity between the web app and this extension, on this device only.
// Runs on the web app page (see content_scripts in manifest.json) at document_start, before the page's own scripts.
// It only moves the recovery code between the page's localStorage and chrome.storage.local. Nothing is sent over the network.
//
// Each side keeps the code plus a change time, last writer wins:
//   web page localStorage:   sfdq.code, sfdq.changedAt (ms), sfdq.signedOut ('1')
//   chrome.storage.local:    lb {code, ...},  lbChangedAt (ms),  lbSignedOut (bool)
(() => {
  'use strict';
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
  const K = 'sfdq.code', T = 'sfdq.changedAt', S = 'sfdq.signedOut';
  const CODE_RE = /^SFDQ-[A-Z0-9-]{8,60}$/;
  const root = document.documentElement;
  root.dataset.sfdqLink = 'pending';   // the web app waits briefly for the first sync

  const ls = {
    get(k) { try { return localStorage.getItem(k); } catch (_) { return null; } },
    set(k, v) { try { localStorage.setItem(k, String(v)); } catch (_) {} },
    del(k) { try { localStorage.removeItem(k); } catch (_) {} }
  };
  const norm = c => String(c || '').trim().toUpperCase();
  const readPage = () => ({ code: norm(ls.get(K)), ts: Number(ls.get(T)) || 0, so: ls.get(S) === '1' });
  const readExt = async () => {
    const r = await chrome.storage.local.get(['lb', 'lbChangedAt', 'lbSignedOut']);
    return { code: norm(r.lb && r.lb.code), ts: Number(r.lbChangedAt) || 0, so: r.lbSignedOut === true, lb: r.lb || null };
  };
  const setPage = (code, ts) => { ls.set(K, code); ls.set(T, ts); ls.del(S); };
  const clearPage = ts => { ls.del(K); ls.set(S, '1'); ls.set(T, ts); };
  const setExt = async (code, ts, cur) => {
    const lb = cur && norm(cur.code) === code ? cur : { code, name: '', linkedin: '', joinedAt: ts };
    await chrome.storage.local.set({ lb, lbChangedAt: ts, lbSignedOut: false });
  };
  // Flag first, then remove the code, so a reader never sees "no code and not signed out".
  const clearExt = async ts => {
    await chrome.storage.local.set({ lbSignedOut: true, lbChangedAt: ts });
    await chrome.storage.local.remove('lb');
  };

  // Compares both sides and brings the older one in line. Returns true when the page's own storage changed.
  async function reconcile() {
    const W = readPage(), E = await readExt();
    const w = W.so ? '' : W.code, e = E.so ? '' : E.code;   // effective code (a signed-out side has none)
    if (w && e) {
      if (w === e || W.ts === E.ts) return false;
      if (W.ts > E.ts) { await setExt(w, W.ts, E.lb); return false; }
      setPage(e, E.ts); return true;
    }
    if (w || e) {
      const webHas = !!w, A = webHas ? W : E, B = webHas ? E : W;
      if (B.so && B.ts > A.ts) {                         // the other side signed out more recently
        if (webHas) { clearPage(B.ts); return true; }
        await clearExt(B.ts); return false;
      }
      const ts = A.ts || Date.now();                     // copy the code across
      if (webHas) { if (!W.ts) ls.set(T, ts); await setExt(w, ts, E.lb); return false; }
      if (!E.ts) await chrome.storage.local.set({ lbChangedAt: ts });
      setPage(e, ts); return true;
    }
    if (W.so && W.ts > E.ts) { await chrome.storage.local.set({ lbSignedOut: true, lbChangedAt: W.ts }); return false; }
    if (E.so && E.ts > W.ts) { ls.set(S, '1'); ls.set(T, E.ts); return true; }
    return false;
  }

  const tell = changed => { try { window.postMessage({ source: 'sfdq-ext', type: 'synced', changed: !!changed }, location.origin); } catch (_) {} };
  let chain = Promise.resolve();
  const queue = fn => { chain = chain.then(fn).catch(() => {}); return chain; };

  // First sync, then let the web app start.
  queue(async () => {
    let changed = false;
    try { changed = await reconcile(); } catch (_) {}
    root.dataset.sfdqLink = 'ready';
    tell(changed);
  });

  // The web app reports its own changes while the page is open.
  window.addEventListener('message', ev => {
    if (ev.source !== window || ev.origin !== location.origin) return;
    const d = ev.data;
    if (!d || d.source !== 'sfdq-web' || d.type !== 'identity') return;
    const code = d.code ? norm(d.code) : '';
    if (code && !CODE_RE.test(code)) return;
    const ts = Number(d.changedAt) || Date.now();
    queue(async () => {
      if (code) {
        // Same code again means a profile edit on the web: blank the cached profile so the extension reloads it.
        const E = await readExt();
        await setExt(code, ts, E.code === code ? { ...E.lb, name: '', linkedin: '' } : null);
      }
      else await clearExt(ts);
    });
  });

  // Changes made in the extension while the page is open flow to the page.
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local' || !(ch.lb || ch.lbChangedAt || ch.lbSignedOut)) return;
      queue(async () => { const changed = await reconcile(); if (changed) tell(true); });
    });
  } catch (_) {}
})();
