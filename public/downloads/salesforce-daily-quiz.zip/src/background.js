// FocusQuest background worker.
// Owns every write to timer/stats/settings so concurrent tabs can't race each other.
importScripts('sites.js');

const HEARTBEAT_MS = 5000;          // content scripts ping this often
const MAX_CREDIT_MS = HEARTBEAT_MS + 1500; // never credit more than one beat per ping
const IDLE_SECONDS = 120;           // no input for 2 min and nothing playing => not watching
const HOLD_MS = 15 * 60000;         // after a pass the wall stays up (not counting) until the results screen is dismissed
const WEEK_MS = 7 * 864e5;

// ---------- storage helpers ----------
const get = keys => chrome.storage.local.get(keys);
const set = obj => chrome.storage.local.set(obj);

const freshTimer = (kind = 'base') => ({
  usedMs: 0, kind, locked: false, lockedAt: 0, lastTick: 0, cycleStart: Date.now(), warned: {},
  holdUntil: 0, failUntil: 0, emergencyUntil: 0, lastLockFailed: false, day: FQ_dayKey()
});
const freshStats = () => ({
  quizzesTaken: 0, quizzesPassed: 0, answered: 0, correct: 0, bestStreak: 0, xp: 0, unlocks: 0,
  byDay: {}, answeredByDay: {}, daily: {}, perSite: {}, history: [], achievements: {}, emergencyLog: [], imported: 0
});

// ---------- settings validation ----------
const clamp = (v, lo, hi, d) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const oneOf = (v, list, d) => list.includes(v) ? v : d;
const bool = (v, d) => typeof v === 'boolean' ? v : d;
const hhmm = (v, d) => /^([01]\d|2[0-3]):[0-5]\d$/.test(String(v)) ? v : d;

function sanitize(raw) {
  const D = FQ_DEFAULTS, s = { ...D, ...(raw || {}) };
  const customSites = (Array.isArray(s.customSites) ? s.customSites : []).map(c => {
    const host = FQ_normalizeHost((c && (c.hosts && c.hosts[0])) || c);
    if (!host || FQ_siteForHost(host)) return null; // skip junk and built-ins
    return { id: 'c:' + host, name: String((c && c.name) || host).slice(0, 40), emoji: String((c && c.emoji) || '').slice(0, 4), hosts: [host] };
  }).filter(Boolean).filter((c, i, a) => a.findIndex(x => x.id === c.id) === i).slice(0, 50);
  return {
    // Existing installs (settings already saved) keep the timer on; new installs start with it off.
    blockerOn: bool(s.blockerOn, raw && raw.limitMinutes !== undefined && raw.blockerOn === undefined ? true : D.blockerOn),
    limitMinutes: clamp(s.limitMinutes, 5, 240, D.limitMinutes),
    rewardMinutes: clamp(s.rewardMinutes, 5, 240, D.rewardMinutes),
    dailyReset: bool(s.dailyReset, D.dailyReset),
    warnAt: [15, 10, 5, 1].filter(m => (Array.isArray(s.warnAt) ? s.warnAt : D.warnAt).map(Number).includes(m)),
    toastPosition: oneOf(s.toastPosition, ['br', 'bl', 'tr', 'tl'], D.toastPosition),
    retryCooldown: clamp(s.retryCooldown, 0, 60, D.retryCooldown),
    emergencyPerWeek: clamp(s.emergencyPerWeek, 0, 7, D.emergencyPerWeek),
    emergencyMinutes: clamp(s.emergencyMinutes, 1, 30, D.emergencyMinutes),
    disabledSites: (Array.isArray(s.disabledSites) ? s.disabledSites : []).map(String).slice(0, 100),
    customSites,
    allowList: (Array.isArray(s.allowList) ? s.allowList : []).map(p => String(p).trim().slice(0, 200)).filter(Boolean).slice(0, 50),
    scheduleOn: bool(s.scheduleOn, D.scheduleOn),
    scheduleDays: [0, 1, 2, 3, 4, 5, 6].filter(d => (Array.isArray(s.scheduleDays) ? s.scheduleDays : []).map(Number).includes(d)),
    scheduleFrom: hhmm(s.scheduleFrom, D.scheduleFrom),
    scheduleTo: hhmm(s.scheduleTo, D.scheduleTo),
    questionsPerQuiz: clamp(s.questionsPerQuiz, 3, 60, D.questionsPerQuiz),
    passPercent: clamp(s.passPercent, 40, 100, D.passPercent),
    livesOn: bool(s.livesOn, D.livesOn),
    fiftyCount: clamp(s.fiftyCount, 0, 5, D.fiftyCount),
    skipCount: clamp(s.skipCount, 0, 5, D.skipCount),
    questionTimer: oneOf(Number(s.questionTimer), [0, 10, 15, 20, 30, 45, 60, 90, 120], D.questionTimer),
    difficulty: oneOf(s.difficulty, ['ramp', 'mixed', 'easy', 'hard'], D.difficulty),
    lockTopics: Array.isArray(s.lockTopics) && s.lockTopics.length ? s.lockTopics.map(String).slice(0, 200) : null,
    explanations: oneOf(s.explanations, ['always', 'wrong', 'never'], D.explanations),
    autoAdvance: bool(s.autoAdvance, D.autoAdvance),
    shuffleOptions: bool(s.shuffleOptions, D.shuffleOptions),
    bankSource: oneOf(s.bankSource, ['builtin', 'custom', 'both'], D.bankSource),
    displayName: String(s.displayName || '').slice(0, 40),
    why: String(s.why || '').slice(0, 240),
    dailyGoal: clamp(s.dailyGoal, 0, 500, D.dailyGoal),
    sound: bool(s.sound, D.sound)
  };
}
// Fields that are fine to change even while a quiz is due (they can't be used to skip it).
const ALWAYS_EDITABLE = ['displayName', 'why', 'dailyGoal', 'sound'];

async function load() {
  const s = await get(['settings', 'timer', 'stats']);
  return {
    settings: sanitize(s.settings),
    timer: { ...freshTimer(), ...(s.timer || {}) },
    stats: { ...freshStats(), ...(s.stats || {}) }
  };
}

// Serialize all state mutations through one promise chain.
let chain = Promise.resolve();
function locked(fn) {
  const run = chain.then(fn, fn);
  chain = run.catch(() => {});
  return run;
}

const limitMsOf = ({ settings, timer }) => (timer.kind === 'reward' ? settings.rewardMinutes : settings.limitMinutes) * 60000;
const emergencyLeft = (settings, stats, now = Date.now()) =>
  Math.max(0, settings.emergencyPerWeek - (stats.emergencyLog || []).filter(t => now - t < WEEK_MS).length);

// Refill at midnight when the user asked for it. Mutates state; returns true if something changed.
function dailyRollover(state) {
  const today = FQ_dayKey();
  if (state.timer.day === today) return false;
  if (!state.settings.dailyReset) { state.timer.day = today; return true; }
  const wasLocked = state.timer.locked;
  state.timer = freshTimer('base');
  if (wasLocked) broadcast({ type: 'fq:unlock' });
  return true;
}

// ---------- badge ----------
async function paintBadge(state) {
  const st = state || await load();
  const { settings, timer } = st;
  const now = Date.now();
  let text, color;
  if (!settings.blockerOn) { const done = (st.stats.daily || {})[FQ_dayKey(now)]; text = done ? '' : '1'; color = '#0176d3'; }
  else if (!FQ_inSchedule(settings, now)) { text = 'off'; color = '#6b7280'; }
  else if (timer.emergencyUntil > now) { text = Math.ceil((timer.emergencyUntil - now) / 60000) + 'm'; color = '#ff9f1c'; }
  else if (timer.locked) { text = 'QUIZ'; color = '#ff4d6d'; }
  else {
    const remainMin = Math.max(0, Math.ceil((limitMsOf(st) - timer.usedMs) / 60000));
    text = remainMin + 'm'; color = remainMin <= 5 ? '#ff9f1c' : '#7c5cff';
  }
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
}

// ---------- broadcast ----------
async function broadcast(msg) {
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) chrome.tabs.sendMessage(t.id, msg).catch(() => {});
}

function publicState(state) {
  const { settings, timer, stats } = state;
  const now = Date.now();
  const limitMs = limitMsOf(state);
  return {
    locked: timer.locked,
    usedMs: timer.usedMs,
    limitMs,
    remainingMs: Math.max(0, limitMs - timer.usedMs),
    kind: timer.kind,
    inSchedule: FQ_inSchedule(settings, now),
    emergencyUntil: timer.emergencyUntil > now ? timer.emergencyUntil : 0,
    emergencyLeft: emergencyLeft(settings, stats, now),
    failUntil: timer.failUntil > now ? timer.failUntil : 0,
    settings
  };
}

// Why a given tab should not be counted right now (or null if it should).
function exemptReason(settings, siteId, url) {
  if (!settings.blockerOn) return 'off';
  if (!siteId || settings.disabledSites.includes(siteId)) return 'disabled';
  if (siteId.startsWith('c:') && !settings.customSites.some(c => c.id === siteId)) return 'disabled';
  if (!FQ_inSchedule(settings)) return 'schedule';
  if (FQ_urlAllowed(url, settings.allowList)) return 'allowed';
  return null;
}

// ---------- core ----------
async function onHeartbeat({ siteId, url, mediaPlaying, visible }) {
  return locked(async () => {
    const state = await load();
    const rolled = dailyRollover(state);
    const { settings, timer, stats } = state;
    const why = exemptReason(settings, siteId, url);
    if (why) { if (rolled) await set({ timer }); return { tracked: false, why }; }
    const now = Date.now();
    const inEmergency = timer.emergencyUntil > now;
    if (timer.locked && !inEmergency) { if (rolled) await set({ timer }); return { tracked: true, ...publicState(state) }; }
    if (timer.holdUntil > now) return { tracked: true, hold: true, ...publicState(state) };

    // Not visible and nothing audible => not consuming. Visible but user idle and no media => not consuming.
    let counting = visible || mediaPlaying;
    if (counting && !mediaPlaying) {
      const idle = await chrome.idle.queryState(IDLE_SECONDS);
      if (idle !== 'active') counting = false;
    }

    let warn = null;
    if (counting) {
      // Credit only the time since the previous ping (from ANY tab), so two open tabs don't double count.
      const credit = timer.lastTick ? Math.min(Math.max(0, now - timer.lastTick), MAX_CREDIT_MS) : HEARTBEAT_MS;
      timer.lastTick = now;
      timer.usedMs += credit;
      const dk = FQ_dayKey(now);
      stats.byDay[dk] = (stats.byDay[dk] || 0) + credit;
      stats.perSite[siteId] = (stats.perSite[siteId] || 0) + credit;
      const days = Object.keys(stats.byDay).sort();
      while (days.length > 90) delete stats.byDay[days.shift()];

      const limitMs = limitMsOf(state);
      const remaining = limitMs - timer.usedMs;
      if (!inEmergency) {
        for (const m of settings.warnAt) {
          if (remaining <= m * 60000 && remaining > 0 && !timer.warned[m] && limitMs > m * 60000) {
            timer.warned[m] = true;
            warn = warn || m;
          }
        }
      }
      if (remaining <= 0 && !inEmergency) {
        timer.locked = true;
        timer.lockedAt = timer.lockedAt || now;
      }
    }
    if (!inEmergency && timer.emergencyUntil && timer.usedMs >= limitMsOf(state)) {
      timer.emergencyUntil = 0; timer.locked = true; // pass expired
    }

    await set({ timer, stats });
    if (timer.locked && !(timer.emergencyUntil > now)) broadcast({ type: 'fq:lock' });
    paintBadge(state);
    return { tracked: true, warn, ...publicState(state), locked: timer.locked && !(timer.emergencyUntil > now) };
  });
}

async function onCheck({ siteId, url }) {
  const state = await load();
  const why = exemptReason(state.settings, siteId, url);
  const now = Date.now();
  const lock = !why && state.timer.locked && !(state.timer.emergencyUntil > now);
  return { lock, hold: !why && state.timer.holdUntil > now, why, prefs: (await get('prefs')).prefs || {}, settings: state.settings };
}

async function onQuizFinished(msg) {
  const { mode, score, total, answered, results, bestStreak, xp } = msg;
  return locked(async () => {
    const state = await load();
    const { settings, timer, stats } = state;
    const { qstats = {} } = await get('qstats');
    const now = Date.now();

    for (const r of results || []) {
      const q = qstats[r.id] || { seen: 0, correct: 0, last: 0 };
      q.seen++; if (r.correct) q.correct++; q.last = now;
      qstats[r.id] = q;
    }
    const passed = total > 0 && score >= Math.ceil(total * settings.passPercent / 100);
    const lock = mode === 'lock';
    const prevLockFailed = !!timer.lastLockFailed;
    const dk = FQ_dayKey(now);
    const beforeToday = stats.answeredByDay[dk] || 0;

    stats.quizzesTaken++;
    if (passed && lock) stats.quizzesPassed++;
    stats.answered += answered ?? total;
    stats.correct += score;
    stats.bestStreak = Math.max(stats.bestStreak || 0, bestStreak || 0);
    stats.xp = (stats.xp || 0) + Math.max(0, Math.round(xp || 0));
    stats.answeredByDay[dk] = beforeToday + (answered ?? total);
    const ad = Object.keys(stats.answeredByDay).sort();
    while (ad.length > 400) delete stats.answeredByDay[ad.shift()];
    stats.history.push({ at: now, score, total, passed, mode });
    if (mode === 'daily' && !(stats.daily || {})[dk]) {
      stats.daily = { ...(stats.daily || {}), [dk]: { score, total } };
      const dd = Object.keys(stats.daily).sort(); while (dd.length > 400) delete stats.daily[dd.shift()];
    }
    if (stats.history.length > 200) stats.history = stats.history.slice(-200);

    let unlocked = false;
    if (lock && passed && timer.locked) {
      state.timer = Object.assign(freshTimer('reward'), { holdUntil: now + HOLD_MS });
      stats.unlocks++;
      unlocked = true;
    } else if (lock && !passed) {
      timer.lastLockFailed = true;
      timer.failUntil = settings.retryCooldown ? now + settings.retryCooldown * 60000 : 0;
    }

    // achievements
    const goal = settings.dailyGoal;
    const round = {
      lock, passed, score, total, bestStreak: bestStreak || 0, livesOn: !!msg.livesOn, livesLeft: msg.livesLeft,
      lifelines: msg.lifelines || 0, speedy: msg.speedy || 0,
      topicsRight: new Set((results || []).filter(r => r.correct && r.topic).map(r => r.topic)).size
    };
    const ctx = {
      stats, round, now, prevLockFailed,
      goalHit: goal > 0 && stats.answeredByDay[dk] >= goal,
      dayStreak: FQ_dayStreak(stats.answeredByDay, goal)
    };
    const fresh = [];
    for (const a of FQ_ACHIEVEMENTS) {
      if (stats.achievements[a.id]) continue;
      try { if (a.check(ctx)) { stats.achievements[a.id] = now; fresh.push(a.id); } } catch (_) {}
    }

    await set({ timer: state.timer, stats, qstats, activeQuiz: null });
    paintBadge(state);
    return { passed, unlocked, achievements: fresh, goalJustHit: goal > 0 && beforeToday < goal && ctx.goalHit, ...publicState(state) };
  });
}

async function onSaveSettings(patch) {
  return locked(async () => {
    const state = await load();
    const p = { ...(patch || {}) };
    if (state.timer.locked) {
      for (const k of Object.keys(p)) if (!ALWAYS_EDITABLE.includes(k)) delete p[k];
      if (!Object.keys(p).length) return { ok: false, reason: 'Settings are frozen while you owe a quiz ' };
    }
    const before = state.settings;
    const settings = sanitize({ ...before, ...p });
    const timer = state.timer;
    if (!timer.locked && timer.usedMs >= limitMsOf({ settings, timer }) && FQ_inSchedule(settings)) {
      timer.locked = true;
      timer.lockedAt = Date.now();
    }
    await set({ settings, timer });
    if (JSON.stringify(before.customSites) !== JSON.stringify(settings.customSites)) await syncCustomScripts(settings);
    const next = { ...state, settings, timer };
    if (timer.locked) broadcast({ type: 'fq:lock' });
    broadcast({ type: 'fq:settings' });
    paintBadge(next);
    return { ok: true, partial: Object.keys(p).length !== Object.keys(patch || {}).length, ...publicState(next) };
  });
}

async function onEmergency() {
  return locked(async () => {
    const state = await load();
    const { settings, timer, stats } = state;
    const now = Date.now();
    if (!timer.locked) return { ok: false, reason: 'Nothing to unlock.' };
    if (emergencyLeft(settings, stats, now) <= 0) return { ok: false, reason: 'No emergency passes left this week.' };
    stats.emergencyLog = [...(stats.emergencyLog || []).filter(t => now - t < WEEK_MS), now];
    timer.emergencyUntil = now + settings.emergencyMinutes * 60000;
    timer.lastTick = 0;
    await set({ timer, stats });
    broadcast({ type: 'fq:unlock' });
    paintBadge(state);
    return { ok: true, ...publicState(state) };
  });
}

// ---------- custom sites (optional host permissions + dynamic content scripts) ----------
async function syncCustomScripts(settingsArg) {
  if (!chrome.scripting || !chrome.scripting.registerContentScripts) return;
  const settings = settingsArg || (await load()).settings;
  const matches = [];
  for (const c of settings.customSites) {
    for (const h of c.hosts) {
      const pats = [`*://${h}/*`, `*://*.${h}/*`];
      try { if (await chrome.permissions.contains({ origins: pats })) matches.push(...pats); } catch (_) {}
    }
  }
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: ['fq-custom'] });
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: ['fq-custom'] });
    if (matches.length) {
      await chrome.scripting.registerContentScripts([{
        id: 'fq-custom', matches, js: ['src/sites.js', 'src/themes.js', 'src/content.js'], runAt: 'document_start', persistAcrossSessions: true
      }]);
      // Start tracking tabs that are already open on those sites.
      const tabs = await chrome.tabs.query({ url: matches });
      for (const t of tabs) {
        chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['src/sites.js', 'src/themes.js', 'src/content.js'] }).catch(() => {});
      }
    }
  } catch (e) { console.warn('FocusQuest: custom site scripts', e); }
}

// ---------- backups ----------
const BACKUP_KEYS = ['settings', 'prefs', 'stats', 'qstats', 'starred', 'customBank'];
async function onExport() {
  const data = await get(BACKUP_KEYS);
  return { app: 'FocusQuest', version: chrome.runtime.getManifest().version, exportedAt: new Date().toISOString(), data };
}
async function onImport({ backup }) {
  return locked(async () => {
    const state = await load();
    if (state.timer.locked) return { ok: false, reason: 'Pass the pending quiz before restoring a backup.' };
    const d = backup && backup.data;
    if (!d || typeof d !== 'object') return { ok: false, reason: 'That file is not a FocusQuest backup.' };
    const out = {};
    if (d.settings) out.settings = sanitize(d.settings);
    if (d.prefs) out.prefs = { ...FQ_PREFS, ...d.prefs };
    if (d.stats) out.stats = { ...freshStats(), ...d.stats };
    if (d.qstats) out.qstats = d.qstats;
    if (Array.isArray(d.starred)) out.starred = d.starred.map(String);
    if (Array.isArray(d.customBank)) out.customBank = d.customBank;
    await set(out);
    if (out.settings) await syncCustomScripts(out.settings);
    paintBadge();
    return { ok: true, keys: Object.keys(out) };
  });
}
async function onReset({ scope }) {
  return locked(async () => {
    const state = await load();
    if (state.timer.locked) return { ok: false, reason: 'Pass the pending quiz first.' };
    if (scope === 'progress') await set({ stats: freshStats(), qstats: {}, starred: [] });
    else if (scope === 'all') {
      await chrome.storage.local.clear();
      await set({ settings: sanitize({}), prefs: { ...FQ_PREFS }, timer: freshTimer(), stats: freshStats() });
      await syncCustomScripts(sanitize({}));
    }
    paintBadge();
    return { ok: true };
  });
}
async function onSetCustomBank({ bank }) {
  return locked(async () => {
    const state = await load();
    if (state.timer.locked) return { ok: false, reason: 'Question banks are frozen while a quiz is due.' };
    const list = Array.isArray(bank) ? bank.slice(0, 5000) : [];
    const stats = state.stats;
    if (list.length) stats.imported = (stats.imported || 0) + 1;
    if (list.length && !stats.achievements.author) stats.achievements.author = Date.now();
    await set({ customBank: list, stats });
    return { ok: true, count: list.length };
  });
}

// ---------- wiring ----------
const openPage = path => chrome.tabs.create({ url: chrome.runtime.getURL(path) });

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const handlers = {
    'fq:heartbeat': () => onHeartbeat(msg),
    'fq:check': () => onCheck(msg),
    'fq:state': () => locked(async () => {
      const s = await load();
      if (dailyRollover(s)) await set({ timer: s.timer });
      return { ...publicState(s), stats: s.stats };
    }),
    'fq:quizFinished': () => onQuizFinished(msg),
    'fq:saveSettings': () => onSaveSettings(msg.settings || {}),
    'fq:emergency': () => onEmergency(),
    'fq:release': () => locked(async () => {
      const state = await load();
      state.timer.holdUntil = 0;
      state.timer.lastTick = 0;
      await set({ timer: state.timer });
      broadcast({ type: 'fq:unlock' });
      paintBadge(state);
      return { ok: true };
    }),
    'fq:openPractice': async () => { await openPage('src/quiz.html?mode=practice' + (msg.query ? '&' + msg.query : '')); return { ok: true }; },
    'fq:openOptions': async () => { await chrome.runtime.openOptionsPage(); return { ok: true }; },
    'fq:syncSites': async () => { await syncCustomScripts(); return { ok: true }; },
    'fq:export': () => onExport(),
    'fq:import': () => onImport(msg),
    'fq:reset': () => onReset(msg),
    'fq:setCustomBank': () => onSetCustomBank(msg)
  };
  const h = handlers[msg && msg.type];
  if (!h) return false;
  Promise.resolve(h()).then(reply, err => reply({ error: String(err) }));
  return true; // async reply
});

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  const s = await get(['settings', 'timer', 'stats', 'prefs']);
  await set({
    settings: sanitize(s.settings),
    timer: { ...freshTimer(), ...(s.timer || {}) },
    stats: { ...freshStats(), ...(s.stats || {}) },
    prefs: { ...FQ_PREFS, ...(s.prefs || {}) }
  });
  chrome.alarms.create('fq:badge', { periodInMinutes: 1 });
  paintBadge();
  syncCustomScripts();
  if (reason === 'install') openPage('src/quiz.html?mode=welcome');
  if (reason === 'update') openPage('src/quiz.html?mode=daily');
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('fq:badge', { periodInMinutes: 1 });
  paintBadge();
});

chrome.alarms.onAlarm.addListener(a => {
  if (a.name !== 'fq:badge') return;
  locked(async () => {
    const s = await load();
    if (dailyRollover(s)) await set({ timer: s.timer });
    paintBadge(s);
  });
});

chrome.commands && chrome.commands.onCommand.addListener(cmd => {
  if (cmd === 'open-practice') openPage('src/quiz.html?mode=practice');
  if (cmd === 'open-options') chrome.runtime.openOptionsPage();
});
