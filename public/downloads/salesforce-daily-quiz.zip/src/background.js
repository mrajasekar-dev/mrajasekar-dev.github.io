// FocusQuest background worker.
// Owns every write to timer/stats/settings so concurrent tabs can't race each other.
importScripts('sites.js');

const HEARTBEAT_MS = 5000;          // content scripts ping this often
const MAX_CREDIT_MS = HEARTBEAT_MS + 1500; // never credit more than one beat per ping
const IDLE_SECONDS = 120;           // no input for 2 min and nothing playing => not watching
const HOLD_MS = 15 * 60000;         // after a pass the wall stays up (not counting) until the results screen is dismissed
const WEEK_MS = 7 * 864e5;
const QSTATS_CAP = 2000;           // seen/missed question ids kept on this device (ids only)
const STARRED_CAP = 500;

// ---------- storage helpers ----------
const get = keys => chrome.storage.local.get(keys);
const set = obj => chrome.storage.local.set(obj);

const freshTimer = (kind = 'base') => ({
  usedMs: 0, kind, locked: false, lockedAt: 0, lastTick: 0, cycleStart: Date.now(), warned: {},
  holdUntil: 0, lockSet: null, lastLockFailed: false, day: FQ_dayKey()
});
// Old builds kept emergencyUntil / failUntil on the timer and customBank imports beside it; those no longer exist.
const cleanTimer = t => { const o = { ...freshTimer(), ...(t || {}) }; delete o.emergencyUntil; delete o.failUntil; return o; };
const cleanLockSet = ls => {
  if (!ls || typeof ls !== 'object' || !/^[A-Za-z0-9_-]{6,64}$/.test(String(ls.seed || ''))) return null;
  return {
    seed: String(ls.seed), n: clamp(ls.n, 1, 50, 10), extra: clamp(ls.extra, 0, 5, 0),
    topics: Array.isArray(ls.topics) && ls.topics.length ? ls.topics.map(String).slice(0, 60) : null,
    difficulty: oneOf(ls.difficulty, ['any', 'easy', 'medium', 'hard'], 'any')
  };
};
const freshStats = () => ({
  quizzesTaken: 0, quizzesPassed: 0, answered: 0, correct: 0, bestStreak: 0, xp: 0, unlocks: 0,
  byDay: {}, answeredByDay: {}, daily: {}, perSite: {}, history: [], achievements: {}, emergencyLog: [], outageLog: []
});

// ---------- settings validation ----------
const clamp = (v, lo, hi, d) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const oneOf = (v, list, d) => list.includes(v) ? v : d;
const bool = (v, d) => typeof v === 'boolean' ? v : d;
const hhmm = (v, d) => /^([01]\d|2[0-3]):[0-5]\d$/.test(String(v)) ? v : d;

function sanitize(raw) {
  const D = FQ_DEFAULTS, s = { ...D, ...(raw || {}) };
  const customSites = (Array.isArray(s.customSites) ? s.customSites : []).map(c => {
    const host = FQ_normalizeHost((c && (c.hosts && c.hosts[0])) || c);
    if (!host || FQ_siteForHost(host)) return null; // skip junk and built-ins
    return { id: 'c:' + host, name: String((c && c.name) || host).slice(0, 40), emoji: String((c && c.emoji) || '').slice(0, 4), hosts: [host] };
  }).filter(Boolean).filter((c, i, a) => a.findIndex(x => x.id === c.id) === i).slice(0, 50);
  return {
    // Existing installs (settings already saved) keep the timer on; new installs start with it off.
    blockerOn: bool(s.blockerOn, raw && raw.limitMinutes !== undefined && raw.blockerOn === undefined ? true : D.blockerOn),
    limitMinutes: clamp(s.limitMinutes, 5, 240, D.limitMinutes),
    rewardMinutes: clamp(s.rewardMinutes, 5, 240, D.rewardMinutes),
    dailyReset: bool(s.dailyReset, D.dailyReset),
    warnAt: [15, 10, 5, 1].filter(m => (Array.isArray(s.warnAt) ? s.warnAt : D.warnAt).map(Number).includes(m)),
    toastPosition: oneOf(s.toastPosition, ['br', 'bl', 'tr', 'tl'], D.toastPosition),
    emergencyPerWeek: clamp(s.emergencyPerWeek, 0, 7, D.emergencyPerWeek),
    disabledSites: (Array.isArray(s.disabledSites) ? s.disabledSites : []).map(String).slice(0, 100),
    customSites,
    allowList: (Array.isArray(s.allowList) ? s.allowList : []).map(p => String(p).trim().slice(0, 200)).filter(Boolean).slice(0, 50),
    scheduleOn: bool(s.scheduleOn, D.scheduleOn),
    scheduleDays: [0, 1, 2, 3, 4, 5, 6].filter(d => (Array.isArray(s.scheduleDays) ? s.scheduleDays : []).map(Number).includes(d)),
    scheduleFrom: hhmm(s.scheduleFrom, D.scheduleFrom),
    scheduleTo: hhmm(s.scheduleTo, D.scheduleTo),
    questionsPerQuiz: clamp(s.questionsPerQuiz, 3, 50, D.questionsPerQuiz),
    passPercent: clamp(s.passPercent, 40, 100, D.passPercent),
    livesOn: bool(s.livesOn, D.livesOn),
    fiftyCount: clamp(s.fiftyCount, 0, 5, D.fiftyCount),
    skipCount: clamp(s.skipCount, 0, 5, D.skipCount),
    questionTimer: oneOf(Number(s.questionTimer), [0, 10, 15, 20, 30, 45, 60, 90, 120], D.questionTimer),
    difficulty: oneOf(s.difficulty, ['ramp', 'mixed', 'easy', 'hard'], D.difficulty),
    lockTopics: Array.isArray(s.lockTopics) && s.lockTopics.length ? s.lockTopics.map(String).slice(0, 200) : null,
    displayName: String(s.displayName || '').slice(0, 40),
    why: String(s.why || '').slice(0, 240),
    dailyGoal: clamp(s.dailyGoal, 0, 500, D.dailyGoal),
    sound: bool(s.sound, D.sound)
  };
}
// Fields that are fine to change even while a quiz is due (they can't be used to skip it).
const ALWAYS_EDITABLE = ['displayName', 'why', 'dailyGoal', 'sound'];

async function load() {
  const s = await get(['settings', 'timer', 'stats']);
  return {
    settings: sanitize(s.settings),
    timer: { ...cleanTimer(s.timer), lockSet: cleanLockSet((s.timer || {}).lockSet) },
    stats: { ...freshStats(), ...(s.stats || {}) }
  };
}

// Serialize all state mutations through one promise chain.
let chain = Promise.resolve();
function locked(fn) {
  const run = chain.then(fn, fn);
  chain = run.catch(() => {});
  return run;
}

const limitMsOf = ({ settings, timer }) => (timer.kind === 'reward' ? settings.rewardMinutes : settings.limitMinutes) * 60000;
const emergencyLeft = (settings, stats, now = Date.now()) =>
  Math.max(0, settings.emergencyPerWeek - (stats.emergencyLog || []).filter(t => now - t < WEEK_MS).length);

// Refill at midnight when the user asked for it. Mutates state; returns true if something changed.
function dailyRollover(state) {
  const today = FQ_dayKey();
  if (state.timer.day === today) return false;
  if (!state.settings.dailyReset) { state.timer.day = today; return true; }
  const wasLocked = state.timer.locked;
  state.timer = freshTimer('base');
  if (wasLocked) broadcast({ type: 'fq:unlock' });
  return true;
}

// ---------- badge ----------
async function paintBadge(state) {
  const st = state || await load();
  const { settings, timer } = st;
  const now = Date.now();
  let text, color;
  if (!settings.blockerOn) { const done = (st.stats.daily || {})[FQ_utcDay(now)]; text = done ? '' : '1'; color = '#3a7bff'; }
  else if (!FQ_inSchedule(settings, now)) { text = 'off'; color = '#6b7280'; }
  else if (timer.locked) { text = 'QUIZ'; color = '#ff4d6d'; }
  else {
    const remainMin = Math.max(0, Math.ceil((limitMsOf(st) - timer.usedMs) / 60000));
    text = remainMin + 'm'; color = remainMin <= 5 ? '#ff9f1c' : '#7c5cff';
  }
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
}

// ---------- broadcast ----------
async function broadcast(msg) {
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) chrome.tabs.sendMessage(t.id, msg).catch(() => {});
}

function publicState(state) {
  const { settings, timer, stats } = state;
  const now = Date.now();
  const limitMs = limitMsOf(state);
  return {
    locked: timer.locked,
    usedMs: timer.usedMs,
    limitMs,
    remainingMs: Math.max(0, limitMs - timer.usedMs),
    kind: timer.kind,
    inSchedule: FQ_inSchedule(settings, now),
    emergencyLeft: emergencyLeft(settings, stats, now),
    lockSet: timer.lockSet || null,
    settings
  };
}

// Why a given tab should not be counted right now (or null if it should).
function exemptReason(settings, siteId, url) {
  if (!settings.blockerOn) return 'off';
  if (!siteId || settings.disabledSites.includes(siteId)) return 'disabled';
  if (siteId.startsWith('c:') && !settings.customSites.some(c => c.id === siteId)) return 'disabled';
  if (!FQ_inSchedule(settings)) return 'schedule';
  if (FQ_urlAllowed(url, settings.allowList)) return 'allowed';
  return null;
}

// ---------- core ----------
async function onHeartbeat({ siteId, url, mediaPlaying, visible }) {
  return locked(async () => {
    const state = await load();
    const rolled = dailyRollover(state);
    const { settings, timer, stats } = state;
    const why = exemptReason(settings, siteId, url);
    if (why) { if (rolled) await set({ timer }); return { tracked: false, why }; }
    const now = Date.now();
    if (timer.locked) { if (rolled) await set({ timer }); return { tracked: true, ...publicState(state) }; }
    if (timer.holdUntil > now) return { tracked: true, hold: true, ...publicState(state) };

    // Not visible and nothing audible => not consuming. Visible but user idle and no media => not consuming.
    let counting = visible || mediaPlaying;
    if (counting && !mediaPlaying) {
      const idle = await chrome.idle.queryState(IDLE_SECONDS);
      if (idle !== 'active') counting = false;
    }

    let warn = null;
    if (counting) {
      // Credit only the time since the previous ping (from ANY tab), so two open tabs don't double count.
      const credit = timer.lastTick ? Math.min(Math.max(0, now - timer.lastTick), MAX_CREDIT_MS) : HEARTBEAT_MS;
      timer.lastTick = now;
      timer.usedMs += credit;
      const dk = FQ_dayKey(now);
      stats.byDay[dk] = (stats.byDay[dk] || 0) + credit;
      stats.perSite[siteId] = (stats.perSite[siteId] || 0) + credit;
      const days = Object.keys(stats.byDay).sort();
      while (days.length > 90) delete stats.byDay[days.shift()];

      const limitMs = limitMsOf(state);
      const remaining = limitMs - timer.usedMs;
      for (const m of settings.warnAt) {
        if (remaining <= m * 60000 && remaining > 0 && !timer.warned[m] && limitMs > m * 60000) {
          timer.warned[m] = true;
          warn = warn || m;
        }
      }
      if (remaining <= 0) {
        timer.locked = true;
        timer.lockedAt = timer.lockedAt || now;
      }
    }

    await set({ timer, stats });
    if (timer.locked) broadcast({ type: 'fq:lock' });
    paintBadge(state);
    return { tracked: true, warn, ...publicState(state) };
  });
}

async function onCheck({ siteId, url }) {
  const state = await load();
  const why = exemptReason(state.settings, siteId, url);
  const now = Date.now();
  const lock = !why && state.timer.locked;
  return { lock, hold: !why && state.timer.holdUntil > now, why, prefs: (await get('prefs')).prefs || {}, settings: state.settings };
}

async function onQuizFinished(msg) {
  const { mode, score, total, answered, results, bestStreak, xp } = msg;
  return locked(async () => {
    const state = await load();
    const { settings, timer, stats } = state;
    const { qstats = {} } = await get('qstats');
    const now = Date.now();

    // Question ids only (never text), capped so storage stays small. `miss` is true while the latest answer was wrong.
    for (const r of results || []) {
      if (!r || typeof r.id !== 'string' || r.id.length > 64) continue;
      const q = qstats[r.id] || { seen: 0, correct: 0, last: 0 };
      q.seen++; if (r.correct) q.correct++; q.last = now; q.miss = !r.correct;
      if (r.topic) q.topic = String(r.topic).slice(0, 60);   // topic name only, for the Progress page
      qstats[r.id] = q;
    }
    const qkeys = Object.keys(qstats);
    if (qkeys.length > QSTATS_CAP) qkeys.sort((a, b) => (qstats[a].last || 0) - (qstats[b].last || 0)).slice(0, qkeys.length - QSTATS_CAP).forEach(k => delete qstats[k]);
    const passed = total > 0 && score >= Math.ceil(total * settings.passPercent / 100);
    const lock = mode === 'lock';
    const prevLockFailed = !!timer.lastLockFailed;
    const dk = FQ_dayKey(now);
    const beforeToday = stats.answeredByDay[dk] || 0;

    stats.quizzesTaken++;
    if (passed && lock) stats.quizzesPassed++;
    stats.answered += answered ?? total;
    stats.correct += score;
    stats.bestStreak = Math.max(stats.bestStreak || 0, bestStreak || 0);
    stats.xp = (stats.xp || 0) + Math.max(0, Math.round(xp || 0));
    stats.answeredByDay[dk] = beforeToday + (answered ?? total);
    const ad = Object.keys(stats.answeredByDay).sort();
    while (ad.length > 400) delete stats.answeredByDay[ad.shift()];
    stats.history.push({ at: now, score, total, passed, mode });
    // The daily challenge is keyed by UTC day. A ranked (server) run reports its own day and may replace an unranked offline run.
    const udk = mode === 'daily' && /^\d{4}-\d{2}-\d{2}$/.test(String(msg.day || '')) ? msg.day : FQ_utcDay(now);
    const prevDaily = (stats.daily || {})[udk];
    if (mode === 'daily' && (!prevDaily || (msg.ranked && !prevDaily.ranked))) {
      const rec = { score, total, grid: String(msg.grid || '').slice(0, 60) };
      if (msg.ranked) {
        rec.ranked = true; rec.flagged = !!msg.flagged;
        if (Number.isFinite(msg.timeMs)) rec.timeMs = msg.timeMs;
        if (Number.isFinite(msg.rank)) rec.rank = msg.rank;
        if (Number.isFinite(msg.players)) rec.players = msg.players;
        if (Number.isFinite(msg.percentile)) rec.percentile = msg.percentile;
      }
      stats.daily = { ...(stats.daily || {}), [udk]: rec };
      const dd = Object.keys(stats.daily).sort(); while (dd.length > 400) delete stats.daily[dd.shift()];
    }
    if (stats.history.length > 200) stats.history = stats.history.slice(-200);

    let unlocked = false;
    if (lock && passed && timer.locked) {
      state.timer = Object.assign(freshTimer('reward'), { holdUntil: now + HOLD_MS });
      stats.unlocks++;
      unlocked = true;
    } else if (lock && !passed) {
      timer.lastLockFailed = true;   // lockSet stays: a retry gets the same questions until the quiz is passed
    }

    // achievements
    const goal = settings.dailyGoal;
    const round = {
      lock, passed, score, total, bestStreak: bestStreak || 0, livesOn: !!msg.livesOn, livesLeft: msg.livesLeft,
      lifelines: msg.lifelines || 0, speedy: msg.speedy || 0,
      topicsRight: new Set((results || []).filter(r => r.correct && r.topic).map(r => r.topic)).size
    };
    const ctx = {
      stats, round, now, prevLockFailed,
      goalHit: goal > 0 && stats.answeredByDay[dk] >= goal,
      dayStreak: FQ_dayStreak(stats.answeredByDay, goal)
    };
    const fresh = [];
    for (const a of FQ_ACHIEVEMENTS) {
      if (stats.achievements[a.id]) continue;
      try { if (a.check(ctx)) { stats.achievements[a.id] = now; fresh.push(a.id); } } catch (_) {}
    }

    await set({ timer: state.timer, stats, qstats, activeQuiz: null });
    paintBadge(state);
    return { passed, unlocked, achievements: fresh, goalJustHit: goal > 0 && beforeToday < goal && ctx.goalHit, ...publicState(state) };
  });
}

async function onSaveSettings(patch) {
  return locked(async () => {
    const state = await load();
    const p = { ...(patch || {}) };
    if (state.timer.locked) {
      for (const k of Object.keys(p)) if (!ALWAYS_EDITABLE.includes(k)) delete p[k];
      if (!Object.keys(p).length) return { ok: false, reason: 'Settings are frozen while you owe a quiz ' };
    }
    const before = state.settings;
    const settings = sanitize({ ...before, ...p });
    const timer = state.timer;
    if (!timer.locked && timer.usedMs >= limitMsOf({ settings, timer }) && FQ_inSchedule(settings)) {
      timer.locked = true;
      timer.lockedAt = Date.now();
    }
    await set({ settings, timer });
    if (JSON.stringify(before.customSites) !== JSON.stringify(settings.customSites)) await syncCustomScripts(settings);
    const next = { ...state, settings, timer };
    if (timer.locked) broadcast({ type: 'fq:lock' });
    broadcast({ type: 'fq:settings' });
    paintBadge(next);
    return { ok: true, partial: Object.keys(p).length !== Object.keys(patch || {}).length, ...publicState(next) };
  });
}

// Unlock exactly as a passed quiz does: fresh reward allowance, usage reset, lockSet cleared. No hold screen: nothing to dismiss.
function grantUnlock(state) {
  state.timer = freshTimer('reward');
  broadcast({ type: 'fq:unlock' });
}

async function onEmergency() {
  return locked(async () => {
    const state = await load();
    const { settings, timer, stats } = state;
    const now = Date.now();
    if (!timer.locked) return { ok: false, reason: 'Nothing to unlock.' };
    if (emergencyLeft(settings, stats, now) <= 0) return { ok: false, reason: 'No emergency passes left this week.' };
    stats.emergencyLog = [...(stats.emergencyLog || []).filter(t => now - t < WEEK_MS), now];
    grantUnlock(state);
    await set({ timer: state.timer, stats, activeQuiz: null });
    paintBadge(state);
    return { ok: true, ...publicState(state) };
  });
}

// The unlock quiz could not load questions (server unreachable): unlock without using an emergency pass. Logged, never counted as a pass.
async function onOutageSkip() {
  return locked(async () => {
    const state = await load();
    const { timer, stats } = state;
    if (!timer.locked) return { ok: false, reason: 'Nothing to unlock.' };
    const now = Date.now();
    if ((stats.outageLog || []).filter(t => now - t < 864e5).length >= 2) return { ok: false, reason: 'You have used this twice in the last day. Retry in a while, or use an emergency pass.' };
    stats.outageLog = [...(stats.outageLog || []), now].slice(-50);
    grantUnlock(state);
    await set({ timer: state.timer, stats, activeQuiz: null });
    paintBadge(state);
    return { ok: true, ...publicState(state) };
  });
}

// First load of an unlock quiz stores the question set (seed and filters, never text); a retry reuses it until the quiz is passed.
async function onLockSet(msg) {
  return locked(async () => {
    const state = await load();
    if (!state.timer.locked) return { ok: false, lockSet: null };
    if (!state.timer.lockSet) {
      const ls = cleanLockSet(msg.lockSet);
      if (!ls) return { ok: false, lockSet: null };
      state.timer.lockSet = ls;
      await set({ timer: state.timer });
    }
    return { ok: true, lockSet: state.timer.lockSet };
  });
}

// ---------- custom sites (optional host permissions + dynamic content scripts) ----------
async function syncCustomScripts(settingsArg) {
  if (!chrome.scripting || !chrome.scripting.registerContentScripts) return;
  const settings = settingsArg || (await load()).settings;
  const matches = [];
  for (const c of settings.customSites) {
    for (const h of c.hosts) {
      const pats = [`*://${h}/*`, `*://*.${h}/*`];
      try { if (await chrome.permissions.contains({ origins: pats })) matches.push(...pats); } catch (_) {}
    }
  }
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: ['fq-custom'] });
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: ['fq-custom'] });
    if (matches.length) {
      await chrome.scripting.registerContentScripts([{
        id: 'fq-custom', matches, js: ['src/sites.js', 'src/themes.js', 'src/content.js'], runAt: 'document_start', persistAcrossSessions: true
      }]);
      // Start tracking tabs that are already open on those sites.
      const tabs = await chrome.tabs.query({ url: matches });
      for (const t of tabs) {
        chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['src/sites.js', 'src/themes.js', 'src/content.js'] }).catch(() => {});
      }
    }
  } catch (e) { console.warn('FocusQuest: custom site scripts', e); }
}

// ---------- backups ----------
const BACKUP_KEYS = ['settings', 'prefs', 'stats', 'qstats', 'starred'];
async function onExport() {
  const data = await get(BACKUP_KEYS);
  return { app: 'FocusQuest', version: chrome.runtime.getManifest().version, exportedAt: new Date().toISOString(), data };
}
async function onImport({ backup }) {
  return locked(async () => {
    const state = await load();
    if (state.timer.locked) return { ok: false, reason: 'Pass the pending quiz before restoring a backup.' };
    const d = backup && backup.data;
    if (!d || typeof d !== 'object') return { ok: false, reason: 'That file is not a FocusQuest backup.' };
    const out = {};
    if (d.settings) out.settings = sanitize(d.settings);
    if (d.prefs) out.prefs = { ...FQ_PREFS, ...d.prefs };
    if (d.stats) out.stats = { ...freshStats(), ...d.stats };
    if (d.qstats && typeof d.qstats === 'object') {   // ids and counters only
      out.qstats = {};
      for (const [id, v] of Object.entries(d.qstats).slice(0, QSTATS_CAP)) {
        if (/^u-/.test(id) || !v || typeof v !== 'object') continue;
        out.qstats[String(id).slice(0, 64)] = { seen: v.seen | 0, correct: v.correct | 0, last: +v.last || 0, miss: v.miss === true || (v.miss === undefined && (v.correct | 0) < (v.seen | 0)) };
      }
    }
    if (Array.isArray(d.starred)) out.starred = d.starred.map(String).filter(id => !/^u-/.test(id)).slice(0, STARRED_CAP);
    await set(out);
    if (out.settings) await syncCustomScripts(out.settings);
    paintBadge();
    return { ok: true, keys: Object.keys(out) };
  });
}
async function onReset({ scope }) {
  return locked(async () => {
    const state = await load();
    if (state.timer.locked) return { ok: false, reason: 'Pass the pending quiz first.' };
    if (scope === 'progress') await set({ stats: freshStats(), qstats: {}, starred: [] });
    else if (scope === 'all') {
      await chrome.storage.local.clear();
      await set({ settings: sanitize({}), prefs: { ...FQ_PREFS }, timer: freshTimer(), stats: freshStats() });
      await syncCustomScripts(sanitize({}));
    }
    paintBadge();
    return { ok: true };
  });
}
// ---------- wiring ----------
const openPage = path => chrome.tabs.create({ url: chrome.runtime.getURL(path) });

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const handlers = {
    'fq:heartbeat': () => onHeartbeat(msg),
    'fq:check': () => onCheck(msg),
    'fq:state': () => locked(async () => {
      const s = await load();
      if (dailyRollover(s)) await set({ timer: s.timer });
      return { ...publicState(s), stats: s.stats };
    }),
    'fq:quizFinished': () => onQuizFinished(msg),
    'fq:saveSettings': () => onSaveSettings(msg.settings || {}),
    'fq:emergency': () => onEmergency(),
    'fq:syncDaily': () => locked(async () => {
      // Record a ranked result that was played on another device (or before this one synced). Never overwrites a local record.
      const state = await load(), stats = state.stats;
      const day = String(msg.day || '');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day) || (stats.daily || {})[day]) return { ok: true, changed: false };
      const rec = { score: msg.score | 0, total: msg.total | 0, grid: String(msg.grid || '').slice(0, 60), ranked: true, flagged: !!msg.flagged };
      for (const k of ['timeMs', 'rank', 'players', 'percentile']) if (Number.isFinite(msg[k])) rec[k] = msg[k];
      stats.daily = { ...(stats.daily || {}), [day]: rec };
      const dd = Object.keys(stats.daily).sort(); while (dd.length > 400) delete stats.daily[dd.shift()];
      await set({ stats });
      paintBadge(state);
      return { ok: true, changed: true };
    }),
    'fq:release': () => locked(async () => {
      const state = await load();
      state.timer.holdUntil = 0;
      state.timer.lastTick = 0;
      await set({ timer: state.timer });
      broadcast({ type: 'fq:unlock' });
      paintBadge(state);
      return { ok: true };
    }),
    'fq:openPractice': async () => { await openPage('src/quiz.html' + (msg.query ? '?' + String(msg.query).replace(/^[?&]/, '') : '') + '#practice'); return { ok: true }; },
    'fq:openOptions': async () => { await chrome.runtime.openOptionsPage(); return { ok: true }; },
    'fq:syncSites': async () => { await syncCustomScripts(); return { ok: true }; },
    'fq:export': () => onExport(),
    'fq:import': () => onImport(msg),
    'fq:reset': () => onReset(msg),
    'fq:lockSet': () => onLockSet(msg),
    'fq:outageSkip': () => onOutageSkip()
  };
  const h = handlers[msg && msg.type];
  if (!h) return false;
  Promise.resolve(h()).then(reply, err => reply({ error: String(err) }));
  return true; // async reply
});

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  const s = await get(['settings', 'timer', 'stats', 'prefs', 'qstats', 'activeQuiz']);
  // Questions no longer live on this device: drop imported banks and any saved round that still carries its own question order.
  await chrome.storage.local.remove(['customBank', 'dailyQuiz']);
  const qs = {}; for (const [id, v] of Object.entries(s.qstats || {})) if (!/^u-/.test(id)) qs[id] = v;
  if (s.activeQuiz && !s.activeQuiz.seed) await chrome.storage.local.remove('activeQuiz');
  await set({
    qstats: qs,
    settings: sanitize(s.settings),
    timer: { ...cleanTimer(s.timer), lockSet: cleanLockSet((s.timer || {}).lockSet) },
    stats: { ...freshStats(), ...(s.stats || {}) },
    prefs: { ...FQ_PREFS, ...(s.prefs || {}) }
  });
  chrome.alarms.create('fq:badge', { periodInMinutes: 1 });
  paintBadge();
  syncCustomScripts();
  await set({ promptDay: FQ_utcDay() }); // no reminder on the day of install or update
  if (reason === 'install') openPage('src/quiz.html?mode=welcome');
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('fq:badge', { periodInMinutes: 1 });
  paintBadge();
  setTimeout(maybePromptDaily, 4000);
});

// Once a day, when the browser is in use, open the popup in its compact "today's challenge" view.
async function maybePromptDaily() {
  const { prefs = {}, stats = {}, promptDay } = await get(['prefs', 'stats', 'promptDay']);
  const today = FQ_utcDay();
  if (prefs.dailyPrompt === false || promptDay === today || (stats.daily || {})[today]) return;
  const win = await chrome.windows.getLastFocused().catch(() => null);
  if (!win || !win.focused || win.type !== 'normal') return;
  await set({ promptDay: today, promptAt: Date.now() });
  try { await chrome.action.openPopup({ windowId: win.id }); }
  catch (_) { await set({ promptAt: 0 }); } // not allowed right now: the badge still says "1"
}
chrome.windows.onFocusChanged.addListener(id => { if (id !== chrome.windows.WINDOW_ID_NONE) maybePromptDaily(); });

chrome.alarms.onAlarm.addListener(a => {
  if (a.name !== 'fq:badge') return;
  locked(async () => {
    const s = await load();
    if (dailyRollover(s)) await set({ timer: s.timer });
    paintBadge(s);
  });
  maybePromptDaily();
});

chrome.commands && chrome.commands.onCommand.addListener(cmd => {
  if (cmd === 'open-practice') openPage('src/quiz.html#practice');
  if (cmd === 'open-options') chrome.runtime.openOptionsPage();
});
