// Leaderboard server settings. CHANGE THESE TWO VALUES AT DEPLOY TIME.
//   apiBase: origin of the leaderboard Worker API (no trailing slash), e.g. 'https://sfdq-leaderboard.example.workers.dev'
//   webUrl:  public address of the leaderboard web app, used for "View the full leaderboard" links and the "link that account" page.
//            It must match the src/link.js content-script `matches` entry in manifest.json (e.g. 'https://<host>/*').
// Both default to the local dev server. A dev override for apiBase can be set with
// chrome.storage.local key "apiBase" (used by the automated tests); leave it unset in production.
const SFDQ_CONFIG = { apiBase: 'https://play.sfdq.workers.dev', webUrl: 'https://play.sfdq.workers.dev' };
