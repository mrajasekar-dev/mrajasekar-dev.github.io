// Apply the saved theme before first paint (extension pages cannot run inline scripts).
FQ_theme.boot();
