// Salesforce Daily Quiz quiz engine: intro → scenario questions with lives/streaks/lifelines → results.
(() => {
  'use strict';

  const params = new URLSearchParams(location.search);
  const MODE = params.get('mode') || 'practice';          // lock | practice | welcome
  const HAS_EXT = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;
  if (MODE === 'lock') document.body.classList.add('embedded');

  // ---------- platform shims (let the page run standalone for previews) ----------
  const store = HAS_EXT
    ? { get: k => chrome.storage.local.get(k), set: o => chrome.storage.local.set(o) }
    : {
        get: async k => { const all = JSON.parse(localStorage.fq || '{}'); const out = {}; [].concat(k).forEach(x => { if (x in all) out[x] = all[x]; }); return out; },
        set: async o => { localStorage.fq = JSON.stringify({ ...JSON.parse(localStorage.fq || '{}'), ...o }); }
      };
  const bg = msg => HAS_EXT
    ? chrome.runtime.sendMessage(msg).catch(() => null)
    : Promise.resolve(msg.type === 'fq:state'
        ? { locked: MODE === 'lock', usedMs: 3600000, limitMs: 3600000, emergencyLeft: 1, settings: FQ_DEFAULTS, stats: { quizzesTaken: 3, quizzesPassed: 2, answered: 90, correct: 66, bestStreak: 11, xp: 7400, unlocks: 2, answeredByDay: {} } }
        : { passed: msg.total && msg.score / msg.total >= .7, achievements: [] });

  // ---------- helpers ----------
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rich = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>');
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const range = n => Array.from({ length: n }, (_, i) => i);
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const KEYS = 'ABCDEF';
  const mmss = ms => { const s = Math.max(0, Math.ceil(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

  const TOPIC_COLORS = {
    'Apex Triggers': '#a58bff', 'Async Apex': '#38bdf8', 'Governor Limits': '#ffb020', 'SOQL & DML': '#2ee6a6',
    'Exception Handling': '#ff7b7b', 'Apex Testing': '#7dd3fc', 'LWC': '#f472b6', 'JavaScript': '#facc15',
    'Integration': '#34d399', 'Platform Events & CDC': '#fb923c', 'Security & Sharing': '#ff6b8b', 'Data Model': '#60a5fa',
    'Assignment & Territory': '#a3e635', 'Flows': '#22d3ee', 'Order of Execution': '#c084fc', 'Validation & Formulas': '#fbbf24',
    'Custom Metadata & Settings': '#2dd4bf', 'Reports & Dashboards': '#818cf8', 'Deployment & DevOps': '#4ade80',
    'Experience Cloud': '#e879f9', 'Sales & Service Cloud': '#5eead4', 'Apex OOP & Platform': '#fda4af', 'Architecture & Design': '#fcd34d'
  };
  const colorOf = t => {
    if (TOPIC_COLORS[t]) return TOPIC_COLORS[t];
    let h = 0; for (const ch of String(t)) h = (h * 31 + ch.charCodeAt(0)) % 360;
    return `hsl(${h} 75% 65%)`;
  };

  const STREAK_BANNERS = { 3: '3 in a row', 5: '5 in a row', 10: '10 in a row', 15: '15 in a row', 20: '20 in a row', 25: '25 in a row', 30: '30 in a row' };
  const PRAISE = ['Correct.', 'Correct. Well reasoned.', 'Exactly right.', 'Correct. Clean call.', 'Spot on.'];
  const OOPS = ['Not quite.', 'Incorrect.'];
  const SOS_PHRASE = 'I choose to scroll';

  // ---------- sound ----------
  const Sound = (() => {
    let ctx = null, on = true, pack = 'arcade', vol = .7;
    const ac = () => (ctx = ctx || new (window.AudioContext || window.webkitAudioContext)());
    function tone(freq, t0, dur, type = 'sine', v = .16, slideTo) {
      const c = ac(), o = c.createOscillator(), g = c.createGain();
      let f = freq, s = slideTo, vv = v * vol;
      if (pack === 'soft') { type = 'sine'; f *= .8; s = s && s * .8; vv *= .6; dur *= 1.3; }
      if (pack === 'retro') { type = 'square'; vv *= .38; }
      o.type = type; o.frequency.setValueAtTime(f, c.currentTime + t0);
      if (s) o.frequency.exponentialRampToValueAtTime(s, c.currentTime + t0 + dur);
      g.gain.setValueAtTime(0.0001, c.currentTime + t0);
      g.gain.exponentialRampToValueAtTime(Math.max(.0002, vv), c.currentTime + t0 + .015);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t0 + dur);
      o.connect(g).connect(c.destination); o.start(c.currentTime + t0); o.stop(c.currentTime + t0 + dur + .05);
    }
    const play = fn => { if (!on || vol <= 0) return; try { fn(); } catch (_) {} };
    return {
      set enabled(v) { on = v; }, get enabled() { return on; },
      config(p) { pack = p.soundPack || 'arcade'; vol = Math.max(0, Math.min(1, (p.volume ?? 70) / 100)); },
      tap: () => play(() => tone(900, 0, .05, 'triangle', .05)),
      right: () => play(() => { tone(784, 0, .12, 'triangle', .14); tone(1175, .08, .22, 'sine', .14); }),
      wrong: () => play(() => { tone(260, 0, .22, 'sawtooth', .05, 150); tone(180, .06, .3, 'sine', .12, 110); }),
      streak: () => play(() => [1047, 1319, 1568, 2093].forEach((f, i) => tone(f, i * .06, .18, 'triangle', .1))),
      pass: () => play(() => [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, i * .09, .35, i % 2 ? 'sine' : 'triangle', .13))),
      fail: () => play(() => [392, 330, 262].forEach((f, i) => tone(f, i * .16, .32, 'sine', .12))),
      fifty: () => play(() => { tone(600, 0, .1, 'square', .04, 1200); tone(1200, .1, .12, 'square', .04, 600); }),
      swap: () => play(() => { tone(500, 0, .12, 'triangle', .08, 900); tone(900, .1, .12, 'triangle', .08, 500); }),
      tick: () => play(() => tone(1400, 0, .03, 'square', .025)),
      trophy: () => play(() => [784, 988, 1175, 1568].forEach((f, i) => tone(f, i * .1, .4, 'triangle', .12)))
    };
  })();

  // ---------- confetti ----------
  const Confetti = (() => {
    const cv = $('confetti'), cx = cv.getContext('2d');
    let parts = [], raf = 0, enabled = true, scale = 1;
    const COLORS = () => { const cs = getComputedStyle(document.documentElement); return ['--accent', '--accent-2', '--good', '--bad', '--warn', '--info'].map(v => cs.getPropertyValue(v).trim() || '#fff').concat('#ffffff'); };
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    function size() { cv.width = innerWidth * devicePixelRatio; cv.height = innerHeight * devicePixelRatio; }
    addEventListener('resize', size); size();
    function spawn(x, y, n, spread = Math.PI * 2, power = 9, dir = -Math.PI / 2) {
      if (reduce || !enabled) return;
      const cols = COLORS();
      n = Math.round(n * scale);
      for (let i = 0; i < n; i++) {
        const a = dir + (Math.random() - .5) * spread, v = power * (.45 + Math.random() * .8);
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, r: 4 + Math.random() * 6, rot: Math.random() * 6, vr: (Math.random() - .5) * .35,
          c: pick(cols), shape: Math.random() < .3 ? 'c' : 'r', life: 0, max: 90 + Math.random() * 70 });
      }
      if (!raf) raf = requestAnimationFrame(tick);
    }
    function tick() {
      cx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
      cx.clearRect(0, 0, innerWidth, innerHeight);
      parts = parts.filter(p => p.life < p.max && p.y < innerHeight + 40);
      for (const p of parts) {
        p.life++; p.vy += .22; p.vx *= .99; p.vy *= .99; p.x += p.vx; p.y += p.vy; p.rot += p.vr;
        cx.save(); cx.globalAlpha = Math.max(0, 1 - p.life / p.max); cx.translate(p.x, p.y); cx.rotate(p.rot); cx.fillStyle = p.c;
        if (p.shape === 'c') { cx.beginPath(); cx.arc(0, 0, p.r / 2, 0, 7); cx.fill(); } else cx.fillRect(-p.r / 2, -p.r / 4, p.r, p.r / 2);
        cx.restore();
      }
      raf = parts.length ? requestAnimationFrame(tick) : 0;
    }
    return {
      config(p) { enabled = p.confetti !== false && p.motion !== 'off'; scale = p.motion === 'calm' ? .4 : 1; },
      burst(el, n = 40) { const r = el.getBoundingClientRect(); spawn(r.left + r.width / 2, r.top + r.height / 2, n, Math.PI * 2, 7); },
      cannons() { spawn(0, innerHeight * .8, 120, 1, 22, -Math.PI / 3); spawn(innerWidth, innerHeight * .8, 120, 1, 22, -Math.PI * 2 / 3); },
      rain(ms = 2600) { if (!enabled) return; const end = Date.now() + ms; (function drop() { spawn(Math.random() * innerWidth, -20, 6, 1, 3, Math.PI / 2); if (Date.now() < end) setTimeout(drop, 60); })(); }
    };
  })();

  function floatText(text, el, big = false) {
    const r = el.getBoundingClientRect();
    const f = document.createElement('div');
    f.className = 'floater' + (big ? ' big' : '');
    f.textContent = text;
    f.style.left = (r.left + r.width / 2) + 'px';
    f.style.top = (r.top) + 'px';
    $('floatLayer').appendChild(f);
    setTimeout(() => f.remove(), 1200);
  }
  function banner(text) {
    const b = document.createElement('div');
    b.className = 'banner'; b.textContent = text;
    document.body.appendChild(b);
    setTimeout(() => b.remove(), 1500);
  }
  function toast(emoji, title, sub) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<span class="te">${esc(emoji)}</span><div>${esc(title)}${sub ? `<small>${esc(sub)}</small>` : ''}</div>`;
    $('toastLayer').appendChild(t);
    setTimeout(() => t.remove(), 4200);
  }
  function announce(t) { $('live').textContent = t; }

  // ---------- state ----------
  let BANK = [];
  let settings = { ...FQ_DEFAULTS };
  let stats = {};
  let pub = {};              // last fq:state
  let prefs = { ...FQ_PREFS };
  let starred = new Set();
  let SITE = null;
  let S = null;              // current session
  let screen = 'intro';
  const practice = { mode: params.get('pmode') || 'smart', len: 10, diff: 'any', timer: 0, topics: null };
  let qTick = 0, lastTickAt = 0, lastSaveAt = 0, autoNext = 0;

  const qById = id => BANK.find(q => q.id === id);
  const needed = total => Math.ceil(total * settings.passPercent / 100);
  // You may miss (total - needed) questions; the next miss after that ends the round.
  const livesFor = total => total - needed(total) + 1;
  const hasLives = () => S && S.mode === 'lock' && S.livesOn;
  const correctCount = () => S.answers.filter(a => a && a.correct).length;
  const wrongCount = () => S.answers.filter(a => a && !a.correct).length;

  async function saveSession() {
    if (S && S.mode === 'lock') { S.updatedAt = Date.now(); await store.set({ activeQuiz: S }); }
    if (S && S.mode === 'daily') await store.set({ dailyQuiz: S });
  }

  // ---------- question bank ----------
  function normalizeQ(q, i, prefix) {
    if (!q || typeof q !== 'object') return null;
    const options = (Array.isArray(q.options) ? q.options : []).map(o => String(o)).filter(o => o.trim()).slice(0, 6);
    let answer = q.answer;
    if (typeof answer === 'string' && /^[A-Fa-f]$/.test(answer.trim())) answer = KEYS.indexOf(answer.trim().toUpperCase());
    answer = Number(answer);
    if (!q.q || options.length < 2 || !(answer >= 0 && answer < options.length)) return null;
    return {
      id: q.id ? String(q.id) : `${prefix}${i}`, topic: String(q.topic || 'General').slice(0, 60),
      difficulty: ['easy', 'medium', 'hard'].includes(q.difficulty) ? q.difficulty : 'medium',
      q: String(q.q), code: q.code ? String(q.code) : '', options, answer, explanation: q.explanation ? String(q.explanation) : ''
    };
  }
  async function loadBank() {
    let builtin = [];
    try {
      const url = HAS_EXT ? chrome.runtime.getURL('data/questions.json') : '../data/questions.json';
      builtin = (await (await fetch(url)).json()).map((q, i) => normalizeQ(q, i, 'b-')).filter(Boolean);
    } catch (_) {}
    const { customBank = [] } = await store.get('customBank');
    const custom = customBank.map((q, i) => normalizeQ({ ...q, id: q.id || `u-${i}` }, i, 'u-')).filter(Boolean);
    const src = settings.bankSource;
    BANK = src === 'custom' && custom.length ? custom : src === 'both' ? builtin.concat(custom) : builtin;
    if (!BANK.length) BANK = custom.length ? custom : builtin;
  }

  const DIFF_RANK = { easy: 0, medium: 1, hard: 2 };
  function basePool({ topics, diff }) {
    let pool = BANK.filter(q => !topics || topics.has(q.topic));
    if (diff === 'easy') pool = pool.filter(q => q.difficulty !== 'hard');
    else if (diff === 'hard') pool = pool.filter(q => q.difficulty !== 'easy');
    else if (['easy-only', 'medium', 'hard-only'].includes(diff)) pool = pool.filter(q => q.difficulty === diff.replace('-only', ''));
    return pool;
  }
  function modePool(pool, mode, qstats) {
    if (mode === 'mistakes') return pool.filter(q => qstats[q.id] && qstats[q.id].correct < qstats[q.id].seen);
    if (mode === 'starred') return pool.filter(q => starred.has(q.id));
    if (mode === 'unseen') return pool.filter(q => !qstats[q.id]);
    return pool;
  }
  function weigh(pool, qstats) {
    const now = Date.now();
    return pool.map(q => {
      const s = qstats[q.id];
      let w = Math.random();
      if (!s) w += 1.4;                                        // never seen → priority
      else {
        w += (1 - s.correct / Math.max(1, s.seen)) * 1.6;      // got it wrong before → more likely
        w += Math.min((now - s.last) / 864e5, 7) / 7 * .8;     // haven't seen in a while → more likely
      }
      return { q, w };
    }).sort((a, b) => b.w - a.w).map(x => x.q);
  }
  function order(qs, how) {
    if (how === 'mixed') return shuffle(qs.slice());
    // gentle difficulty ramp with jitter so it never feels predictable
    return qs.map(q => ({ q, k: (DIFF_RANK[q.difficulty] ?? 1) + Math.random() * 1.8 })).sort((a, b) => a.k - b.k).map(x => x.q);
  }
  function lockFilter() {
    return { topics: settings.lockTopics ? new Set(settings.lockTopics) : null, diff: settings.difficulty };
  }
  function practiceFilter() {
    const d = { any: null, easy: 'easy-only', medium: 'medium', hard: 'hard-only' }[practice.diff];
    return { topics: practice.topics, diff: d };
  }
  function selectQuestions(n, mode, qstats) {
    if (mode === 'lock') {
      let pool = basePool(lockFilter());
      if (pool.length < n) pool = pool.concat(basePool({ topics: lockFilter().topics }).filter(q => !pool.includes(q)));
      if (pool.length < n) pool = pool.concat(BANK.filter(q => !pool.includes(q)));
      return order(weigh(pool, qstats).slice(0, n), settings.difficulty === 'mixed' ? 'mixed' : 'ramp');
    }
    const pool = modePool(basePool(practiceFilter()), practice.mode, qstats);
    return order(weigh(pool, qstats).slice(0, n), 'ramp');
  }
  const permFor = q => settings.shuffleOptions ? shuffle(range(q.options.length)) : range(q.options.length);

  // Daily challenge: the same five questions for everyone on a given date.
  function seeded(str) { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return () => { h += 0x6D2B79F5; let t = h; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const DAILY_LENGTHS = [5, 10, 15, 20];
  const dailyLen = () => DAILY_LENGTHS.includes(prefs.dailyCount) ? prefs.dailyCount : 5;
  function dailySet() {
    const rnd = seeded('sfdq-' + FQ_dayKey());
    const pool = BANK.filter(q => q.id && !q.id.startsWith('u-')).sort((a, b) => a.id < b.id ? -1 : 1);
    const src = pool.length >= 5 ? pool : BANK.slice();
    for (let i = src.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [src[i], src[j]] = [src[j], src[i]]; }
    const qs = src.slice(0, dailyLen()).map(q => ({ q, k: (DIFF_RANK[q.difficulty] ?? 1) + rnd() * 1.8 })).sort((x, y) => x.k - y.k).map(x => x.q);
    return { qs, perms: qs.map(q => { const p = range(q.options.length); for (let i = p.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [p[i], p[j]] = [p[j], p[i]]; } return p; }) };
  }

  async function newSession(mode) {
    const { qstats = {} } = await store.get('qstats');
    const n = mode === 'lock' ? settings.questionsPerQuiz : practice.len;
    const daily = mode === 'daily' ? dailySet() : null;
    const qs = daily ? daily.qs : selectQuestions(n, mode, qstats);
    S = {
      mode, ids: qs.map(q => q.id), perms: daily ? daily.perms : qs.map(permFor), day: FQ_dayKey(),
      i: 0, answers: [], xp: 0, streak: 0, bestStreak: 0, lifelines: 0, speedy: 0,
      fiftyLeft: daily ? 0 : settings.fiftyCount, skipLeft: daily ? 0 : settings.skipCount, fiftyOn: null,
      livesOn: mode === 'lock' && settings.livesOn,
      timer: mode === 'lock' ? settings.questionTimer : daily ? 0 : practice.timer, tLeft: 0, tFor: -1,
      startedAt: Date.now(), updatedAt: Date.now(), over: false
    };
    await saveSession();
  }

  // ---------- screens ----------
  function show(name) {
    screen = name;
    for (const id of ['intro', 'quiz', 'results']) $(id).hidden = id !== name;
    const el = $(name); el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
    scrollTo({ top: 0, behavior: 'smooth' });
  }

  const chip = html => `<span class="chip">${html}</span>`;
  const greet = () => settings.displayName ? `, ${esc(settings.displayName)}` : '';

  function renderIntro(resumable) {
    const total = settings.questionsPerQuiz;
    const lvl = FQ_levelOf(stats.xp || 0);
    $('howto').hidden = MODE !== 'welcome';
    $('practicePicker').hidden = MODE === 'lock';
    $('restartBtn').hidden = !resumable;
    $('whyCard').hidden = !settings.why;
    $('whyText').textContent = settings.why;
    $('emergencyBtn').hidden = true;
    $('cooldownNote').hidden = true;

    $('dailyPick').hidden = true; $('dailyBoardIntro').hidden = true;
    if (MODE === 'daily') {
      const done = (stats.daily || {})[FQ_dayKey()];
      const ds = FQ_dailyStats(stats.daily);
      $('practicePicker').hidden = true;
      $('introEyebrow').textContent = 'Daily challenge · ' + new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
      if (done) {
        $('introTitle').textContent = `Today: ${done.score}/${done.total}`;
        $('introLede').innerHTML = done.score === done.total ? 'A perfect set. Come back tomorrow for the next one.' : 'You have played today\'s set. The next one unlocks at midnight.';
        $('introChips').innerHTML = '';
        dailyBoard($('dailyBoardIntro'), done);
        $('startLabel').textContent = 'Practice while you wait';
      } else {
        $('introTitle').textContent = ds.current ? `Day ${ds.current + 1}. Keep it going.` : 'Today\'s five questions.';
        $('introLede').innerHTML = 'Everyone gets the same Salesforce scenarios today. One attempt, with the reasoning after each answer.';
        $('introChips').innerHTML = chip(`Streak <b>${ds.current}</b>`) + chip(`Best <b>${ds.best}</b>`) + chip(`Played <b>${ds.played}</b>`);
        if (!resumable) renderDailyPick();
        $('startLabel').textContent = resumable ? `Resume today's set · ${S.answers.length}/${S.ids.length}` : `Start today's ${dailyLen()} questions`;
      }
    } else if (MODE === 'lock') {
      $('introEmoji').textContent = '';
      $('introEyebrow').textContent = SITE ? `${SITE.emoji} ${SITE.name} is paused` : 'Scroll paused';
      $('introTitle').innerHTML = settings.displayName ? `Time for a quick review${greet()}.` : 'Time for a quick review.';
      const used = Math.round((pub.limitMs || settings.limitMinutes * 60000) / 60000);
      $('introLede').innerHTML = `You've used your <b>${used} minutes</b> of social time. Score <b>${needed(total)} of ${total}</b> to unlock another <b>${settings.rewardMinutes}</b>.`;
      $('introChips').innerHTML = [
        chip(` <b>${total}</b> questions`), chip(` <b>${settings.passPercent}%</b> to pass`),
        settings.livesOn ? chip(` <b>${livesFor(total)}</b> lives`) : chip(' no lives'),
        settings.questionTimer ? chip(` <b>${settings.questionTimer}s</b> each`) : '',
        settings.fiftyCount ? chip(` <b>${settings.fiftyCount}</b> × 50:50`) : '',
        settings.skipCount ? chip(`⇄ <b>${settings.skipCount}</b> × swap`) : ''
      ].join('');
      $('startLabel').textContent = resumable ? `Resume · Q${Math.min(S.answers.length + 1, S.ids.length)} of ${S.ids.length}` : "Let's go";
      if (settings.emergencyPerWeek > 0) {
        const left = pub.emergencyLeft ?? 0;
        $('emergencyBtn').hidden = false;
        $('emergencyBtn').disabled = left <= 0;
        $('emergencyBtn').textContent = left > 0 ? ` Emergency pass (${left} left this week)` : ' No emergency passes left this week';
      }
      applyCooldown();
    } else {
      $('introEmoji').textContent = MODE === 'welcome' ? '' : '';
      $('introEyebrow').textContent = MODE === 'welcome' ? 'Welcome' : 'Practice';
      $('introTitle').innerHTML = MODE === 'welcome' ? 'Salesforce Daily Quiz' : 'Practise at your own pace.';
      $('introLede').innerHTML = MODE === 'welcome'
        ? `Every <b>${settings.limitMinutes} minutes</b> on social media, Salesforce Daily Quiz pauses everything and hands you a <b>${total}-question</b> challenge. Score <b>${settings.passPercent}%</b> and you're back in.`
        : `No streaks or stakes. Pick a mode and go. <b>${BANK.length}</b> questions in your bank.`;
      $('introChips').innerHTML = chip(`${lvl[2]} <b>${lvl[1]}</b>`) + chip(` <b>${(stats.xp || 0).toLocaleString()}</b> XP`) + chip(`Daily streak <b>${FQ_dailyStreak(stats.daily)}</b>`);
      $('startLabel').textContent = MODE === 'welcome' ? 'Take a practice round' : 'Start practice';
      renderPicker();
    }

    const acc = stats.answered ? Math.round(stats.correct / stats.answered * 100) + '%' : '—';
    const today = (stats.answeredByDay || {})[FQ_dayKey()] || 0;
    $('miniStats').hidden = true; // stats live in the popup and Settings > Progress
    $('pinTip').hidden = MODE !== 'welcome';
    if (MODE === 'welcome') $('introChips').innerHTML = '';
    $('miniStats').innerHTML = [
      [stats.quizzesPassed || 0, 'quizzes passed'], [acc, 'lifetime accuracy'], [stats.bestStreak || 0, 'best streak '],
      settings.dailyGoal ? [`${Math.min(today, settings.dailyGoal)}/${settings.dailyGoal}`, 'today\'s goal '] : null,
      [`${lvl[2]} ${lvl[1]}`, `${(stats.xp || 0).toLocaleString()} XP`]
    ].filter(Boolean).map(([b, s]) => `<div class="mini"><b>${b}</b><span>${s}</span></div>`).join('');
    show('intro');
  }

  function renderDailyPick() {
    $('dailyPick').hidden = false;
    const n = dailyLen();
    $('dailyLenSeg').innerHTML = DAILY_LENGTHS.map(v => `<button type="button" role="radio" data-v="${v}" aria-checked="${v === n}">${v === 5 ? '5 · Standard' : v}</button>`).join('');
    $('dailyPickNote').textContent = n === 5 ? 'Five is the standard daily set. Want a longer session? Pick 10, 15 or 20. Your streak counts either way.' : `A longer set: the standard five plus ${n - 5} more. Your streak counts either way.`;
    $('dailyLenSeg').onclick = async e => {
      const b = e.target.closest('button'); if (!b) return;
      Sound.tap();
      prefs = { ...prefs, dailyCount: +b.dataset.v };
      const { prefs: p = {} } = await store.get('prefs');
      await store.set({ prefs: { ...p, dailyCount: +b.dataset.v } });
      renderDailyPick();
      $('startLabel').textContent = `Start today's ${dailyLen()} questions`;
    };
  }

  // Wordle-style summary: numbers, this week, countdown and share.
  let countdownTimer = 0;
  function dailyBoard(el, today, withShare = true) {
    const ds = FQ_dailyStats(stats.daily), d = stats.daily || {};
    const week = [];
    for (let i = 6; i >= 0; i--) { const t = Date.now() - i * 864e5, k = FQ_dayKey(t), r = d[k]; week.push({ k, r, label: new Date(t).toLocaleDateString([], { weekday: 'narrow' }), today: i === 0 }); }
    el.hidden = false;
    el.innerHTML = `
      <div class="db-stats">${[[ds.played, 'Played'], [ds.current, 'Current streak'], [ds.best, 'Best streak'], [ds.avg + '%', 'Average score']].map(([b, l]) => `<div><b>${b}</b><span>${l}</span></div>`).join('')}</div>
      <div class="db-week">${week.map(w => `<div class="dw${w.r ? ' on' : ''}${w.r && w.r.score === w.r.total ? ' perfect' : ''}${w.today ? ' today' : ''}" title="${w.k}${w.r ? `: ${w.r.score}/${w.r.total}` : ''}"><i>${w.r ? w.r.score : ''}</i><span>${w.label}</span></div>`).join('')}</div>
      ${today && today.grid ? `<div class="db-grid" aria-label="Your answers today">${[...today.grid].map(c => `<i class="${c === '■' ? 'ok' : 'no'}"></i>`).join('')}</div>` : ''}
      <div class="db-foot"><span>Next challenge in <b id="dbCountdown"></b></span>${today && withShare ? '<button class="btn ghost" type="button" id="dbShare">Share result</button>' : ''}</div>`;
    const tick = () => { const c = el.querySelector('#dbCountdown'); if (!c) return clearInterval(countdownTimer); const m = new Date(); m.setHours(24, 0, 0, 0); const s = Math.max(0, Math.floor((m - Date.now()) / 1000)); c.textContent = `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
    clearInterval(countdownTimer); tick(); countdownTimer = setInterval(tick, 1000);
    const sh = el.querySelector('#dbShare');
    if (sh) sh.onclick = () => shareDaily(today, ds);
  }
  async function copyText(text) {
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_) {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { ok = document.execCommand('copy'); } catch (_) {} ta.remove();
    }
    toast('', ok ? 'Copied to clipboard' : 'Could not copy', ok ? 'Paste it anywhere' : '');
  }
  const shareDaily = (r, ds) => copyText([`Salesforce Daily Quiz ${FQ_dayKey()}  ${r.score}/${r.total}`, r.grid || '', `Streak ${ds.current}`].filter(Boolean).join('\n'));

  // Retry cooldown after a failed lock round.
  let coolTimer = 0;
  function applyCooldown(btn = $('startBtn'), label = $('startLabel')) {
    clearInterval(coolTimer);
    const until = pub.failUntil || 0;
    if (!until || until <= Date.now() || (S && S.answers.length)) { btn.disabled = false; return; }
    const original = label.textContent;
    const paint = () => {
      const left = until - Date.now();
      if (left <= 0) { clearInterval(coolTimer); btn.disabled = false; label.textContent = original; $('cooldownNote').hidden = true; return; }
      btn.disabled = true;
      label.textContent = `Next attempt in ${mmss(left)}`;
      $('cooldownNote').hidden = false;
      $('cooldownNote').textContent = ' Cooldown. Skim your misses, grab water, come back sharper.';
    };
    paint(); coolTimer = setInterval(paint, 500);
  }

  function seg(el, items, current, onPick) {
    el.innerHTML = items.map(([v, label]) => `<button type="button" role="radio" aria-checked="${v === current}" data-v="${v}">${label}</button>`).join('');
    el.onclick = e => { const b = e.target.closest('button'); if (!b) return; Sound.tap(); onPick(isNaN(+b.dataset.v) ? b.dataset.v : +b.dataset.v); renderPicker(); };
  }

  async function renderPicker() {
    const { qstats = {} } = await store.get('qstats');
    seg($('modeSeg'), [['smart', 'Smart'], ['mistakes', 'Mistakes'], ['starred', 'Starred'], ['unseen', 'Unseen']], practice.mode, v => practice.mode = v);
    seg($('lenSeg'), [5, 10, 20, 30, 50].map(n => [n, n]), practice.len, v => practice.len = v);
    seg($('diffSeg'), [['any', 'Any'], ['easy', 'Easy'], ['medium', 'Medium'], ['hard', 'Hard']], practice.diff, v => practice.diff = v);
    seg($('timerSeg'), [[0, 'Off'], [15, '15s'], [30, '30s'], [60, '60s']], practice.timer, v => practice.timer = v);
    const counts = {};
    BANK.forEach(q => counts[q.topic] = (counts[q.topic] || 0) + 1);
    if (!practice.topics) {
      const want = (params.get('topics') || '').split('|').filter(t => counts[t]);
      practice.topics = new Set(want.length ? want : Object.keys(counts));
      if (want.length) $('topicsFold').open = true;
    }
    const nT = Object.keys(counts).length;
    $('topicsSum').textContent = practice.topics.size === nT ? `All ${nT} topics` : practice.topics.size ? `${practice.topics.size} of ${nT} topics` : 'None selected';
    $('topicGrid').innerHTML = Object.keys(counts).sort().map(t =>
      `<button type="button" class="chip-toggle" style="--c:${colorOf(t)}" aria-pressed="${practice.topics.has(t)}" data-t="${esc(t)}">${esc(t)}<small>${counts[t]}</small></button>`).join('');
    $('topicGrid').onclick = e => {
      const b = e.target.closest('button'); if (!b) return;
      const t = b.dataset.t; practice.topics.has(t) ? practice.topics.delete(t) : practice.topics.add(t);
      Sound.tap(); renderPicker();
    };
    $('topicAll').onclick = () => { practice.topics = new Set(Object.keys(counts)); renderPicker(); };
    $('topicNone').onclick = () => { practice.topics = new Set(); renderPicker(); };
    const size = modePool(basePool(practiceFilter()), practice.mode, qstats).length;
    const empty = { mistakes: 'No mistakes to review yet. Nice.', starred: 'Nothing bookmarked yet. Tap ☆ on any question to save it.', unseen: 'You have seen every question in this selection.' }[practice.mode];
    $('poolNote').innerHTML = size ? `<b>${size}</b> question${size === 1 ? '' : 's'} match. You'll get <b>${Math.min(size, practice.len)}</b>.` : (empty || 'No questions match these filters.');
    $('startBtn').disabled = size === 0;
  }

  // ---------- quiz ----------
  function renderHud() {
    const total = S.ids.length;
    const q = qById(S.ids[S.i]);
    const answered = !!S.answers[S.i];
    $('qNum').textContent = Math.min(S.i + 1, total);
    $('qTotal').textContent = total;
    $('xpNum').textContent = S.xp.toLocaleString();
    $('streakNum').textContent = S.streak;
    $('streak').classList.toggle('hot', S.streak >= 3);
    $('fiftyBtn').hidden = !settings.fiftyCount || S.mode === 'daily';
    $('fiftyBtn').disabled = S.fiftyLeft <= 0 || answered || (S.fiftyOn && S.fiftyOn.i === S.i) || !q || q.options.length < 3;
    $('fiftyLeft').textContent = S.fiftyLeft > 1 ? S.fiftyLeft : '';
    $('skipBtn').hidden = !settings.skipCount || S.mode === 'daily';
    $('skipBtn').disabled = S.skipLeft <= 0 || answered;
    $('skipLeft').textContent = S.skipLeft > 1 ? S.skipLeft : '';
    $('soundBtn').textContent = Sound.enabled ? 'Sound' : 'Muted';

    const lives = $('lives');
    if (hasLives()) {
      const max = livesFor(total), left = max - wrongCount();
      lives.hidden = false;
      lives.title = `${Math.max(0, left)} of ${max} mistakes left`;
      lives.innerHTML = Array.from({ length: max }, (_, k) => `<span class="heart${k >= left ? ' lost' : ''}"></span>`).join('');
    } else lives.hidden = true;

    $('track').innerHTML = S.ids.map((_, k) => {
      const a = S.answers[k];
      return `<i class="seg-pip${a ? (a.correct ? ' ok' : ' no') : k === S.i ? ' now' : ''}"></i>`;
    }).join('');
  }

  function highlight(code) {
    const re = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`[^`]*`)|(@\w+)|(\b\d+(?:\.\d+)?\b)|(\b(?:public|private|protected|global|static|final|class|interface|extends|implements|virtual|abstract|override|with|without|inherited|sharing|void|return|new|if|else|for|while|do|try|catch|finally|throw|trigger|on|before|after|insert|update|delete|undelete|upsert|merge|this|super|null|true|false|const|let|var|function|async|await|import|export|from|default|of|in|instanceof|typeof|select|where|limit|order|by|and|or|not|def|elif|lambda|SELECT|FROM|WHERE|LIMIT|ORDER|BY|AND|OR|NOT|IN|FOR|UPDATE|WITH|USER_MODE|SECURITY_ENFORCED|Database|System|Test|List|Set|Map|String|Integer|Boolean|Id|Decimal|Date|Datetime|Object|SObject)\b)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      const cls = m[1] ? 'c' : m[2] ? 's' : m[3] ? 'a' : m[4] ? 'n' : /^[A-Z]/.test(m[5]) && !/^[A-Z_]+$/.test(m[5]) ? 't' : 'k';
      out += `<span class="${cls}">${esc(m[0])}</span>`;
      last = m.index + m[0].length;
    }
    return out + esc(code.slice(last));
  }

  function renderQuestion() {
    clearTimeout(autoNext);
    const q = qById(S.ids[S.i]);
    const perm = S.perms[S.i];
    const ans = S.answers[S.i];
    const card = $('card');
    card.classList.remove('enter', 'shake', 'glow'); void card.offsetWidth; card.classList.add('enter');

    const t = $('qTopic'); t.textContent = q.topic; t.style.setProperty('--c', colorOf(q.topic));
    const lv = { easy: 1, medium: 2, hard: 3 }[q.difficulty] || 2;
    $('qDiff').innerHTML = [1, 2, 3].map(k => `<i class="${k <= lv ? 'on' : ''}"></i>`).join('') + `&nbsp;${q.difficulty || 'medium'}`;
    $('qText').innerHTML = rich(q.q);
    const code = $('qCode');
    if (q.code) { code.hidden = false; code.firstElementChild.innerHTML = highlight(q.code); } else code.hidden = true;
    paintStar();

    $('options').innerHTML = perm.map((orig, k) => `
      <button class="opt" type="button" data-k="${k}">
        <span class="key">${KEYS[k]}</span><span class="txt">${rich(q.options[orig])}</span>
      </button>`).join('');
    $('explain').hidden = true;
    const n = q.options.length;
    $('hint').querySelector('.kbd:nth-child(2)').textContent = KEYS[n - 1];
    $('hint').querySelector('.kbd:nth-child(4)').textContent = String(n);

    if (S.fiftyOn && S.fiftyOn.i === S.i) applyFifty(S.fiftyOn.hide, false);
    renderHud();
    if (ans) paintAnswer(ans.picked, false);
    startTimer();
  }

  function paintStar() {
    const id = S.ids[S.i];
    const on = starred.has(id);
    $('starBtn').textContent = on ? '★' : '☆';
    $('starBtn').setAttribute('aria-pressed', on);
    $('starBtn').title = on ? 'Bookmarked (B to remove)' : 'Bookmark for later (B)';
  }
  async function toggleStar() {
    if (screen !== 'quiz') return;
    const id = S.ids[S.i];
    if (starred.has(id)) starred.delete(id); else { starred.add(id); floatText(' Saved', $('starBtn')); }
    Sound.tap(); paintStar();
    await store.set({ starred: [...starred] });
  }

  // ---------- per-question timer ----------
  function startTimer() {
    cancelAnimationFrame(qTick);
    const on = S.timer > 0 && !S.answers[S.i];
    $('qTimer').hidden = !(S.timer > 0);
    $('qSecs').hidden = !(S.timer > 0);
    if (!(S.timer > 0)) return;
    if (S.tFor !== S.i) { S.tFor = S.i; S.tLeft = S.timer * 1000; }
    paintTimer();
    if (!on) return;
    lastTickAt = performance.now();
    const loop = now => {
      if (screen !== 'quiz' || S.answers[S.i]) return;
      const dt = now - lastTickAt; lastTickAt = now;
      if (document.visibilityState === 'visible' && $('sosModal').hidden) {
        const before = Math.ceil(S.tLeft / 1000);
        S.tLeft -= dt;
        const after = Math.ceil(S.tLeft / 1000);
        if (after !== before && after <= 5 && after > 0) Sound.tick();
        if (Date.now() - lastSaveAt > 1000) { lastSaveAt = Date.now(); saveSession(); }
      }
      paintTimer();
      if (S.tLeft <= 0) { answer(-1); return; }
      qTick = requestAnimationFrame(loop);
    };
    qTick = requestAnimationFrame(loop);
  }
  function paintTimer() {
    const frac = Math.max(0, S.tLeft / (S.timer * 1000));
    $('qTimerBar').style.transform = `scaleX(${frac})`;
    const low = S.tLeft <= 5000;
    $('qTimer').classList.toggle('low', low);
    $('qSecs').classList.toggle('low', low && !S.answers[S.i]);
    $('qSecs').textContent = ` ${Math.max(0, Math.ceil(S.tLeft / 1000))}s`;
  }

  function correctDisplayIndex() {
    const q = qById(S.ids[S.i]);
    return S.perms[S.i].indexOf(q.answer);
  }

  // ---------- lifelines ----------
  function applyFifty(hide, animate = true) {
    const opts = $('options').children;
    hide.forEach(k => opts[k] && opts[k].classList.add('gone'));
    if (animate) { Sound.fifty(); floatText('50:50!', $('fiftyBtn')); }
  }
  function useFifty() {
    if (screen !== 'quiz' || $('fiftyBtn').disabled || $('fiftyBtn').hidden) return;
    const n = S.perms[S.i].length;
    const right = correctDisplayIndex();
    const hide = shuffle(range(n).filter(k => k !== right)).slice(0, n - 2);
    S.fiftyLeft--; S.lifelines++; S.fiftyOn = { i: S.i, hide };
    applyFifty(hide);
    renderHud(); saveSession();
  }
  function useSkip() {
    if (screen !== 'quiz' || $('skipBtn').disabled || $('skipBtn').hidden) return;
    const cur = qById(S.ids[S.i]);
    const f = S.mode === 'lock' ? lockFilter() : practiceFilter();
    let pool = basePool(f).filter(q => !S.ids.includes(q.id));
    if (!pool.length) pool = BANK.filter(q => !S.ids.includes(q.id));
    if (!pool.length) { toast('', 'No other questions to swap in'); return; }
    const same = pool.filter(q => q.difficulty === cur.difficulty);
    const next = pick(same.length ? same : pool);
    S.ids[S.i] = next.id; S.perms[S.i] = permFor(next);
    if (S.fiftyOn && S.fiftyOn.i === S.i) S.fiftyOn = null;
    S.skipLeft--; S.lifelines++; S.tFor = -1;
    Sound.swap(); floatText('Swapped ⇄', $('skipBtn'));
    saveSession(); renderQuestion();
  }

  // ---------- answering ----------
  async function answer(k) {
    if (screen !== 'quiz' || S.answers[S.i]) return;
    const timeout = k < 0;
    const btn = $('options').children[k];
    if (!timeout && (!btn || btn.classList.contains('gone'))) return;
    cancelAnimationFrame(qTick);
    const q = qById(S.ids[S.i]);
    const correct = !timeout && k === correctDisplayIndex();

    let gained = 0, speedy = false;
    if (correct) {
      S.streak++;
      S.bestStreak = Math.max(S.bestStreak, S.streak);
      const base = { easy: 100, medium: 150, hard: 200 }[q.difficulty] || 150;
      const mult = 1 + Math.min(S.streak - 1, 5) * .2;
      speedy = S.timer > 0 && S.tLeft > S.timer * 1000 * .6;
      if (speedy) S.speedy++;
      gained = Math.round(base * mult * (S.fiftyOn && S.fiftyOn.i === S.i ? .5 : 1) * (speedy ? 1.25 : 1));
      S.xp += gained;
    } else S.streak = 0;

    S.answers[S.i] = { picked: k, correct };
    const total = S.ids.length;
    if (hasLives() && wrongCount() >= livesFor(total)) S.over = true;
    saveSession();
    paintAnswer(k, true, gained, speedy);
  }

  function paintAnswer(k, fresh, gained = 0, speedy = false) {
    const q = qById(S.ids[S.i]);
    const right = correctDisplayIndex();
    const correct = k === right;
    const timeout = k < 0;
    const opts = Array.from($('options').children);
    opts.forEach((b, idx) => {
      b.disabled = true;
      if (idx === right) b.classList.add('right');
      else if (idx === k) b.classList.add('wrong');
      else b.classList.add('dim');
      if (idx === k) b.classList.add('picked');
    });

    const total = S.ids.length;
    const verdict = $('verdict');
    verdict.className = 'verdict ' + (correct ? 'good' : 'bad');
    verdict.textContent = correct ? (speedy ? ' Speedy! ' : '') + pick(PRAISE)
      : timeout ? ` Time's up! The answer is ${KEYS[right]}.` : `${pick(OOPS)} The answer is ${KEYS[right]}.`;
    const showText = settings.explanations === 'always' || (settings.explanations === 'wrong' && !correct);
    $('explainText').innerHTML = showText ? rich(q.explanation || '') : '';
    $('explainText').hidden = !showText || !q.explanation;
    $('explain').classList.toggle('has-text', showText && !!q.explanation);
    const last = S.i === total - 1;
    $('nextLabel').textContent = S.over ? 'See results' : last ? 'Finish' : 'Next';
    $('explain').hidden = false;
    renderHud();
    if (S.timer > 0) paintTimer();

    if (fresh) {
      const card = $('card');
      if (correct) {
        Sound.right();
        card.classList.add('glow');
        floatText(`+${gained}`, opts[k]);
        $('xpNum').parentElement.classList.remove('bump'); void card.offsetWidth; $('xpNum').parentElement.classList.add('bump');
        $('streak').classList.remove('bump'); void card.offsetWidth; $('streak').classList.add('bump');
        Confetti.burst(opts[k], 18);
        const msg = STREAK_BANNERS[S.streak];
        if (msg) { setTimeout(() => { banner(msg); Sound.streak(); Confetti.burst($('streak'), 60); }, 250); }
        if (S.mode === 'lock' && correctCount() === needed(total)) {
          setTimeout(() => { banner('Pass mark reached'); Sound.pass(); Confetti.cannons(); }, msg ? 1500 : 300);
        }
        announce('Correct. ' + (showText ? q.explanation || '' : ''));
        if (settings.autoAdvance && !S.over) { const at = S.i; autoNext = setTimeout(() => { if (S && S.i === at && screen === 'quiz') next(); }, msg ? 1600 : 1100); }
      } else {
        Sound.wrong();
        card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake');
        if (hasLives()) {
          const hearts = $('lives').children;
          const idx = livesFor(total) - wrongCount();
          if (hearts[idx]) { hearts[idx].classList.remove('lost'); void hearts[idx].offsetWidth; hearts[idx].classList.add('breaking'); }
          const left = livesFor(total) - wrongCount();
          if (S.over) setTimeout(() => banner('No lives left'), 300);
          else if (left === 1) setTimeout(() => banner('Last life'), 300);
        }
        announce(`Incorrect. The answer is ${KEYS[right]}. ${showText ? q.explanation || '' : ''}`);
      }
      setTimeout(() => $('nextBtn').focus({ preventScroll: true }), 60);
      setTimeout(() => $('explain').scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 150);
    }
  }

  function next() {
    if (screen !== 'quiz' || !S.answers[S.i]) return;
    clearTimeout(autoNext);
    Sound.tap();
    if (S.over || S.i >= S.ids.length - 1) return finish();
    S.i++;
    saveSession();
    renderQuestion();
  }

  // ---------- results ----------
  async function finish() {
    cancelAnimationFrame(qTick);
    const total = S.ids.length;
    const score = correctCount();
    const answered = S.answers.filter(Boolean).length;
    const passed = score >= needed(total);
    const results = S.ids.map((id, k) => S.answers[k] ? { id, correct: S.answers[k].correct, topic: (qById(id) || {}).topic } : null).filter(Boolean);
    const sess = S;
    S = null;
    const res = await bg({
      type: 'fq:quizFinished', mode: sess.mode, score, total, answered, results, bestStreak: sess.bestStreak, xp: sess.xp,
      livesOn: sess.livesOn, livesLeft: sess.livesOn ? livesFor(total) - results.filter(r => !r.correct).length : null,
      lifelines: sess.lifelines, speedy: sess.speedy, grid: gridOf(sess)
    }) || {};
    const st = await bg({ type: 'fq:state' });
    if (st) { pub = st; if (st.stats) stats = st.stats; }
    renderResults(sess, { score, total, answered, passed: res.passed ?? passed, res });
  }

  function renderResults(sess, { score, total, answered, passed, res }) {
    show('results');
    $('dailyBoardRes').hidden = true;
    $('shareBtn').hidden = sess.mode === 'daily';
    const pct = Math.round(score / total * 100);
    const lock = sess.mode === 'lock';
    const ok = lock ? passed : pct >= settings.passPercent;

    // ring
    const C = 2 * Math.PI * 52;
    const fg = $('ringFg');
    fg.style.strokeDasharray = C; fg.style.strokeDashoffset = C;
    fg.classList.toggle('fail', !ok);
    requestAnimationFrame(() => requestAnimationFrame(() => { fg.style.strokeDashoffset = C * (1 - score / total); }));
    const t0 = performance.now();
    (function count(t) {
      const p = Math.min(1, (t - t0) / 1500), e = 1 - Math.pow(1 - p, 3);
      $('scorePct').textContent = Math.round(pct * e) + '%';
      $('scoreRaw').textContent = `${Math.round(score * e)} / ${total}`;
      if (p < 1) requestAnimationFrame(count);
    })(t0);

    const lvl = FQ_levelOf(stats.xp || 0);
    const siteName = SITE ? SITE.name : 'your feed';
    $('resPrimary').disabled = false;
    if (lock && ok) {
      $('resEyebrow').textContent = 'Unlocked ';
      $('resTitle').textContent = 'Passed.';
      $('resLede').innerHTML = `<b>${score}/${total}</b>, that's ${pct}%. Your next <b>${settings.rewardMinutes} minutes</b> start the moment you head back.`;
      $('resPrimary').innerHTML = `Back to ${esc(siteName)} ▶`;
      $('resPrimary').className = 'btn primary big success';
      $('resPrimary').onclick = release;
      $('resSecondary').hidden = true;
      setTimeout(() => { Sound.pass(); Confetti.cannons(); Confetti.rain(2800); }, 500);
    } else if (lock) {
      const outOfLives = answered < total;
      $('resEyebrow').textContent = outOfLives ? 'Round over' : 'Below the pass mark';
      $('resTitle').textContent = score >= needed(total) - 3 ? 'Almost there.' : 'Not this time.';
      $('resLede').innerHTML = outOfLives
        ? `You ran out of lives at question <b>${answered}</b> with <b>${score}</b> correct. You need <b>${needed(total)}</b>. Skim the misses below, then take a fresh set.`
        : `<b>${score}/${total}</b> (${pct}%). You needed <b>${needed(total)}</b>. The misses below are your cheat sheet for the next round.`;
      $('resPrimary').innerHTML = '<span id="retryLabel">Try a fresh set ↻</span>';
      $('resPrimary').className = 'btn primary big';
      $('resPrimary').onclick = async () => { await newSession('lock'); startQuiz(); };
      $('resSecondary').hidden = true;
      applyCooldown($('resPrimary'), $('retryLabel'));
      setTimeout(() => Sound.fail(), 400);
    } else if (sess.mode === 'daily') {
      const ds = FQ_dailyStats(stats.daily), today = (stats.daily || {})[FQ_dayKey()] || { score, total, grid: gridOf(sess) };
      $('resEyebrow').textContent = 'Daily challenge · ' + new Date().toLocaleDateString([], { month: 'long', day: 'numeric' });
      $('resTitle').textContent = score === total ? `Perfect. ${score}/${total}.` : `${score}/${total} today.`;
      $('resLede').innerHTML = ds.current > 1 ? `That's a <b>${ds.current}-day</b> streak.` : 'Day one of your streak. See you tomorrow.';
      $('resPrimary').innerHTML = 'Share result';
      $('resPrimary').className = 'btn primary big';
      $('resPrimary').onclick = () => shareDaily(today, ds);
      $('resSecondary').hidden = false;
      $('resSecondary').textContent = 'Practice more';
      $('resSecondary').onclick = () => { location.search = '?mode=practice'; };
      dailyBoard($('dailyBoardRes'), today, false);
      if (score === total) setTimeout(() => { Sound.pass(); Confetti.cannons(); }, 400);
    } else {
      $('resEyebrow').textContent = 'Practice complete';
      $('resTitle').textContent = pct === 100 ? 'Perfect score.' : pct >= settings.passPercent ? 'Solid round.' : 'Keep going.';
      $('resLede').innerHTML = `<b>${score}/${total}</b> (${pct}%). ${pct >= settings.passPercent ? 'That would have passed the real thing.' : `The real thing needs ${settings.passPercent}%.`}`;
      $('resPrimary').innerHTML = 'Another round ↻';
      $('resPrimary').className = 'btn primary big';
      $('resPrimary').onclick = () => renderIntro(false);
      $('resSecondary').hidden = false;
      $('resSecondary').textContent = 'Close';
      $('resSecondary').onclick = () => window.close();
      if (pct >= settings.passPercent) setTimeout(() => { Sound.pass(); Confetti.cannons(); }, 500);
    }
    $('resBadges').innerHTML =
      sess.mode === 'daily' ? chip(`<b>+${sess.xp.toLocaleString()}</b> XP`) :
      chip(`<b>+${sess.xp.toLocaleString()}</b> XP`) + chip(`Best combo <b>${sess.bestStreak}</b>`) +
      (sess.speedy ? chip(`<b>${sess.speedy}</b> fast answers`) : '') + chip(`<b>${lvl[1]}</b>`);

    // new achievements
    const fresh = (res.achievements || []).map(id => FQ_ACHIEVEMENTS.find(a => a.id === id)).filter(Boolean);
    $('newTrophies').hidden = !fresh.length;
    $('newTrophies').innerHTML = fresh.map(a => `<div class="trophy"><span class="te">${a.emoji}</span><div><span class="new">Achievement unlocked</span><b>${esc(a.name)}</b><small>${esc(a.desc)}</small></div></div>`).join('');
    if (fresh.length) setTimeout(() => { Sound.trophy(); Confetti.burst($('newTrophies'), 50); }, 1400);
    if (res.goalJustHit) setTimeout(() => toast('', 'Daily goal smashed!', `${settings.dailyGoal} questions today`), 900);

    // daily goal
    const today = (stats.answeredByDay || {})[FQ_dayKey()] || 0;
    $('goalBox').hidden = !settings.dailyGoal;
    $('goalText').textContent = `${Math.min(today, settings.dailyGoal)}/${settings.dailyGoal}`;
    $('goalBar').dataset.w = Math.min(100, Math.round(today / Math.max(1, settings.dailyGoal) * 100));

    // topic bars
    const byTopic = {};
    sess.ids.forEach((id, k) => {
      const a = sess.answers[k]; if (!a) return;
      const t = qById(id).topic;
      byTopic[t] = byTopic[t] || { n: 0, ok: 0 };
      byTopic[t].n++; if (a.correct) byTopic[t].ok++;
    });
    const rows = Object.entries(byTopic).sort((a, b) => a[1].ok / a[1].n - b[1].ok / b[1].n);
    $('topicBars').innerHTML = rows.map(([t, v]) => `
      <div class="bar-row"><div class="bar-head"><span>${esc(t)}</span><b>${v.ok}/${v.n}</b></div>
      <div class="bar"><i style="--c:${colorOf(t)}" data-w="${Math.round(v.ok / v.n * 100)}"></i></div></div>`).join('') || '<div class="empty">No answers yet.</div>';
    setTimeout(() => document.querySelectorAll('.bar i').forEach(i => i.style.width = i.dataset.w + '%'), 200);

    // misses
    const misses = sess.ids.map((id, k) => ({ q: qById(id), a: sess.answers[k], perm: sess.perms[k] })).filter(x => x.a && !x.a.correct);
    $('missCount').textContent = misses.length || '';
    $('misses').innerHTML = misses.length ? misses.map(({ q, a, perm }) => `
      <details class="miss">
        <summary>${rich(q.q)}</summary>
        <div class="body">
          <p class="ans">✓ ${rich(q.options[q.answer])}</p>
          <p class="yours">${a.picked < 0 ? ' Ran out of time' : `✕ You picked: ${rich(q.options[perm[a.picked]])}`}</p>
          <p>${rich(q.explanation || '')}</p>
        </div>
      </details>`).join('') : '<div class="empty">Zero misses. Absolute legend. </div>';

    $('shareBtn').onclick = () => share(sess, score, total, pct);
    const weak = [...new Set(misses.map(m => m.q.topic))];
    $('weakBtn').hidden = !weak.length || sess.mode === 'lock';
    $('weakBtn').textContent = weak.length === 1 ? `Practise ${weak[0]}` : `Practise ${weak.length} missed topics`;
    $('weakBtn').onclick = () => { location.href = 'quiz.html?mode=practice&topics=' + encodeURIComponent(weak.join('|')); };
    setTimeout(() => $('resPrimary').focus(), 400);
  }

  const gridOf = sess => sess.ids.map((_, k) => sess.answers[k] ? (sess.answers[k].correct ? '■' : '□') : '·').join('');
  async function share(sess, score, total, pct) {
    const grid = gridOf(sess);
    const rows = grid.match(/.{1,15}/g) || [];
    const text = [`${sess.mode === 'daily' ? 'Salesforce Daily Quiz ' + FQ_dayKey() : 'Salesforce Daily Quiz'}: ${score}/${total} (${pct}%)`, ...rows].join('\n');
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_) {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { ok = document.execCommand('copy'); } catch (_) {} ta.remove();
    }
    toast(ok ? '' : '', ok ? 'Copied to clipboard' : 'Could not copy', ok ? 'Paste it anywhere to flex' : '');
  }

  async function release() {
    Sound.tap();
    $('resPrimary').disabled = true;
    $('resPrimary').textContent = `Enjoy, see you in ${settings.rewardMinutes} minutes `;
    await bg({ type: 'fq:release' });
  }

  function startQuiz() {
    show('quiz');
    renderQuestion();
  }

  // ---------- emergency pass ----------
  function openSos() {
    $('sosText').innerHTML = `Unlock for <b>${settings.emergencyMinutes} minute${settings.emergencyMinutes === 1 ? '' : 's'}</b> without the quiz. You have <b>${pub.emergencyLeft}</b> left this week. The quiz will be waiting when it runs out.`;
    $('sosPhrase').textContent = SOS_PHRASE;
    $('sosInput').value = '';
    $('sosGo').disabled = true;
    $('sosModal').hidden = false;
    setTimeout(() => $('sosInput').focus(), 50);
  }
  const closeSos = () => { $('sosModal').hidden = true; $('startBtn').focus(); };
  $('emergencyBtn').addEventListener('click', openSos);
  $('sosCancel').addEventListener('click', closeSos);
  $('sosInput').addEventListener('input', e => { $('sosGo').disabled = e.target.value.trim().toLowerCase() !== SOS_PHRASE.toLowerCase(); });
  $('sosInput').addEventListener('keydown', e => { if (e.key === 'Enter' && !$('sosGo').disabled) $('sosGo').click(); });
  $('sosGo').addEventListener('click', async () => {
    $('sosGo').disabled = true;
    const r = await bg({ type: 'fq:emergency' });
    if (r && r.ok) { $('sosText').textContent = `Pass active for ${settings.emergencyMinutes} min. Use it well.`; setTimeout(closeSos, 1200); }
    else { $('sosText').textContent = (r && r.reason) || 'Could not use a pass.'; }
  });

  // ---------- input ----------
  document.addEventListener('keydown', e => {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (!$('sosModal').hidden) { if (e.key === 'Escape') closeSos(); return; }
    if (e.target && e.target.tagName === 'INPUT') return;
    const k = e.key.toLowerCase();
    if (screen === 'quiz') {
      const n = S.perms[S.i].length;
      let idx = 'abcdef'.indexOf(k);
      if (idx < 0 && /^[1-6]$/.test(k)) idx = +k - 1;
      if (idx >= 0 && idx < n && !S.answers[S.i]) { e.preventDefault(); answer(idx); return; }
      if ((k === 'enter' || k === ' ' || k === 'arrowright') && S.answers[S.i]) { e.preventDefault(); next(); return; }
      if (k === 'f') { useFifty(); return; }
      if (k === 'w') { useSkip(); return; }
      if (k === 'b') { toggleStar(); return; }
      if (k === 'm') { toggleSound(); return; }
    } else if (screen === 'intro' && k === 'enter' && document.activeElement === document.body) {
      $('startBtn').click();
    }
  });

  $('options').addEventListener('click', e => {
    const b = e.target.closest('.opt'); if (b) answer(+b.dataset.k);
  });
  $('nextBtn').addEventListener('click', next);
  $('fiftyBtn').addEventListener('click', useFifty);
  $('skipBtn').addEventListener('click', useSkip);
  $('starBtn').addEventListener('click', toggleStar);
  $('soundBtn').addEventListener('click', toggleSound);
  $('openOptions').addEventListener('click', () => HAS_EXT ? chrome.runtime.openOptionsPage() : location.assign('options.html'));

  async function toggleSound() {
    Sound.enabled = !Sound.enabled;
    $('soundBtn').textContent = Sound.enabled ? 'Sound' : 'Muted';
    const { prefs: p = {} } = await store.get('prefs');
    await store.set({ prefs: { ...p, sound: Sound.enabled } });
    Sound.tap();
  }

  $('startBtn').addEventListener('click', async () => {
    if ($('startBtn').disabled) return;
    Sound.tap();
    if (MODE === 'lock') {
      if (!S) await newSession('lock');
      startQuiz();
    } else {
      if (MODE === 'daily') { if ((stats.daily || {})[FQ_dayKey()]) { location.search = '?mode=practice'; return; } if (!S) await newSession('daily'); return startQuiz(); }
      if (MODE === 'welcome') { location.search = '?mode=daily'; return; }
      if (!practice.topics || practice.topics.size === 0) return;
      await newSession('practice');
      if (!S.ids.length) { toast('', 'No questions match'); return; }
      startQuiz();
    }
  });
  $('restartBtn').addEventListener('click', async () => {
    if (MODE !== 'lock') return;
    Sound.tap();
    await newSession('lock');
    startQuiz();
  });

  // Another tab may have advanced the shared lock-mode quiz; adopt the newer copy.
  document.addEventListener('visibilitychange', async () => {
    if (document.visibilityState !== 'visible' || MODE !== 'lock') return;
    const { activeQuiz } = await store.get('activeQuiz');
    if (activeQuiz && S && activeQuiz.updatedAt > S.updatedAt) {
      S = activeQuiz;
      if (screen === 'quiz') renderQuestion();
    }
  });

  // ---------- colour mode (System / Light / Dark) ----------
  function paintModeToggle() {
    const t = prefs.theme || 'auto';
    const cur = t === 'auto' ? 'auto' : (FQ_THEMES.find(x => x.id === t) || {}).dark === false ? 'light' : 'dark';
    document.querySelectorAll('#modeToggle button').forEach(b => b.setAttribute('aria-checked', b.dataset.mode === cur));
  }
  $('topbar').hidden = MODE === 'lock';
  document.querySelectorAll('.tb-links a').forEach(a => a.classList.toggle('on', a.dataset.m === (MODE === 'welcome' ? '' : MODE)));
  $('modeToggle').addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return;
    const theme = { auto: 'auto', light: 'cloud', dark: 'graphite' }[b.dataset.mode];
    const { prefs: p = {} } = await store.get('prefs');
    await store.set({ prefs: { ...p, theme, accent: '' } });
    if (!HAS_EXT) FQ_theme.apply({ ...p, theme });
    prefs = { ...prefs, theme }; paintModeToggle();
  });

  // ---------- boot ----------
  (async function boot() {
    $('homeLink').href = FQ_HOME;
    const [st, local] = await Promise.all([bg({ type: 'fq:state' }), store.get(['prefs', 'activeQuiz', 'starred'])]);
    if (st) { pub = st; settings = { ...settings, ...st.settings }; stats = st.stats || {}; }
    const applyPrefs = p => {
      prefs = { ...FQ_PREFS, ...(p || {}) };
      Sound.enabled = prefs.sound !== false && settings.sound !== false;
      Sound.config(prefs); Confetti.config(prefs);
      if ($('soundBtn')) $('soundBtn').textContent = Sound.enabled ? 'Sound' : 'Muted';
      paintModeToggle();
    };
    applyPrefs(local.prefs);
    if (HAS_EXT) chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.prefs) applyPrefs(ch.prefs.newValue); });
    starred = new Set(local.starred || []);
    SITE = FQ_SITES.concat(settings.customSites || []).find(s => s.id === params.get('site')) || null;

    await loadBank();
    if (!BANK.length) {
      document.querySelector('.app').innerHTML = '<p style="padding:40px">Could not load any questions. Run <code>node build.js</code> or import a bank in Options.</p>';
      return;
    }

    if (MODE === 'lock') {
      if (st && (!st.locked || st.emergencyUntil)) {
        // Opened after the lock cleared (e.g. passed in another tab) — offer the way out.
        S = null;
        renderIntro(false);
        $('introEmoji').textContent = '';
        $('introEyebrow').textContent = 'All clear';
        $('introTitle').textContent = "You're free!";
        $('introLede').innerHTML = st.emergencyUntil ? 'An emergency pass is active. The quiz returns when it runs out.' : 'This round was already passed. Go enjoy it.';
        $('introChips').innerHTML = '';
        $('emergencyBtn').hidden = true;
        $('startLabel').textContent = 'Continue ▶';
        $('startBtn').onclick = e => { e.stopImmediatePropagation(); bg({ type: 'fq:release' }); };
        return;
      }
      const aq = local.activeQuiz;
      const valid = aq && aq.mode === 'lock' && !aq.over && aq.ids.every(qById) && aq.answers.length < aq.ids.length;
      S = valid ? aq : null;
      renderIntro(!!S);
    } else if (MODE === 'daily') {
      const { dailyQuiz } = await store.get('dailyQuiz');
      S = dailyQuiz && dailyQuiz.day === FQ_dayKey() && !(stats.daily || {})[FQ_dayKey()] && dailyQuiz.ids.every(qById) ? dailyQuiz : null;
      renderIntro(!!S);
    } else {
      renderIntro(false);
      if (MODE === 'welcome') welcomeChoice();
    }
  })();

  function welcomeChoice() {
    const b = $('restartBtn'); b.hidden = false;
    const paint = () => { b.textContent = settings.blockerOn ? 'Focus timer is on' : 'Turn on the focus timer'; };
    paint();
    b.onclick = async e => { e.stopImmediatePropagation(); const r = await bg({ type: 'fq:saveSettings', settings: { blockerOn: !settings.blockerOn } }); if (r && r.settings) settings = r.settings; paint(); };
    $('startLabel').textContent = 'Start today\'s challenge';
    $('introEyebrow').textContent = 'Welcome';
    $('introTitle').textContent = 'Five Salesforce questions a day.';
    $('introLede').innerHTML = 'A daily challenge for developers and admins, the same for everyone, plus 200 practice scenarios. Build a streak, one set a day.';
    $('practicePicker').hidden = true;
  }
})();
