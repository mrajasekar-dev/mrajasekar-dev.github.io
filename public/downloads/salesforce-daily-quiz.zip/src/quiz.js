// Salesforce Daily Quiz quiz engine: intro → scenario questions with lives/streaks/lifelines → results.
(() => {
  'use strict';

  const params = new URLSearchParams(location.search);
  const MODE = params.get('mode') || 'practice';          // lock | practice | welcome
  const HAS_EXT = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;
  if (MODE === 'lock') document.body.classList.add('embedded');

  // ---------- platform shims (let the page run standalone for previews) ----------
  const store = HAS_EXT
    ? { get: k => chrome.storage.local.get(k), set: o => chrome.storage.local.set(o) }
    : {
        get: async k => { const all = JSON.parse(localStorage.fq || '{}'); const out = {}; [].concat(k).forEach(x => { if (x in all) out[x] = all[x]; }); return out; },
        set: async o => { localStorage.fq = JSON.stringify({ ...JSON.parse(localStorage.fq || '{}'), ...o }); }
      };
  const bg = msg => HAS_EXT
    ? chrome.runtime.sendMessage(msg).catch(() => null)
    : Promise.resolve(msg.type === 'fq:state'
        ? { locked: MODE === 'lock', usedMs: 3600000, limitMs: 3600000, emergencyLeft: 1, settings: FQ_DEFAULTS, stats: { quizzesTaken: 3, quizzesPassed: 2, answered: 90, correct: 66, bestStreak: 11, xp: 7400, unlocks: 2, answeredByDay: {} } }
        : { passed: msg.total && msg.score / msg.total >= .7, achievements: [] });

  // ---------- helpers ----------
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rich = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>');
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const range = n => Array.from({ length: n }, (_, i) => i);
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const KEYS = 'ABCDEF';
  const mmss = ms => { const s = Math.max(0, Math.ceil(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

  const TOPIC_COLORS = {
    'Apex Triggers': '#a58bff', 'Async Apex': '#38bdf8', 'Governor Limits': '#ffb020', 'SOQL & DML': '#2ee6a6',
    'Exception Handling': '#ff7b7b', 'Apex Testing': '#7dd3fc', 'LWC': '#f472b6', 'JavaScript': '#facc15',
    'Integration': '#34d399', 'Platform Events & CDC': '#fb923c', 'Security & Sharing': '#ff6b8b', 'Data Model': '#60a5fa',
    'Assignment & Territory': '#a3e635', 'Flows': '#22d3ee', 'Order of Execution': '#c084fc', 'Validation & Formulas': '#fbbf24',
    'Custom Metadata & Settings': '#2dd4bf', 'Reports & Dashboards': '#818cf8', 'Deployment & DevOps': '#4ade80',
    'Experience Cloud': '#e879f9', 'Sales & Service Cloud': '#5eead4', 'Apex OOP & Platform': '#fda4af', 'Architecture & Design': '#fcd34d'
  };
  const colorOf = t => {
    if (TOPIC_COLORS[t]) return TOPIC_COLORS[t];
    let h = 0; for (const ch of String(t)) h = (h * 31 + ch.charCodeAt(0)) % 360;
    return `hsl(${h} 75% 65%)`;
  };

  const STREAK_BANNERS = { 3: '3 in a row', 5: '5 in a row', 10: '10 in a row', 15: '15 in a row', 20: '20 in a row', 25: '25 in a row', 30: '30 in a row' };
  const PRAISE = ['Correct.', 'Correct. Well reasoned.', 'Exactly right.', 'Correct. Clean call.', 'Spot on.'];
  const OOPS = ['Not quite.', 'Incorrect.'];
  const SOS_PHRASE = 'I choose to scroll';

  // ---------- sound ----------
  const Sound = (() => {
    let ctx = null, on = true, pack = 'arcade', vol = .7;
    const ac = () => (ctx = ctx || new (window.AudioContext || window.webkitAudioContext)());
    function tone(freq, t0, dur, type = 'sine', v = .16, slideTo) {
      const c = ac(), o = c.createOscillator(), g = c.createGain();
      let f = freq, s = slideTo, vv = v * vol;
      if (pack === 'soft') { type = 'sine'; f *= .8; s = s && s * .8; vv *= .6; dur *= 1.3; }
      if (pack === 'retro') { type = 'square'; vv *= .38; }
      o.type = type; o.frequency.setValueAtTime(f, c.currentTime + t0);
      if (s) o.frequency.exponentialRampToValueAtTime(s, c.currentTime + t0 + dur);
      g.gain.setValueAtTime(0.0001, c.currentTime + t0);
      g.gain.exponentialRampToValueAtTime(Math.max(.0002, vv), c.currentTime + t0 + .015);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t0 + dur);
      o.connect(g).connect(c.destination); o.start(c.currentTime + t0); o.stop(c.currentTime + t0 + dur + .05);
    }
    const play = fn => { if (!on || vol <= 0) return; try { fn(); } catch (_) {} };
    return {
      set enabled(v) { on = v; }, get enabled() { return on; },
      config(p) { pack = p.soundPack || 'arcade'; vol = Math.max(0, Math.min(1, (p.volume ?? 70) / 100)); },
      tap: () => play(() => tone(900, 0, .05, 'triangle', .05)),
      right: () => play(() => { tone(784, 0, .12, 'triangle', .14); tone(1175, .08, .22, 'sine', .14); }),
      wrong: () => play(() => { tone(260, 0, .22, 'sawtooth', .05, 150); tone(180, .06, .3, 'sine', .12, 110); }),
      streak: () => play(() => [1047, 1319, 1568, 2093].forEach((f, i) => tone(f, i * .06, .18, 'triangle', .1))),
      pass: () => play(() => [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, i * .09, .35, i % 2 ? 'sine' : 'triangle', .13))),
      fail: () => play(() => [392, 330, 262].forEach((f, i) => tone(f, i * .16, .32, 'sine', .12))),
      fifty: () => play(() => { tone(600, 0, .1, 'square', .04, 1200); tone(1200, .1, .12, 'square', .04, 600); }),
      swap: () => play(() => { tone(500, 0, .12, 'triangle', .08, 900); tone(900, .1, .12, 'triangle', .08, 500); }),
      tick: () => play(() => tone(1400, 0, .03, 'square', .025)),
      trophy: () => play(() => [784, 988, 1175, 1568].forEach((f, i) => tone(f, i * .1, .4, 'triangle', .12)))
    };
  })();

  // ---------- confetti ----------
  const Confetti = (() => {
    const cv = $('confetti'), cx = cv.getContext('2d');
    let parts = [], raf = 0, enabled = true, scale = 1;
    const COLORS = () => { const cs = getComputedStyle(document.documentElement); return ['--accent', '--accent-2', '--good', '--bad', '--warn', '--info'].map(v => cs.getPropertyValue(v).trim() || '#fff').concat('#ffffff'); };
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    function size() { cv.width = innerWidth * devicePixelRatio; cv.height = innerHeight * devicePixelRatio; }
    addEventListener('resize', size); size();
    function spawn(x, y, n, spread = Math.PI * 2, power = 9, dir = -Math.PI / 2) {
      if (reduce || !enabled) return;
      const cols = COLORS();
      n = Math.round(n * scale);
      for (let i = 0; i < n; i++) {
        const a = dir + (Math.random() - .5) * spread, v = power * (.45 + Math.random() * .8);
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, r: 4 + Math.random() * 6, rot: Math.random() * 6, vr: (Math.random() - .5) * .35,
          c: pick(cols), shape: Math.random() < .3 ? 'c' : 'r', life: 0, max: 90 + Math.random() * 70 });
      }
      if (!raf) raf = requestAnimationFrame(tick);
    }
    function tick() {
      cx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
      cx.clearRect(0, 0, innerWidth, innerHeight);
      parts = parts.filter(p => p.life < p.max && p.y < innerHeight + 40);
      for (const p of parts) {
        p.life++; p.vy += .22; p.vx *= .99; p.vy *= .99; p.x += p.vx; p.y += p.vy; p.rot += p.vr;
        cx.save(); cx.globalAlpha = Math.max(0, 1 - p.life / p.max); cx.translate(p.x, p.y); cx.rotate(p.rot); cx.fillStyle = p.c;
        if (p.shape === 'c') { cx.beginPath(); cx.arc(0, 0, p.r / 2, 0, 7); cx.fill(); } else cx.fillRect(-p.r / 2, -p.r / 4, p.r, p.r / 2);
        cx.restore();
      }
      raf = parts.length ? requestAnimationFrame(tick) : 0;
    }
    return {
      config(p) { enabled = p.confetti !== false && p.motion !== 'off'; scale = p.motion === 'calm' ? .4 : 1; },
      burst(el, n = 40) { const r = el.getBoundingClientRect(); spawn(r.left + r.width / 2, r.top + r.height / 2, n, Math.PI * 2, 7); },
      cannons() { spawn(0, innerHeight * .8, 120, 1, 22, -Math.PI / 3); spawn(innerWidth, innerHeight * .8, 120, 1, 22, -Math.PI * 2 / 3); },
      rain(ms = 2600) { if (!enabled) return; const end = Date.now() + ms; (function drop() { spawn(Math.random() * innerWidth, -20, 6, 1, 3, Math.PI / 2); if (Date.now() < end) setTimeout(drop, 60); })(); }
    };
  })();

  function floatText(text, el, big = false) {
    const r = el.getBoundingClientRect();
    const f = document.createElement('div');
    f.className = 'floater' + (big ? ' big' : '');
    f.textContent = text;
    f.style.left = (r.left + r.width / 2) + 'px';
    f.style.top = (r.top) + 'px';
    $('floatLayer').appendChild(f);
    setTimeout(() => f.remove(), 1200);
  }
  function banner(text) {
    const b = document.createElement('div');
    b.className = 'banner'; b.textContent = text;
    document.body.appendChild(b);
    setTimeout(() => b.remove(), 1500);
  }

  function toast(title, sub) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<div>${esc(title)}${sub ? `<small>${esc(sub)}</small>` : ''}</div>`;
    $('toastLayer').appendChild(t);
    setTimeout(() => t.remove(), 4200);
  }
  function announce(t) { $('live').textContent = t; }

  // ---------- state ----------
  let BANK = [];
  let settings = { ...FQ_DEFAULTS };   // Focus timer and unlock-quiz rules (lock mode only)
  let stats = {};
  let pub = {};                        // last fq:state
  let prefs = { ...FQ_PREFS };
  let starred = new Set();
  let SITE = null;
  let S = null;                        // current session
  let screen = 'welcome';
  // Practice rules (edited in Settings > Practice) apply to Practice only.
  const PRACTICE_DEFAULTS = { len: 10, diff: 'any', timer: 0, shuffle: true, fifty: 1, skip: 1, topics: null };
  let rules = { ...PRACTICE_DEFAULTS };
  const practice = { mode: params.get('pmode') || 'smart', topics: null, touched: false };   // per visit: deep-link mode and quick topic pick
  let qTick = 0, lastTickAt = 0, lastSaveAt = 0, autoNext = 0;
  let LB = null;                       // leaderboard identity { code, name, linkedin, joinedAt } or null
  const DAILY = { state: 'loading', info: null, error: '' };   // loading | join | restore | ready | playing | done | offline
  const SQ = {};                       // questions of the ranked (server) daily, keyed by synthetic id
  let pending = false, clockTimer = 0, nextTimer = 0;
  const NUDGE_KEY = 'recoveryNudgeDone';

  const qById = id => SQ[id] || BANK.find(q => q.id === id);
  const needed = total => Math.ceil(total * settings.passPercent / 100);
  // The starter bank is small: a lock quiz can never be longer than the questions available.
  const lockCount = () => Math.max(1, Math.min(settings.questionsPerQuiz, BANK.length || settings.questionsPerQuiz));
  // You may miss (total - needed) questions; the next miss after that ends the round.
  const livesFor = total => total - needed(total) + 1;
  const hasLives = () => S && S.mode === 'lock' && S.livesOn;
  const correctCount = () => S.answers.filter(a => a && a.correct).length;
  const wrongCount = () => S.answers.filter(a => a && !a.correct).length;

  // Only the Focus unlock quiz survives a reload locally; the ranked daily lives on the server.
  async function saveSession() {
    if (S && S.mode === 'lock') { S.updatedAt = Date.now(); await store.set({ activeQuiz: S }); }
  }

  // ---------- question bank ----------
  function normalizeQ(q, i, prefix) {
    if (!q || typeof q !== 'object') return null;
    const options = (Array.isArray(q.options) ? q.options : []).map(o => String(o)).filter(o => o.trim()).slice(0, 6);
    let answer = q.answer;
    if (typeof answer === 'string' && /^[A-Fa-f]$/.test(answer.trim())) answer = KEYS.indexOf(answer.trim().toUpperCase());
    answer = Number(answer);
    if (!q.q || options.length < 2 || !(answer >= 0 && answer < options.length)) return null;
    return {
      id: q.id ? String(q.id) : `${prefix}${i}`, topic: String(q.topic || 'General').slice(0, 60),
      difficulty: ['easy', 'medium', 'hard'].includes(q.difficulty) ? q.difficulty : 'medium',
      q: String(q.q), code: q.code ? String(q.code) : '', options, answer, explanation: q.explanation ? String(q.explanation) : ''
    };
  }
  async function loadBank() {
    let builtin = [];
    try {
      const url = HAS_EXT ? chrome.runtime.getURL('data/questions.json') : '../data/questions.json';
      builtin = (await (await fetch(url)).json()).map((q, i) => normalizeQ(q, i, 'b-')).filter(Boolean);
    } catch (_) {}
    const { customBank = [] } = await store.get('customBank');
    const custom = customBank.map((q, i) => normalizeQ({ ...q, id: q.id || `u-${i}` }, i, 'u-')).filter(Boolean);
    const src = settings.bankSource;
    BANK = src === 'custom' && custom.length ? custom : src === 'both' ? builtin.concat(custom) : builtin;
    if (!BANK.length) BANK = custom.length ? custom : builtin;
  }

  const DIFF_RANK = { easy: 0, medium: 1, hard: 2 };
  function basePool({ topics, diff }) {
    let pool = BANK.filter(q => !topics || topics.has(q.topic));
    if (diff === 'easy') pool = pool.filter(q => q.difficulty !== 'hard');
    else if (diff === 'hard') pool = pool.filter(q => q.difficulty !== 'easy');
    else if (['easy-only', 'medium', 'hard-only'].includes(diff)) pool = pool.filter(q => q.difficulty === diff.replace('-only', ''));
    return pool;
  }
  function modePool(pool, mode, qstats) {
    if (mode === 'mistakes') return pool.filter(q => qstats[q.id] && qstats[q.id].correct < qstats[q.id].seen);
    if (mode === 'starred') return pool.filter(q => starred.has(q.id));
    if (mode === 'unseen') return pool.filter(q => !qstats[q.id]);
    return pool;
  }
  function weigh(pool, qstats) {
    const now = Date.now();
    return pool.map(q => {
      const s = qstats[q.id];
      let w = Math.random();
      if (!s) w += 1.4;                                        // never seen → priority
      else {
        w += (1 - s.correct / Math.max(1, s.seen)) * 1.6;      // got it wrong before → more likely
        w += Math.min((now - s.last) / 864e5, 7) / 7 * .8;     // haven't seen in a while → more likely
      }
      return { q, w };
    }).sort((a, b) => b.w - a.w).map(x => x.q);
  }
  function order(qs, how) {
    if (how === 'mixed') return shuffle(qs.slice());
    // gentle difficulty ramp with jitter so it never feels predictable
    return qs.map(q => ({ q, k: (DIFF_RANK[q.difficulty] ?? 1) + Math.random() * 1.8 })).sort((a, b) => a.k - b.k).map(x => x.q);
  }
  function lockFilter() {
    return { topics: settings.lockTopics ? new Set(settings.lockTopics) : null, diff: settings.difficulty };
  }
  function practiceFilter() {
    const d = { any: null, easy: 'easy-only', medium: 'medium', hard: 'hard-only' }[rules.diff];
    return { topics: practice.topics, diff: d };
  }
  function selectQuestions(n, mode, qstats) {
    if (mode === 'lock') {
      let pool = basePool(lockFilter());
      if (pool.length < n) pool = pool.concat(basePool({ topics: lockFilter().topics }).filter(q => !pool.includes(q)));
      if (pool.length < n) pool = pool.concat(BANK.filter(q => !pool.includes(q)));
      return order(weigh(pool, qstats).slice(0, n), settings.difficulty === 'mixed' ? 'mixed' : 'ramp');
    }
    const pool = modePool(basePool(practiceFilter()), practice.mode, qstats);
    return order(weigh(pool, qstats).slice(0, n), 'ramp');
  }
  const permFor = (q, mode) => (mode === 'lock' ? settings.shuffleOptions : rules.shuffle) ? shuffle(range(q.options.length)) : range(q.options.length);

  async function newSession(mode) {
    const { qstats = {} } = await store.get('qstats');
    const lock = mode === 'lock';
    const qs = selectQuestions(lock ? lockCount() : rules.len, mode, qstats);
    const fifty = lock ? settings.fiftyCount : rules.fifty, skip = lock ? settings.skipCount : rules.skip;
    S = {
      mode, ids: qs.map(q => q.id), perms: qs.map(q => permFor(q, mode)), day: FQ_dayKey(),
      i: 0, answers: [], xp: 0, streak: 0, bestStreak: 0, lifelines: 0, speedy: 0,
      fiftyMax: fifty, skipMax: skip, fiftyLeft: fifty, skipLeft: skip, fiftyOn: null,
      livesOn: lock && settings.livesOn,
      timer: lock ? settings.questionTimer : rules.timer, tLeft: 0, tFor: -1,
      startedAt: Date.now(), updatedAt: Date.now(), over: false
    };
    await saveSession();
  }

  // ---------- screens ----------
  const SCREENS = ['welcome', 'daily', 'practice', 'intro', 'quiz', 'results'];
  function show(name) {
    screen = name;
    for (const id of SCREENS) $(id).hidden = id !== name;
    $('pTheme').hidden = !(MODE === 'practice' && name === 'practice');   // System / Light / Dark lives in the top bar, not during a round
    if (name !== 'daily') clearInterval(nextTimer);
    const el = $(name); el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
    scrollTo({ top: 0, behavior: 'auto' });
  }

  const chip = html => `<span class="chip">${html}</span>`;
    const fmtTime = ms => { const t = Math.max(0, Math.round(ms / 1000)); return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`; };
  async function copyText(text) {
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_) {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { ok = document.execCommand('copy'); } catch (_) {} ta.remove();
    }
    toast(ok ? 'Copied to clipboard' : 'Could not copy', ok ? 'Paste it anywhere' : '');
    return ok;
  }
  function setNotice(text) { const el = $('lbNotice'); el.textContent = text || ''; el.hidden = !text; }
  const showErr = (id, msg) => { const e = $(id); e.textContent = msg || ''; e.hidden = !msg; };
  const webLink = async path => String(await SFDQ_API.webUrl()).replace(/\/+$/, '') + path;
  const openUrl = url => { if (HAS_EXT && chrome.tabs) chrome.tabs.create({ url }); else window.open(url, '_blank', 'noopener'); };
  const openBoard = async () => openUrl(await webLink('/#/board'));
  const openEditRules = () => { const url = HAS_EXT ? chrome.runtime.getURL('src/options.html#practice') : 'options.html#practice'; openUrl(url); };

  // ---------- Focus unlock quiz intro (lock mode only) ----------
  function renderIntro(resumable) {
    const total = lockCount();
    $('restartBtn').hidden = !resumable;
    $('whyCard').hidden = !settings.why;
    $('whyText').textContent = settings.why;
    $('emergencyBtn').hidden = true;
    $('cooldownNote').hidden = true;
    $('introEyebrow').textContent = SITE ? `${SITE.name} is paused` : 'Scroll paused';
    $('introTitle').textContent = 'Time for a quick review.';
    const used = Math.round((pub.limitMs || settings.limitMinutes * 60000) / 60000);
    $('introLede').innerHTML = `You've used your <b>${used} minutes</b> of social time. Score <b>${needed(total)} of ${total}</b> to unlock another <b>${settings.rewardMinutes}</b>.`;
    $('introChips').innerHTML = [
      chip(`<b>${total}</b> questions`), chip(`<b>${settings.passPercent}%</b> to pass`),
      settings.livesOn ? chip(`<b>${livesFor(total)}</b> lives`) : chip('no lives'),
      settings.questionTimer ? chip(`<b>${settings.questionTimer}s</b> each`) : '',
      settings.fiftyCount ? chip(`<b>${settings.fiftyCount}</b> × 50:50`) : '',
      settings.skipCount ? chip(`<b>${settings.skipCount}</b> × swap`) : ''
    ].join('');
    $('startLabel').textContent = resumable ? `Resume · Q${Math.min(S.answers.length + 1, S.ids.length)} of ${S.ids.length}` : "Let's go";
    if (settings.emergencyPerWeek > 0) {
      const left = pub.emergencyLeft ?? 0;
      $('emergencyBtn').hidden = false;
      $('emergencyBtn').disabled = left <= 0;
      $('emergencyBtn').textContent = left > 0 ? `Emergency pass (${left} left this week)` : 'No emergency passes left this week';
    }
    applyCooldown();
    show('intro');
  }

  // Retry cooldown after a failed lock round.
  let coolTimer = 0;
  function applyCooldown(btn = $('startBtn'), label = $('startLabel')) {
    clearInterval(coolTimer);
    const until = pub.failUntil || 0;
    if (!until || until <= Date.now() || (S && S.answers.length)) { btn.disabled = false; return; }
    const original = label.textContent;
    const paint = () => {
      const left = until - Date.now();
      if (left <= 0) { clearInterval(coolTimer); btn.disabled = false; label.textContent = original; $('cooldownNote').hidden = true; return; }
      btn.disabled = true;
      label.textContent = `Next attempt in ${mmss(left)}`;
      $('cooldownNote').hidden = false;
      $('cooldownNote').textContent = 'Cooldown. Skim your misses, grab water, come back sharper.';
    };
    paint(); coolTimer = setInterval(paint, 500);
  }

  // ---------- welcome ----------
  function renderWelcome() {
    $('wFocus').hidden = !!settings.blockerOn;   // the Focus timer is invisible once it is on
    show('welcome');
  }

  // ---------- daily (always the ranked server set) ----------
  const utcRecord = () => (stats.daily || {})[FQ_utcDay()] || null;
  const rankedRecord = () => { const r = utcRecord(); return r && r.ranked ? r : null; };
  const untilNext = () => {
    const m = Math.max(0, Math.floor((FQ_nextUtcMidnight() - Date.now()) / 60000)), h = Math.floor(m / 60);
    return h ? `${h}h ${m % 60}m` : `${Math.max(1, m)}m`;
  };

  // Work out where today stands, then paint. Never fabricates a set: no server, no daily.
  async function loadDaily() {
    setNotice('');
    if (!LB) { DAILY.state = 'join'; paintDaily(); return; }
    const rec = rankedRecord();
    DAILY.state = rec ? 'done' : 'loading'; DAILY.error = '';
    paintDaily();
    try {
      const info = await SFDQ_API.dailyInfo();
      DAILY.info = info;
      if (info.status === null) DAILY.state = 'restore';   // the server does not recognise the saved code
      else if (info.status === 'done') {
        if (info.result && !(stats.daily || {})[info.day]) await syncServerResult(info.result);
        DAILY.state = 'done';
      } else DAILY.state = info.status === 'playing' ? 'playing' : 'ready';
    } catch (e) {
      if (e.code === 'unauthorized') DAILY.state = 'restore';
      else if (rec) DAILY.state = 'done';
      else { DAILY.state = 'offline'; DAILY.error = e.network ? '' : (e.message || ''); }
    }
    if (screen === 'daily') paintDaily();
  }

  function setCta(items) {
    $('dCta').innerHTML = items.map(([id, label, cls]) => `<button class="btn ${cls}" id="${id}" type="button">${label}</button>`).join('');
  }
  function showJoinMode(mode, note) {
    $('joinCard').hidden = false;
    $('joinForm').hidden = mode !== 'join';
    $('restoreForm').hidden = mode !== 'restore';
    $('restoreNote').textContent = note || 'Only needed on a different computer or browser. On the same browser your account is linked automatically.';
    $('restoreNote').hidden = false;
    showErr('joinErr', ''); showErr('restoreErr', '');
  }

  function paintDaily() {
    const st = DAILY.state, ds = FQ_dailyStats(stats.daily);
    $('joinCard').hidden = true; $('dChips').hidden = true; $('dQuiet').hidden = true; $('dCta').innerHTML = '';
    clearInterval(nextTimer);
    const setHead = (title, lede) => { $('dTitle').textContent = title; $('dLede').innerHTML = lede; $('dLede').hidden = !lede; };
    const standard = () => setHead("Today's five.", 'Same questions for everyone. One attempt. Ranked by score, then time.');

    if (st === 'join') {
      standard();
      showJoinMode('join');
    } else if (st === 'restore') {
      standard();
      showJoinMode('restore', 'The recovery code saved on this device is no longer accepted. Enter a recovery code, or join again.');
    } else if (st === 'offline') {
      setHead('Daily needs a connection.', 'Practice works offline.');
      setCta([['dRetry', 'Retry', 'primary big'], ['dPractice', 'Start practice', 'ghost']]);
      if (DAILY.error) setNotice(DAILY.error);
    } else if (st === 'done') {
      const r = (DAILY.info && DAILY.info.result) || rankedRecord() || {};
      const score = r.score ?? 0, total = r.total ?? 5;
      const parts = [];
      if (r.flagged) parts.push('That run was too quick to rank, so it is not on the leaderboard. Your score is saved.');
      else {
        if (r.rank) parts.push(`<b>Rank ${r.rank}</b> of ${r.players}${Number.isFinite(r.timeMs) ? `, in ${fmtTime(r.timeMs)}` : ''}.`);
        else if (Number.isFinite(r.timeMs)) parts.push(`Finished in ${fmtTime(r.timeMs)}.`);
        if (r.percentile != null) parts.push(`You beat <b>${r.percentile}%</b> of players today.`);
      }
      setHead(`Today: ${score}/${total}`, parts.join(' '));
      if (ds.current > 0) { $('dChips').hidden = false; $('dChips').innerHTML = chip(`Streak <b>${ds.current}</b>`); }
      setCta([['dBoard', 'Leaderboard', 'primary big'], ['dPractice', 'Practice', 'ghost']]);
      const paintNext = () => { $('dQuiet').hidden = false; $('dQuiet').textContent = `Next challenge in ${untilNext()}`; };
      paintNext(); nextTimer = setInterval(paintNext, 15000);
    } else {
      // loading | ready | playing
      standard();
      if (ds.current > 0) { $('dChips').hidden = false; $('dChips').innerHTML = chip(`Streak <b>${ds.current}</b>`); }
      setCta([['dStart', st === 'playing' ? 'Resume' : 'Start', 'primary big']]);
      $('dStart').disabled = st === 'loading';
      $('dQuiet').hidden = false; $('dQuiet').textContent = 'Practice rules do not apply to the daily.';
    }
    const on = (id, fn) => { const b = $(id); if (b) b.onclick = () => fn(b); };
    on('dStart', b => { Sound.tap(); startDaily(b); });
    on('dRetry', b => { Sound.tap(); b.disabled = true; b.textContent = 'Checking…'; loadDaily(); });
    on('dPractice', () => { location.search = '?mode=practice'; });
    on('dBoard', () => openBoard());
  }

  // ---------- leaderboard identity: join and restore ----------
  // Joins with the typed name, or (skip) with no name so the server picks one, then goes straight into today's set.
  async function doJoin(skip) {
    const btn = $('joinBtn'), skipBtn = $('skipJoin');
    btn.disabled = true; skipBtn.disabled = true; showErr('joinErr', '');
    btn.textContent = 'Joining…';
    try {
      await SFDQ_API.register(skip ? { consent: true } : { name: $('joinName').value, linkedin: $('joinLinkedin').value, consent: true });
      LB = await SFDQ_API.identity();
      DAILY.info = null;
      btn.disabled = false; skipBtn.disabled = false; btn.textContent = 'Join and play';
      await startDaily(btn, true);       // straight into today's set
      return;
    } catch (err) {
      showErr('joinErr', err.message);
      if ((err.code || '').includes('linkedin')) $('joinLiFold').open = true;
    }
    btn.disabled = false; skipBtn.disabled = false; btn.textContent = 'Join and play';
  }
  function wireJoin() {
    SFDQ_API.webUrl().then(u => { $('privacyLink').href = String(u).replace(/\/+$/, '') + '/privacy'; $('linkWeb').href = String(u).replace(/\/+$/, '') + '/'; });
    $('joinForm').addEventListener('submit', async e => {
      e.preventDefault();
      if (!$('joinName').value.trim()) { showErr('joinErr', 'Enter a display name, or skip and play with a random name.'); $('joinName').focus(); return; }
      await doJoin(false);
    });
    $('skipJoin').addEventListener('click', () => doJoin(true));
    $('toRestore').addEventListener('click', () => { showJoinMode('restore'); $('restoreCode').focus(); });
    $('toJoin').addEventListener('click', () => { showJoinMode('join'); $('joinName').focus(); });
    $('restoreForm').addEventListener('submit', async e => {
      e.preventDefault();
      const btn = $('restoreBtn'); btn.disabled = true; showErr('restoreErr', '');
      try {
        await SFDQ_API.restore($('restoreCode').value);
        LB = await SFDQ_API.identity();
        DAILY.info = null; $('restoreCode').value = '';
        toast('Signed in', LB.name || '');
        await loadDaily();
      } catch (err) { showErr('restoreErr', err.message); }
      btn.disabled = false;
    });
  }

  // Store a ranked result we did not play on this device (or lost) so streaks and the board stay right.
  async function syncServerResult(r) {
    let grid = '';
    try { const rv = await SFDQ_API.review(r.day); grid = (rv.review && rv.review.questions || []).map(q => q.correct ? '■' : '□').join(''); } catch (_) {}
    await bg({ type: 'fq:syncDaily', day: r.day, score: r.score, total: r.total, grid, flagged: r.flagged, timeMs: r.timeMs, rank: r.rank, players: r.players, percentile: r.percentile });
    const st = await bg({ type: 'fq:state' });
    if (st && st.stats) stats = st.stats;
  }

  // ---------- ranked daily (server) ----------
  const gainFor = q => Math.round(({ easy: 100, medium: 150, hard: 200 }[q.difficulty] || 150) * (1 + Math.min(S.streak - 1, 5) * .2));
  function buildServerSession(r) {
    const ids = r.questions.map(q => {
      const id = `srv-${r.day}-${q.i}`;
      SQ[id] = { id, topic: q.topic || 'General', difficulty: q.difficulty || 'medium', q: q.q, code: q.code || '', options: q.options, answer: -1, explanation: '' };
      return id;
    });
    S = {
      mode: 'daily', server: true, day: r.day, ids, perms: ids.map(id => range(SQ[id].options.length)),
      i: 0, answers: [], xp: 0, streak: 0, bestStreak: 0, lifelines: 0, speedy: 0, fiftyLeft: 0, skipLeft: 0, fiftyOn: null,
      livesOn: false, timer: 0, tLeft: 0, tFor: -1, startedAt: r.startedAt, clockOffset: (r.serverNow || Date.now()) - Date.now(), updatedAt: Date.now(), over: false
    };
    (r.answered || []).forEach((a, k) => {
      if (!a) return;
      const q = SQ[ids[k]]; q.answer = a.answer; q.explanation = a.explanation || '';
      S.answers[k] = { picked: a.choice, correct: !!a.correct };
      if (a.correct) { S.streak++; S.bestStreak = Math.max(S.bestStreak, S.streak); S.xp += gainFor(q); } else S.streak = 0;
    });
    S.i = Math.max(0, ids.findIndex((_, k) => !S.answers[k]));
  }
  // Starts (or resumes) today's ranked set. Any failure ends on an honest screen, never a substitute set.
  async function startDaily(btn, fromJoin) {
    const was = btn && btn.textContent;
    if (btn) { btn.disabled = true; btn.textContent = 'Starting…'; }
    try {
      const r = await SFDQ_API.dailyStart();
      buildServerSession(r); setNotice('');
      if (btn) { btn.disabled = false; btn.textContent = was; }
      startQuiz();
    } catch (e) {
      if (btn) { btn.disabled = false; btn.textContent = was; }
      if (e.code === 'already_played') {
        DAILY.info = { status: 'done', day: FQ_utcDay(), result: e.result };
        if (e.result) await syncServerResult(e.result);
        DAILY.state = 'done';
      } else if (e.code === 'unauthorized') DAILY.state = 'restore';
      else { DAILY.state = 'offline'; DAILY.error = e.network ? '' : (e.message || ''); }
      paintDaily();
    }
  }
  function paintClock() {
    clearInterval(clockTimer);
    const el = $('qElapsed');
    el.hidden = !(S && S.server);
    if (!S || !S.server) return;
    const tick = () => {
      if (!S || !S.server) return clearInterval(clockTimer);
      const ms = S.srvResult ? S.srvResult.timeMs : Date.now() + S.clockOffset - S.startedAt;
      el.textContent = 'Time ' + fmtTime(ms);
      if (S.srvResult) clearInterval(clockTimer);
    };
    tick(); clockTimer = setInterval(tick, 500);
  }

  // ---------- practice ----------
  const DIFF_LABEL = { any: 'any difficulty', easy: 'easy only', medium: 'medium only', hard: 'hard only' };
  const MODE_LABEL = { mistakes: 'questions you missed', starred: 'bookmarked questions', unseen: 'questions you have not seen' };
  const num = (v, lo, hi, d) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
  // Practice rules live in Settings > Practice: prefs.practice{Length,Difficulty,Timer,Topics}, plus settings.{shuffleOptions,fiftyCount,skipCount}.
  async function loadRules() {
    const [{ prefs: p = {} }, st] = await Promise.all([store.get('prefs'), bg({ type: 'fq:state' })]);
    if (st && st.settings) settings = { ...settings, ...st.settings };
    prefs = { ...FQ_PREFS, ...p };
    rules = {
      len: num(prefs.practiceLength, 1, 100, 10), diff: ['any', 'easy', 'medium', 'hard'].includes(prefs.practiceDifficulty) ? prefs.practiceDifficulty : 'any',
      timer: num(prefs.practiceTimer, 0, 300, 0), shuffle: settings.shuffleOptions !== false, fifty: num(settings.fiftyCount, 0, 5, 1), skip: num(settings.skipCount, 0, 5, 1),
      topics: Array.isArray(prefs.practiceTopics) && prefs.practiceTopics.length ? prefs.practiceTopics.map(String) : null
    };
  }
  function topicCounts() { const c = {}; BANK.forEach(q => c[q.topic] = (c[q.topic] || 0) + 1); return c; }
  const missedTopics = qstats => [...new Set(BANK.filter(q => qstats[q.id] && qstats[q.id].correct < qstats[q.id].seen).map(q => q.topic))];

  async function renderPractice() {
    await loadRules();
    const { qstats = {} } = await store.get('qstats');
    const counts = topicCounts(), all = Object.keys(counts);
    if (!practice.topics || !practice.touched) {
      const want = (params.get('topics') || '').split('|').filter(t => counts[t]);
      const saved = (rules.topics || []).filter(t => counts[t]);
      practice.topics = new Set(want.length ? want : saved.length ? saved : all);
      if (want.length) $('topicsFold').open = true;
    }
    const miss = missedTopics(qstats);
    $('pWeak').hidden = !miss.length;
    $('pWeak').onclick = () => { practice.topics = new Set(miss); practice.touched = true; startPractice(); };
    paintPractice(qstats, counts);
    show('practice');
  }

  function paintPractice(qstats, counts) {
    const all = Object.keys(counts), n = practice.topics.size;
    const topicsText = n === all.length ? 'all topics' : n === 0 ? 'no topics' : n === 1 ? '1 topic' : `${n} of ${all.length} topics`;
    $('pSummary').textContent = [`${rules.len} question${rules.len === 1 ? '' : 's'}`, DIFF_LABEL[rules.diff], topicsText,
      rules.timer ? `${rules.timer}s per question` : '', MODE_LABEL[practice.mode] ? MODE_LABEL[practice.mode] : ''].filter(Boolean).join(', ');
    $('topicsSum').textContent = n === all.length ? 'All topics' : n ? `${n} of ${all.length}` : 'None selected';
    $('topicGrid').innerHTML = all.sort().map(t =>
      `<button type="button" class="chip-toggle" style="--c:${colorOf(t)}" aria-pressed="${practice.topics.has(t)}" data-t="${esc(t)}">${esc(t)}</button>`).join('');
    const size = modePool(basePool(practiceFilter()), practice.mode, qstats).length;
    const empty = { mistakes: 'No missed questions to review yet. Nice.', starred: 'Nothing bookmarked yet. Tap the star on any question to save it.', unseen: 'You have seen every question in this selection.' }[practice.mode];
    const note = $('poolNote');
    note.hidden = false;
    if (!n) note.textContent = 'Pick at least one topic.';
    else if (!size) note.textContent = empty || 'No questions match these rules. Edit rules or pick more topics.';
    else if (size < rules.len) note.textContent = size === 1 ? 'Only 1 question matches these rules.' : `Only ${size} questions match these rules.`;
    else note.hidden = true;
    $('pStart').disabled = size === 0 || !n;
    $('topicGrid').onclick = e => {
      const b = e.target.closest('button'); if (!b) return;
      const t = b.dataset.t; practice.topics.has(t) ? practice.topics.delete(t) : practice.topics.add(t);
      practice.touched = true; Sound.tap(); paintPractice(qstats, counts);
    };
    $('topicAll').onclick = () => { practice.topics = new Set(all); practice.touched = true; paintPractice(qstats, counts); };
    $('topicNone').onclick = () => { practice.topics = new Set(); practice.touched = true; paintPractice(qstats, counts); };
  }

  async function startPractice() {
    if (!practice.topics || practice.topics.size === 0) return;
    await newSession('practice');
    if (!S.ids.length) { toast('No questions match', 'Edit your rules or pick more topics.'); return; }
    startQuiz();
  }

  // ---------- quiz ----------
  function renderHud() {
    const total = S.ids.length;
    const q = qById(S.ids[S.i]);
    const answered = !!S.answers[S.i];
    $('qNum').textContent = Math.min(S.i + 1, total);
    $('qTotal').textContent = total;
    $('xpNum').textContent = S.xp.toLocaleString();
    $('streakNum').textContent = S.streak;
    $('streak').classList.toggle('hot', S.streak >= 3);
    const daily = S.mode === 'daily';
    $('fiftyBtn').hidden = !(S.fiftyMax ?? settings.fiftyCount) || daily;
    $('fiftyBtn').disabled = S.fiftyLeft <= 0 || answered || (S.fiftyOn && S.fiftyOn.i === S.i) || !q || q.options.length < 3;
    $('fiftyLeft').textContent = S.fiftyLeft > 1 ? S.fiftyLeft : '';
    $('skipBtn').hidden = !(S.skipMax ?? settings.skipCount) || daily;
    $('streak').hidden = daily; $('xpNum').parentElement.hidden = daily;   // the ranked set is scored on answers and time only
    $('skipBtn').disabled = S.skipLeft <= 0 || answered;
    $('skipLeft').textContent = S.skipLeft > 1 ? S.skipLeft : '';
    $('soundBtn').textContent = Sound.enabled ? 'Sound' : 'Muted';

    const lives = $('lives');
    if (hasLives()) {
      const max = livesFor(total), left = max - wrongCount();
      lives.hidden = false;
      lives.title = `${Math.max(0, left)} of ${max} mistakes left`;
      lives.innerHTML = Array.from({ length: max }, (_, k) => `<span class="heart${k >= left ? ' lost' : ''}"></span>`).join('');
    } else lives.hidden = true;

    $('track').innerHTML = S.ids.map((_, k) => {
      const a = S.answers[k];
      return `<i class="seg-pip${a ? (a.correct ? ' ok' : ' no') : k === S.i ? ' now' : ''}"></i>`;
    }).join('');
  }

  function highlight(code) {
    const re = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`[^`]*`)|(@\w+)|(\b\d+(?:\.\d+)?\b)|(\b(?:public|private|protected|global|static|final|class|interface|extends|implements|virtual|abstract|override|with|without|inherited|sharing|void|return|new|if|else|for|while|do|try|catch|finally|throw|trigger|on|before|after|insert|update|delete|undelete|upsert|merge|this|super|null|true|false|const|let|var|function|async|await|import|export|from|default|of|in|instanceof|typeof|select|where|limit|order|by|and|or|not|def|elif|lambda|SELECT|FROM|WHERE|LIMIT|ORDER|BY|AND|OR|NOT|IN|FOR|UPDATE|WITH|USER_MODE|SECURITY_ENFORCED|Database|System|Test|List|Set|Map|String|Integer|Boolean|Id|Decimal|Date|Datetime|Object|SObject)\b)/g;
    let out = '', last = 0, m;
    while ((m = re.exec(code))) {
      out += esc(code.slice(last, m.index));
      const cls = m[1] ? 'c' : m[2] ? 's' : m[3] ? 'a' : m[4] ? 'n' : /^[A-Z]/.test(m[5]) && !/^[A-Z_]+$/.test(m[5]) ? 't' : 'k';
      out += `<span class="${cls}">${esc(m[0])}</span>`;
      last = m.index + m[0].length;
    }
    return out + esc(code.slice(last));
  }

  function renderQuestion() {
    clearTimeout(autoNext);
    const q = qById(S.ids[S.i]);
    const perm = S.perms[S.i];
    const ans = S.answers[S.i];
    const card = $('card');
    card.classList.remove('enter', 'shake', 'glow'); void card.offsetWidth; card.classList.add('enter');

    const t = $('qTopic'); t.textContent = q.topic; t.style.setProperty('--c', colorOf(q.topic));
    const lv = { easy: 1, medium: 2, hard: 3 }[q.difficulty] || 2;
    $('qDiff').innerHTML = [1, 2, 3].map(k => `<i class="${k <= lv ? 'on' : ''}"></i>`).join('') + `&nbsp;${q.difficulty || 'medium'}`;
    $('qText').innerHTML = rich(q.q);
    const code = $('qCode');
    if (q.code) { code.hidden = false; code.firstElementChild.innerHTML = highlight(q.code); } else code.hidden = true;
    paintStar();

    $('options').innerHTML = perm.map((orig, k) => `
      <button class="opt" type="button" data-k="${k}">
        <span class="key">${KEYS[k]}</span><span class="txt">${rich(q.options[orig])}</span>
      </button>`).join('');
    $('explain').hidden = true;
    const n = q.options.length;
    const k = t => `<span class="kbd">${t}</span>`;
    $('hint').innerHTML = `Keys: ${k('A')}–${k(KEYS[n - 1])} or ${k(1)}–${k(n)} answer · ${k('Enter')} next` +
      (S.mode === 'daily' ? ` · ${k('M')} mute` : ` · ${k('F')} 50:50 · ${k('W')} swap · ${k('B')} bookmark · ${k('M')} mute`);
    $('starBtn').hidden = S.mode === 'daily';
    paintReport();

    if (S.fiftyOn && S.fiftyOn.i === S.i) applyFifty(S.fiftyOn.hide, false);
    renderHud();
    if (ans) paintAnswer(ans.picked, false);
    startTimer();
    paintClock();
  }

  function paintStar() {
    const id = S.ids[S.i];
    const on = starred.has(id);
    $('starBtn').textContent = on ? '★' : '☆';
    $('starBtn').setAttribute('aria-pressed', on);
    $('starBtn').title = on ? 'Bookmarked (B to remove)' : 'Bookmark for later (B)';
  }
  async function toggleStar() {
    if (screen !== 'quiz' || S.mode === 'daily') return;
    const id = S.ids[S.i];
    if (starred.has(id)) starred.delete(id); else { starred.add(id); floatText('Saved', $('starBtn')); }
    Sound.tap(); paintStar();
    await store.set({ starred: [...starred] });
  }

  // ---------- per-question timer ----------
  function startTimer() {
    cancelAnimationFrame(qTick);
    const on = S.timer > 0 && !S.answers[S.i];
    $('qTimer').hidden = !(S.timer > 0);
    $('qSecs').hidden = !(S.timer > 0);
    if (!(S.timer > 0)) return;
    if (S.tFor !== S.i) { S.tFor = S.i; S.tLeft = S.timer * 1000; }
    paintTimer();
    if (!on) return;
    lastTickAt = performance.now();
    const loop = now => {
      if (screen !== 'quiz' || S.answers[S.i]) return;
      const dt = now - lastTickAt; lastTickAt = now;
      if (document.visibilityState === 'visible' && $('sosModal').hidden) {
        const before = Math.ceil(S.tLeft / 1000);
        S.tLeft -= dt;
        const after = Math.ceil(S.tLeft / 1000);
        if (after !== before && after <= 5 && after > 0) Sound.tick();
        if (Date.now() - lastSaveAt > 1000) { lastSaveAt = Date.now(); saveSession(); }
      }
      paintTimer();
      if (S.tLeft <= 0) { answer(-1); return; }
      qTick = requestAnimationFrame(loop);
    };
    qTick = requestAnimationFrame(loop);
  }
  function paintTimer() {
    const frac = Math.max(0, S.tLeft / (S.timer * 1000));
    $('qTimerBar').style.transform = `scaleX(${frac})`;
    const low = S.tLeft <= 5000;
    $('qTimer').classList.toggle('low', low);
    $('qSecs').classList.toggle('low', low && !S.answers[S.i]);
    $('qSecs').textContent = ` ${Math.max(0, Math.ceil(S.tLeft / 1000))}s`;
  }

  function correctDisplayIndex() {
    const q = qById(S.ids[S.i]);
    return S.perms[S.i].indexOf(q.answer);
  }

  // ---------- lifelines ----------
  function applyFifty(hide, animate = true) {
    const opts = $('options').children;
    hide.forEach(k => opts[k] && opts[k].classList.add('gone'));
    if (animate) { Sound.fifty(); floatText('50:50!', $('fiftyBtn')); }
  }
  function useFifty() {
    if (screen !== 'quiz' || $('fiftyBtn').disabled || $('fiftyBtn').hidden) return;
    const n = S.perms[S.i].length;
    const right = correctDisplayIndex();
    const hide = shuffle(range(n).filter(k => k !== right)).slice(0, n - 2);
    S.fiftyLeft--; S.lifelines++; S.fiftyOn = { i: S.i, hide };
    applyFifty(hide);
    renderHud(); saveSession();
  }
  function useSkip() {
    if (screen !== 'quiz' || $('skipBtn').disabled || $('skipBtn').hidden) return;
    const cur = qById(S.ids[S.i]);
    const f = S.mode === 'lock' ? lockFilter() : practiceFilter();
    let pool = basePool(f).filter(q => !S.ids.includes(q.id));
    if (!pool.length) pool = BANK.filter(q => !S.ids.includes(q.id));
    if (!pool.length) { toast('No other questions to swap in'); return; }
    const same = pool.filter(q => q.difficulty === cur.difficulty);
    const next = pick(same.length ? same : pool);
    S.ids[S.i] = next.id; S.perms[S.i] = permFor(next);
    if (S.fiftyOn && S.fiftyOn.i === S.i) S.fiftyOn = null;
    S.skipLeft--; S.lifelines++; S.tFor = -1;
    Sound.swap(); floatText('Swapped', $('skipBtn'));
    saveSession(); renderQuestion();
  }

  // ---------- answering ----------
  async function answer(k) {
    if (screen !== 'quiz' || S.answers[S.i]) return;
    const timeout = k < 0;
    const btn = $('options').children[k];
    if (!timeout && (!btn || btn.classList.contains('gone'))) return;
    cancelAnimationFrame(qTick);
    const q = qById(S.ids[S.i]);
    if (S.server) {
      if (timeout || pending) return;
      pending = true;
      const opts = Array.from($('options').children);
      opts.forEach((b, idx) => { b.disabled = true; if (idx !== k) b.classList.add('dim'); });
      try {
        const r = await SFDQ_API.dailyAnswer(S.day, S.i, k);
        q.answer = r.answer; q.explanation = r.explanation || '';
        if (r.done && r.result) S.srvResult = r.result;
      } catch (e) {
        pending = false;
        opts.forEach(b => { b.disabled = false; b.classList.remove('dim'); });
        if (e.code === 'unauthorized') { setNotice('The server no longer accepts your recovery code. Use a recovery code in Settings to keep your ranked run.'); toast('Answer not sent', 'Sign-in needed'); }
        else toast(e.network ? 'Connection lost' : 'Answer not sent', e.network ? 'Your answer was not sent. Try again.' : e.message);
        return;
      }
      pending = false;
      if (screen !== 'quiz' || !S || !S.server) return;
    }
    const correct = !timeout && k === correctDisplayIndex();

    let gained = 0, speedy = false;
    if (correct) {
      S.streak++;
      S.bestStreak = Math.max(S.bestStreak, S.streak);
      const base = { easy: 100, medium: 150, hard: 200 }[q.difficulty] || 150;
      const mult = 1 + Math.min(S.streak - 1, 5) * .2;
      speedy = S.timer > 0 && S.tLeft > S.timer * 1000 * .6;
      if (speedy) S.speedy++;
      gained = Math.round(base * mult * (S.fiftyOn && S.fiftyOn.i === S.i ? .5 : 1) * (speedy ? 1.25 : 1));
      S.xp += gained;
    } else S.streak = 0;

    S.answers[S.i] = { picked: k, correct };
    const total = S.ids.length;
    if (hasLives() && wrongCount() >= livesFor(total)) S.over = true;
    saveSession();
    paintAnswer(k, true, gained, speedy);
  }

  function paintAnswer(k, fresh, gained = 0, speedy = false) {
    const q = qById(S.ids[S.i]);
    const right = correctDisplayIndex();
    const correct = k === right;
    const timeout = k < 0;
    const opts = Array.from($('options').children);
    opts.forEach((b, idx) => {
      b.disabled = true;
      if (idx === right) b.classList.add('right');
      else if (idx === k) b.classList.add('wrong');
      else b.classList.add('dim');
      if (idx === k) b.classList.add('picked');
    });

    const total = S.ids.length;
    const verdict = $('verdict');
    verdict.className = 'verdict ' + (correct ? 'good' : 'bad');
    verdict.textContent = correct ? (speedy ? 'Speedy! ' : '') + pick(PRAISE)
      : timeout ? `Time's up. The answer is ${KEYS[right]}.` : `${pick(OOPS)} The answer is ${KEYS[right]}.`;
    const showText = true;   // the reasoning is always shown after an answer
    $('explainText').innerHTML = showText ? rich(q.explanation || '') : '';
    $('explainText').hidden = !showText || !q.explanation;
    $('explain').classList.toggle('has-text', showText && !!q.explanation);
    const last = S.i === total - 1;
    $('nextLabel').textContent = S.over ? 'See results' : last ? 'Finish' : 'Next';
    $('explain').hidden = false;
    paintReport();
    renderHud();
    if (S.timer > 0) paintTimer();

    if (fresh) {
      const card = $('card');
      if (correct) {
        Sound.right();
        card.classList.add('glow');
        floatText(`+${gained}`, opts[k]);
        $('xpNum').parentElement.classList.remove('bump'); void card.offsetWidth; $('xpNum').parentElement.classList.add('bump');
        $('streak').classList.remove('bump'); void card.offsetWidth; $('streak').classList.add('bump');
        Confetti.burst(opts[k], 18);
        const msg = STREAK_BANNERS[S.streak];
        if (msg) { setTimeout(() => { banner(msg); Sound.streak(); Confetti.burst($('streak'), 60); }, 250); }
        if (S.mode === 'lock' && correctCount() === needed(total)) {
          setTimeout(() => { banner('Pass mark reached'); Sound.pass(); Confetti.cannons(); }, msg ? 1500 : 300);
        }
        announce('Correct. ' + (showText ? q.explanation || '' : ''));
              } else {
        Sound.wrong();
        card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake');
        if (hasLives()) {
          const hearts = $('lives').children;
          const idx = livesFor(total) - wrongCount();
          if (hearts[idx]) { hearts[idx].classList.remove('lost'); void hearts[idx].offsetWidth; hearts[idx].classList.add('breaking'); }
          const left = livesFor(total) - wrongCount();
          if (S.over) setTimeout(() => banner('No lives left'), 300);
          else if (left === 1) setTimeout(() => banner('Last life'), 300);
        }
        announce(`Incorrect. The answer is ${KEYS[right]}. ${showText ? q.explanation || '' : ''}`);
      }
      setTimeout(() => $('nextBtn').focus({ preventScroll: true }), 60);
      setTimeout(() => $('explain').scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 150);
    }
  }

  function next() {
    if (screen !== 'quiz' || !S.answers[S.i]) return;
    clearTimeout(autoNext);
    Sound.tap();
    if (S.over || S.i >= S.ids.length - 1) return finish();
    S.i++;
    saveSession();
    renderQuestion();
  }

  // ---------- results ----------
  async function finish() {
    cancelAnimationFrame(qTick);
    const total = S.ids.length;
    const score = correctCount();
    const answered = S.answers.filter(Boolean).length;
    const passed = score >= needed(total);
    const results = S.ids.map((id, k) => S.answers[k] ? { id, correct: S.answers[k].correct, topic: (qById(id) || {}).topic } : null).filter(Boolean);
    const sess = S;
    clearInterval(clockTimer);
    if (sess.server && !sess.srvResult) { try { const info = await SFDQ_API.dailyInfo(); if (info.result) sess.srvResult = info.result; } catch (_) {} }
    S = null;
    const sr = sess.server ? sess.srvResult : null;
    const res = await bg({
      type: 'fq:quizFinished', mode: sess.mode, score, total, answered, results, bestStreak: sess.bestStreak, xp: sess.xp,
      livesOn: sess.livesOn, livesLeft: sess.livesOn ? livesFor(total) - results.filter(r => !r.correct).length : null,
      lifelines: sess.lifelines, speedy: sess.speedy, grid: gridOf(sess),
      ...(sr ? { day: sr.day, ranked: true, flagged: !!sr.flagged, timeMs: sr.timeMs, rank: sr.rank, players: sr.players, percentile: sr.percentile } : {})
    }) || {};
    const st = await bg({ type: 'fq:state' });
    if (st) { pub = st; if (st.stats) stats = st.stats; }
    renderResults(sess, { score, total, answered, passed: res.passed ?? passed, res });
  }

  function renderResults(sess, { score, total, answered, passed, res }) {
    show('results');
    const daily = sess.mode === 'daily', lock = sess.mode === 'lock';
    $('shareBtn').hidden = daily;
    $('nudge').hidden = true;
    $('phoneLine').hidden = !(daily && sess.server && LB && LB.code);   // quiet link to the QR dialog, ranked daily only
    $('resPanels').hidden = daily;
    $('resLede').hidden = false;
    const pct = Math.round(score / total * 100);
    const ok = lock ? passed : daily ? true : pct >= 70;

    // ring
    const C = 2 * Math.PI * 52;
    const fg = $('ringFg');
    fg.style.strokeDasharray = C; fg.style.strokeDashoffset = C;
    fg.classList.toggle('fail', !ok);
    requestAnimationFrame(() => requestAnimationFrame(() => { fg.style.strokeDashoffset = C * (1 - score / total); }));
    const t0 = performance.now();
    (function count(t) {
      const p = Math.min(1, (t - t0) / 1500), e = 1 - Math.pow(1 - p, 3);
      $('scorePct').textContent = Math.round(pct * e) + '%';
      $('scoreRaw').textContent = `${Math.round(score * e)} / ${total}`;
      if (p < 1) requestAnimationFrame(count);
    })(t0);

    const lvl = FQ_levelOf(stats.xp || 0);
    const siteName = SITE ? SITE.name : 'your feed';
    $('resPrimary').disabled = false;
    if (lock && ok) {
      $('resEyebrow').textContent = 'Unlocked';
      $('resTitle').textContent = 'Passed.';
      $('resLede').innerHTML = `<b>${score}/${total}</b>, that's ${pct}%. Your next <b>${settings.rewardMinutes} minutes</b> start the moment you head back.`;
      $('resPrimary').textContent = `Back to ${siteName}`;
      $('resPrimary').className = 'btn primary big success';
      $('resPrimary').onclick = release;
      $('resSecondary').hidden = true;
      setTimeout(() => { Sound.pass(); Confetti.cannons(); Confetti.rain(2800); }, 500);
    } else if (lock) {
      const outOfLives = answered < total;
      $('resEyebrow').textContent = outOfLives ? 'Round over' : 'Below the pass mark';
      $('resTitle').textContent = score >= needed(total) - 3 ? 'Almost there.' : 'Not this time.';
      $('resLede').innerHTML = outOfLives
        ? `You ran out of lives at question <b>${answered}</b> with <b>${score}</b> correct. You need <b>${needed(total)}</b>. Skim the misses below, then take a fresh set.`
        : `<b>${score}/${total}</b> (${pct}%). You needed <b>${needed(total)}</b>. The misses below are your cheat sheet for the next round.`;
      $('resPrimary').innerHTML = '<span id="retryLabel">Try a fresh set</span>';
      $('resPrimary').className = 'btn primary big';
      $('resPrimary').onclick = async () => { await newSession('lock'); startQuiz(); };
      $('resSecondary').hidden = true;
      applyCooldown($('resPrimary'), $('retryLabel'));
      setTimeout(() => Sound.fail(), 400);
    } else if (daily) {
      const r = sess.server ? sess.srvResult : null;
      const ds = FQ_dailyStats(stats.daily);
      const cur = r && r.streak ? r.streak.current : ds.current;
      $('resEyebrow').textContent = 'Daily challenge';
      $('resTitle').textContent = score === total ? `Perfect. ${score}/${total}.` : `${score}/${total} today.`;
      let lede = '';
      if (r && r.flagged) lede = 'That run was too quick to rank, so it stays off the leaderboard. Your score is still saved.';
      else if (r && r.percentile != null) lede = `You beat <b>${r.percentile}%</b> of players today.`;
      else if (!r) lede = 'Your score is saved.';
      $('resLede').innerHTML = lede; $('resLede').hidden = !lede;
      $('resPrimary').textContent = 'Leaderboard';
      $('resPrimary').className = 'btn primary big';
      $('resPrimary').onclick = () => openBoard();
      $('resSecondary').hidden = false;
      $('resSecondary').textContent = 'Practice';
      $('resSecondary').onclick = () => { location.search = '?mode=practice'; };
      $('resBadges').innerHTML = (r && Number.isFinite(r.timeMs) ? chip(`Time <b>${fmtTime(r.timeMs)}</b>`) : '') +
        (r && r.rank ? chip(`Rank <b>${r.rank}</b> of ${r.players}`) : '') + (cur > 0 ? chip(`Streak <b>${cur}</b>`) : '');
      if (score === total) setTimeout(() => { Sound.pass(); Confetti.cannons(); }, 400);
      showNudge();
    } else {
      $('resEyebrow').textContent = 'Practice. Not ranked.';
      $('resTitle').textContent = pct === 100 ? 'Perfect score.' : pct >= 70 ? 'Solid round.' : 'Keep going.';
      $('resLede').innerHTML = `<b>${score}/${total}</b> (${pct}%). Practice rounds never appear on the leaderboard.`;
      $('resPrimary').textContent = 'Another round';
      $('resPrimary').className = 'btn primary big';
      $('resPrimary').onclick = () => renderPractice();
      $('resSecondary').hidden = false;
      $('resSecondary').textContent = 'Close';
      $('resSecondary').onclick = () => window.close();
      if (pct >= 70) setTimeout(() => { Sound.pass(); Confetti.cannons(); }, 500);
    }
    if (!daily) $('resBadges').innerHTML = chip(`<b>+${sess.xp.toLocaleString()}</b> XP`) + chip(`Best combo <b>${sess.bestStreak}</b>`) +
      (sess.speedy ? chip(`<b>${sess.speedy}</b> fast answers`) : '') + chip(`<b>${lvl[1]}</b>`);

    // new achievements
    const fresh = daily ? [] : (res.achievements || []).map(id => FQ_ACHIEVEMENTS.find(a => a.id === id)).filter(Boolean);
    $('newTrophies').hidden = !fresh.length;
    $('newTrophies').innerHTML = fresh.map(a => `<div class="trophy"><div><span class="new">Achievement unlocked</span><b>${esc(a.name)}</b><small>${esc(a.desc)}</small></div></div>`).join('');
    if (fresh.length) setTimeout(() => { Sound.trophy(); Confetti.burst($('newTrophies'), 50); }, 1400);
    if (daily) { setTimeout(() => $('resPrimary').focus(), 400); return; }

    // topic bars
    const byTopic = {};
    sess.ids.forEach((id, k) => {
      const a = sess.answers[k]; if (!a) return;
      const t = qById(id).topic;
      byTopic[t] = byTopic[t] || { n: 0, ok: 0 };
      byTopic[t].n++; if (a.correct) byTopic[t].ok++;
    });
    const rows = Object.entries(byTopic).sort((a, b) => a[1].ok / a[1].n - b[1].ok / b[1].n);
    $('topicBars').innerHTML = rows.map(([t, v]) => `
      <div class="bar-row"><div class="bar-head"><span>${esc(t)}</span><b>${v.ok}/${v.n}</b></div>
      <div class="bar"><i style="--c:${colorOf(t)}" data-w="${Math.round(v.ok / v.n * 100)}"></i></div></div>`).join('') || '<div class="empty">No answers yet.</div>';
    setTimeout(() => document.querySelectorAll('.bar i').forEach(i => i.style.width = i.dataset.w + '%'), 200);

    // misses
    const misses = sess.ids.map((id, k) => ({ q: qById(id), a: sess.answers[k], perm: sess.perms[k] })).filter(x => x.a && !x.a.correct);
    $('missCount').textContent = misses.length || '';
    $('misses').innerHTML = misses.length ? misses.map(({ q, a, perm }) => `
      <details class="miss">
        <summary>${rich(q.q)}</summary>
        <div class="body">
          <p class="ans">Correct: ${rich(q.options[q.answer])}</p>
          <p class="yours">${a.picked < 0 ? 'Ran out of time' : `You picked: ${rich(q.options[perm[a.picked]])}`}</p>
          <p>${rich(q.explanation || '')}</p>
        </div>
      </details>`).join('') : '<div class="empty">Zero misses.</div>';

    $('shareBtn').onclick = () => share(sess, score, total, pct);
    const weak = [...new Set(misses.map(m => m.q.topic))].filter(t => BANK.some(b => b.topic === t));
    $('weakBtn').hidden = !weak.length || lock;
    $('weakBtn').textContent = weak.length === 1 ? `Practise ${weak[0]}` : `Practise ${weak.length} missed topics`;
    $('weakBtn').onclick = () => { location.href = 'quiz.html?mode=practice&topics=' + encodeURIComponent(weak.join('|')); };
    setTimeout(() => $('resPrimary').focus(), 400);
  }

  // Recovery-code nudge: result screen only, gone for good once copied or dismissed.
  async function showNudge() {
    if (!LB || !LB.code) return;
    let done = false;
    try { done = !!(await store.get(NUDGE_KEY))[NUDGE_KEY]; } catch (_) {}
    if (done || screen !== 'results') return;
    const close = async () => { $('nudge').hidden = true; await store.set({ [NUDGE_KEY]: true }); };
    $('nudgeCopy').onclick = async () => { if (await copyText(LB.code)) close(); };
    $('nudgeLater').onclick = close;
    $('nudge').hidden = false;
  }

  // ---------- report a problem (ranked daily only) ----------
  const REPORT_OK = 'Thanks. We will take a look.';
  function paintReport() {
    const on = !!(S && S.server && S.answers[S.i]);
    $('report').hidden = !on;
    $('reportForm').hidden = true;
    $('reportLink').setAttribute('aria-expanded', 'false');
    const sent = on && S.reported && S.reported[S.i];
    $('reportLink').hidden = !!sent;
    $('reportMsg').hidden = !sent; $('reportMsg').textContent = sent ? REPORT_OK : '';
    $('reportMsg').classList.remove('bad');
  }
  function wireReport() {
    $('reportLink').addEventListener('click', () => {
      const open = $('reportForm').hidden;
      $('reportForm').hidden = !open; $('reportLink').setAttribute('aria-expanded', String(open));
      $('reportMsg').hidden = true;
      if (open) { const f = $('reportForm').querySelector('input[type=radio]'); if (f) f.focus(); }
    });
    $('reportCancel').addEventListener('click', () => { $('reportForm').hidden = true; $('reportLink').setAttribute('aria-expanded', 'false'); $('reportLink').focus(); });
    $('reportForm').addEventListener('submit', async e => {
      e.preventDefault();
      const msg = $('reportMsg'), pick = $('reportForm').querySelector('input[name=reportReason]:checked');
      const say = (t, bad) => { msg.textContent = t; msg.hidden = false; msg.classList.toggle('bad', !!bad); };
      if (!pick) return say('Choose what is wrong first.', true);
      if (!S || !S.server) return;
      const day = S.day, i = S.i, btn = $('reportSend');
      btn.disabled = true; btn.textContent = 'Sending…';
      try {
        await SFDQ_API.report(day, i, pick.value, $('reportNote').value.trim() || undefined);
        S.reported = { ...(S.reported || {}), [i]: true };
        $('reportForm').hidden = true; $('reportLink').hidden = true; $('reportLink').setAttribute('aria-expanded', 'false');
        $('reportNote').value = ''; pick.checked = false;
        say(REPORT_OK);
      } catch (err) {
        say(err.network ? 'Could not send that. Check your connection and try again.' : (err.message || 'Could not send that. Try again in a moment.'), true);
      }
      btn.disabled = false; btn.textContent = 'Send';
    });
  }

  const gridOf = sess => sess.ids.map((_, k) => sess.answers[k] ? (sess.answers[k].correct ? '■' : '□') : '·').join('');
  async function share(sess, score, total, pct) {
    const grid = gridOf(sess);
    const rows = grid.match(/.{1,15}/g) || [];
    const text = [`Salesforce Daily Quiz practice: ${score}/${total} (${pct}%)`, ...rows].join('\n');
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_) {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
      try { ok = document.execCommand('copy'); } catch (_) {} ta.remove();
    }
    toast(ok ? 'Copied to clipboard' : 'Could not copy', ok ? 'Paste it anywhere' : '');
  }

  async function release() {
    Sound.tap();
    $('resPrimary').disabled = true;
    $('resPrimary').textContent = `Enjoy, see you in ${settings.rewardMinutes} minutes`;
    await bg({ type: 'fq:release' });
  }

  function startQuiz() {
    show('quiz');
    renderQuestion();
  }


  // ---------- emergency pass ----------
  function openSos() {
    $('sosText').innerHTML = `Unlock for <b>${settings.emergencyMinutes} minute${settings.emergencyMinutes === 1 ? '' : 's'}</b> without the quiz. You have <b>${pub.emergencyLeft}</b> left this week. The quiz will be waiting when it runs out.`;
    $('sosPhrase').textContent = SOS_PHRASE;
    $('sosInput').value = '';
    $('sosGo').disabled = true;
    $('sosModal').hidden = false;
    setTimeout(() => $('sosInput').focus(), 50);
  }
  const closeSos = () => { $('sosModal').hidden = true; $('startBtn').focus(); };
  $('emergencyBtn').addEventListener('click', openSos);
  $('sosCancel').addEventListener('click', closeSos);
  $('sosInput').addEventListener('input', e => { $('sosGo').disabled = e.target.value.trim().toLowerCase() !== SOS_PHRASE.toLowerCase(); });
  $('sosInput').addEventListener('keydown', e => { if (e.key === 'Enter' && !$('sosGo').disabled) $('sosGo').click(); });
  $('sosGo').addEventListener('click', async () => {
    $('sosGo').disabled = true;
    const r = await bg({ type: 'fq:emergency' });
    if (r && r.ok) { $('sosText').textContent = `Pass active for ${settings.emergencyMinutes} min. Use it well.`; setTimeout(closeSos, 1200); }
    else { $('sosText').textContent = (r && r.reason) || 'Could not use a pass.'; }
  });


  // ---------- input ----------
  document.addEventListener('keydown', e => {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (!$('sosModal').hidden) { if (e.key === 'Escape') closeSos(); return; }
    const tag = e.target && e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || (e.target.closest && e.target.closest('#report'))) return;
    const k = e.key.toLowerCase();
    if (screen === 'quiz') {
      const n = S.perms[S.i].length;
      let idx = 'abcdef'.indexOf(k);
      if (idx < 0 && /^[1-6]$/.test(k)) idx = +k - 1;
      if (idx >= 0 && idx < n && !S.answers[S.i]) { e.preventDefault(); answer(idx); return; }
      if ((k === 'enter' || k === ' ' || k === 'arrowright') && S.answers[S.i]) { e.preventDefault(); next(); return; }
      if (k === 'f') { useFifty(); return; }
      if (k === 'w') { useSkip(); return; }
      if (k === 'b') { toggleStar(); return; }
      if (k === 'm') { toggleSound(); return; }
    } else if (screen === 'intro' && k === 'enter' && document.activeElement === document.body) {
      $('startBtn').click();
    }
  });

  $('options').addEventListener('click', e => {
    const b = e.target.closest('.opt'); if (b) answer(+b.dataset.k);
  });
  $('nextBtn').addEventListener('click', next);
  $('fiftyBtn').addEventListener('click', useFifty);
  $('skipBtn').addEventListener('click', useSkip);
  $('starBtn').addEventListener('click', toggleStar);
  $('soundBtn').addEventListener('click', toggleSound);
  $('pEdit').addEventListener('click', e => { e.preventDefault(); openEditRules(); });
  $('pStart').addEventListener('click', () => { if (!$('pStart').disabled) { Sound.tap(); startPractice(); } });

  async function toggleSound() {
    Sound.enabled = !Sound.enabled;
    $('soundBtn').textContent = Sound.enabled ? 'Sound' : 'Muted';
    const { prefs: p = {} } = await store.get('prefs');
    await store.set({ prefs: { ...p, sound: Sound.enabled } });
    Sound.tap();
  }

  // Focus unlock quiz: the only thing the intro Start button does.
  $('startBtn').addEventListener('click', async () => {
    if ($('startBtn').disabled || MODE !== 'lock') return;
    Sound.tap();
    if (!S) await newSession('lock');
    startQuiz();
  });
  $('restartBtn').addEventListener('click', async () => {
    if (MODE !== 'lock') return;
    Sound.tap();
    await newSession('lock');
    startQuiz();
  });

  // Another tab may have advanced the shared lock-mode quiz; adopt the newer copy.
  document.addEventListener('visibilitychange', async () => {
    if (document.visibilityState !== 'visible' || MODE !== 'lock') return;
    const { activeQuiz } = await store.get('activeQuiz');
    if (activeQuiz && S && activeQuiz.updatedAt > S.updatedAt) {
      S = activeQuiz;
      if (screen === 'quiz') renderQuestion();
    }
  });


  // ---------- navigation ----------
  $('topbar').hidden = MODE === 'lock';
  document.querySelectorAll('.tb-links a').forEach(a => { const on = a.dataset.m === MODE; a.classList.toggle('on', on); if (on) a.setAttribute('aria-current', 'page'); });

  // ---------- boot ----------
  (async function boot() {
    $('homeLink').href = FQ_HOME;
    const [st, local] = await Promise.all([bg({ type: 'fq:state' }), store.get(['prefs', 'activeQuiz', 'starred'])]);
    if (st) { pub = st; settings = { ...settings, ...st.settings }; stats = st.stats || {}; }
    const applyPrefs = p => {
      prefs = { ...FQ_PREFS, ...(p || {}) };
      Sound.enabled = prefs.sound !== false && settings.sound !== false;
      Sound.config(prefs); Confetti.config(prefs);
      if ($('soundBtn')) $('soundBtn').textContent = Sound.enabled ? 'Sound' : 'Muted';
    };
    applyPrefs(local.prefs);
    starred = new Set(local.starred || []);
    SITE = FQ_SITES.concat(settings.customSites || []).find(s => s.id === params.get('site')) || null;
    if (HAS_EXT) {
      chrome.storage.local.remove(['dailyQuiz', 'joinSkipDay']).catch(() => {});   // the local daily no longer exists
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area !== 'local') return;
        if (ch.prefs) applyPrefs(ch.prefs.newValue);
        if (ch.lb) {   // joined, restored or signed out in another tab
          LB = ch.lb.newValue || null;
          if (LB && LB.code && !LB.name) SFDQ_API.adopt();   // a code that came from the web app: fetch the profile
          if (screen === 'daily' && DAILY.state !== 'loading' && !pending) { DAILY.info = null; loadDaily(); }
        }
        if ((ch.prefs || ch.settings) && screen === 'practice') renderPractice();
        if (ch.stats) { stats = ch.stats.newValue || stats; }
      });
    }

    if (MODE !== 'lock') {
      try { LB = await SFDQ_API.identity(); } catch (_) { LB = null; }
      // A code that came from the web app has no profile yet: fetch it (bounded wait; offline keeps the code and retries next time).
      // Also swaps a long legacy recovery code for a short one, silently (old code kept on failure).
      if (LB && LB.code) { try { LB = (await Promise.race([SFDQ_API.adopt(), new Promise(r => setTimeout(() => r(LB), 2500))])) || LB; } catch (_) {} }
      wireJoin(); wireReport();
      $('phoneLink').addEventListener('click', e => SFDQ_PHONE.open(e.currentTarget));
    }
    if (MODE === 'practice') FQ_theme.mountModeSwitch($('pTheme'));
    await loadBank();
    if (!BANK.length) {
      document.querySelector('.app').innerHTML = '<p style="padding:40px">Could not load any questions. Run <code>node build.js</code> or import a bank in Settings.</p>';
      return;
    }

    if (MODE === 'lock') {
      if (st && (!st.locked || st.emergencyUntil)) {
        // Opened after the lock cleared (e.g. passed in another tab): offer the way out.
        S = null;
        renderIntro(false);
        $('introEyebrow').textContent = 'All clear';
        $('introTitle').textContent = "You're free.";
        $('introLede').innerHTML = st.emergencyUntil ? 'An emergency pass is active. The quiz returns when it runs out.' : 'This round was already passed. Go enjoy it.';
        $('introChips').innerHTML = '';
        $('emergencyBtn').hidden = true;
        $('startLabel').textContent = 'Continue';
        $('startBtn').onclick = e => { e.stopImmediatePropagation(); bg({ type: 'fq:release' }); };
        return;
      }
      const aq = local.activeQuiz;
      const valid = aq && aq.mode === 'lock' && !aq.over && aq.ids.every(qById) && aq.answers.length < aq.ids.length;
      S = valid ? aq : null;
      renderIntro(!!S);
    } else if (MODE === 'daily') {
      show('daily');
      loadDaily();
    } else if (MODE === 'welcome') {
      renderWelcome();
    } else {
      renderPractice();
    }
  })();
})();
