// Salesforce Daily Quiz popup: one Daily card, Practice, Leaderboard, and the Focus timer card only when it is on.
(() => {
  const $ = id => document.getElementById(id);
  const C = 2 * Math.PI * 50;
  const go = path => { chrome.tabs.create({ url: chrome.runtime.getURL(path) }); window.close(); };
  const openDaily = () => go('src/quiz.html?mode=daily');
  const openPractice = () => { chrome.runtime.sendMessage({ type: 'fq:openPractice' }); window.close(); };
  const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtTime = ms => { const t = Math.max(0, Math.round(ms / 1000)); return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`; };
  const fmt = ms => {
    const s = Math.max(0, Math.round(ms / 1000));
    return s > 3600 ? `${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}` : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  };
  const until = () => {
    const m = Math.max(1, Math.ceil((FQ_nextUtcMidnight() - Date.now()) / 60000));
    return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`;
  };

  // ---------- Daily card ----------
  let model = { joined: false, played: null, streak: 0, offline: false }, dayShown = FQ_utcDay(), liveSeq = 0;

  function paintDaily() {
    const m = model, r = m.played;
    let h;
    if (r) {
      const rank = r.flagged ? 'Too quick to rank.' : (r.rank && r.players ? `Rank ${r.rank} of ${r.players}` : '');
      h = `<span class="k">Today's challenge</span>
        <div class="d-title">Today: ${r.score}/${r.total}${Number.isFinite(r.timeMs) ? ` in ${fmtTime(r.timeMs)}` : ''}</div>
        ${rank ? `<div class="d-line strong">${rank}</div>` : ''}
        ${!r.flagged && r.percentile ? `<div class="d-line">You beat ${r.percentile}%</div>` : ''}
        <div class="d-line" id="nextIn">Next challenge in ${until()}</div>
        <div class="d-actions"><button class="btn" type="button" data-act="board">Leaderboard</button></div>`;
    } else if (m.offline) {
      h = `<span class="k">Today's challenge</span>
        <div class="d-title">Daily needs a connection.</div>
        <div class="d-line">Practice works offline.</div>
        <div class="d-actions"><button class="btn" type="button" data-act="retry">Retry</button><button class="btn ghost" type="button" data-act="practice">Practice</button></div>`;
    } else {
      h = `<span class="k">Today's challenge</span>
        <div class="d-title">5 questions. Same for everyone. Ranked.</div>
        ${m.joined && m.streak ? `<div class="d-line strong">Day ${m.streak} streak</div>` : ''}
        <div class="d-line" id="nextIn">Next challenge in ${until()}</div>
        <div class="d-actions"><button class="btn" type="button" data-act="play">Play</button></div>`;
    }
    $('dailyCard').innerHTML = h;
  }
  $('dailyCard').addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    ({ play: openDaily, practice: openPractice, board: () => setView('board'), retry: () => { b.disabled = true; b.textContent = 'Retrying'; live(); } })[b.dataset.act]();
  });

  // Local data first (instant), then the live state when joined. Falls back to local data silently.
  async function loadDaily() {
    const { stats = {} } = await chrome.storage.local.get('stats');
    let lb = await SFDQ_API.identity();
    // A code that came from the web app has no profile yet: fetch it (bounded wait; offline keeps the code).
    // adopt() also swaps a long legacy recovery code for a short one, silently.
    if (lb && lb.code) { try { lb = (await Promise.race([SFDQ_API.adopt(), new Promise(r => setTimeout(() => r(lb), 2500))])) || lb; } catch (_) {} }
    const joined = !!(lb && lb.code);
    model = { joined, played: (stats.daily || {})[FQ_utcDay()] || null, streak: joined ? FQ_dailyStreak(stats.daily) : 0, offline: false };
    dayShown = FQ_utcDay();
    paintDaily();
    if (joined) live();
  }
  async function live() {
    const seq = ++liveSeq;
    let res = null, netFail = false;
    try {
      res = await Promise.race([SFDQ_API.me(), new Promise((_, rej) => setTimeout(() => rej({ network: true }), 3500))]);
    } catch (e) { netFail = !!(e && e.network); }
    if (seq !== liveSeq) return;
    model.offline = false;
    if (res && res.today) {
      const t = res.today;
      if (res.streak) model.streak = res.streak.current;
      if (t.status === 'done' && t.result) model.played = t.result;
      else model.played = null;
    } else if (netFail && !model.played) model.offline = true;
    paintDaily();
  }

  // ---------- Focus timer card (only when switched on) ----------
  async function refreshFocus() {
    const state = await chrome.runtime.sendMessage({ type: 'fq:state' });
    if (!state) return;
    const { remainingMs, limitMs, locked, settings, emergencyUntil, inSchedule } = state;
    const on = !!(settings && settings.blockerOn);
    $('focusCard').hidden = !on;
    if (!on) return;
    const now = Date.now(), ring = $('ring');
    ring.style.strokeDasharray = C;
    ring.classList.remove('low', 'out', 'sos', 'off');
    if (!inSchedule) {
      ring.style.strokeDashoffset = 0; ring.classList.add('off');
      $('remain').textContent = 'Off'; $('remainSub').textContent = 'outside schedule';
      $('status').textContent = 'Resting. Nothing counts until your focus hours start.';
    } else if (emergencyUntil) {
      ring.style.strokeDashoffset = 0; ring.classList.add('sos');
      $('remain').textContent = fmt(emergencyUntil - now); $('remainSub').textContent = 'emergency pass';
      $('status').textContent = 'The quiz is back when the pass runs out.';
    } else if (locked) {
      ring.style.strokeDashoffset = C; ring.classList.add('out');
      $('remain').textContent = 'Quiz'; $('remainSub').textContent = 'due';
      $('status').textContent = 'Social time is used up. Open a tracked site to take the quiz.';
    } else {
      ring.style.strokeDashoffset = C * (1 - remainingMs / limitMs);
      if (remainingMs < 5 * 60000) ring.classList.add('low');
      $('remain').textContent = fmt(remainingMs);
      $('remainSub').textContent = `of ${Math.round(limitMs / 60000)}m`;
      $('status').textContent = remainingMs < 5 * 60000 ? 'Nearly out. A quiz is coming up.' : 'Counts down only while a tracked site is open.';
    }
  }

  $('settingsBtn').addEventListener('click', () => { chrome.runtime.openOptionsPage(); window.close(); });
  $('practice').addEventListener('click', openPractice);
  $('boardBtn').addEventListener('click', () => setView('board'));
  $('homeLink').href = FQ_HOME;
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;

  // Compact reminder, shown when the popup was opened by the once-a-day prompt.
  async function maybePrompt() {
    const { promptAt = 0, stats = {} } = await chrome.storage.local.get(['promptAt', 'stats']);
    if (!promptAt || Date.now() - promptAt > 30000 || (stats.daily || {})[FQ_utcDay()]) return false;
    await chrome.storage.local.set({ promptAt: 0 });
    const cur = FQ_dailyStreak(stats.daily);
    document.body.classList.add('compact');
    $('prompt').hidden = false; $('full').hidden = true;
    $('promptDate').textContent = new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' });
    $('promptTitle').textContent = cur ? `Keep your ${cur}-day streak going` : "Today's challenge is ready";
    return true;
  }
  $('promptPlay').addEventListener('click', openDaily);
  $('promptLater').addEventListener('click', () => window.close());

  // ---------- leaderboard view ----------
  let boardSeq = 0;

  function setView(v) {
    $('full').hidden = v !== 'today';
    $('boardView').hidden = v !== 'board';
    if (v === 'board') loadBoard();
  }
  const state = (title, text, btn) => {
    $('lbList').innerHTML = ''; $('lbState').hidden = false; $('lbCols').hidden = true;
    $('lbState').innerHTML = `<b>${esc(title)}</b>${esc(text)}${btn ? `<br><button class="btn" id="lbStateBtn" type="button">${esc(btn[0])}</button>` : ''}`;
    if (btn) $('lbStateBtn').onclick = btn[1];
  };
  const rowHTML = (r, me) => `<li class="${me ? 'me' : ''}"><span class="rk">${r.rank}</span><span class="nm" title="${esc(r.name)}">${/^https:\/\/(www\.)?linkedin\.com\/in\//.test(r.linkedin || '') ? `<a href="${esc(r.linkedin)}" target="_blank" rel="noopener">${esc(r.name)}</a>` : esc(r.name)}</span><span class="sc">${r.score}/${r.total}</span><span class="tm">${fmtTime(r.timeMs)}</span></li>`;

  async function loadBoard() {
    const seq = ++boardSeq;
    $('lbDay').textContent = 'Today · ' + new Date().toLocaleDateString([], { month: 'short', day: 'numeric', timeZone: 'UTC' }) + ' UTC';
    $('lbFoot').innerHTML = '';
    state('Loading', 'Fetching today\'s board.');
    const lb = await SFDQ_API.identity();
    let data;
    try { data = await SFDQ_API.board({ limit: 10 }); }
    catch (e) {
      if (seq !== boardSeq) return;
      $('lbCount').textContent = 'Top players';
      state('Offline', e.network ? 'Could not reach the leaderboard. Practice still works offline.' : e.message, ['Try again', loadBoard]);
      return;
    }
    if (seq !== boardSeq) return;
    const me = data.me, rows = data.rows || [];
    $('lbCount').textContent = data.players ? `${data.players} player${data.players === 1 ? '' : 's'} today` : 'No players yet';
    if (!rows.length) {
      state('Nobody has played yet today', lb ? 'Be the first on the board.' : 'Join and be the first on the board.', lb ? ['Play today\'s challenge', openDaily] : null);
    } else {
      $('lbState').hidden = true; $('lbCols').hidden = false;
      const inTop = me && rows.some(r => r.pid === me.pid);
      $('lbList').innerHTML = rows.map(r => rowHTML(r, me && r.pid === me.pid)).join('')
        + (me && !inTop && me.rank ? `<li class="gap" aria-hidden="true">...</li>` + rowHTML({ rank: me.rank, name: (lb && lb.name) || 'You', linkedin: '', score: me.score, total: me.total, timeMs: me.timeMs }, true) : '');
    }
    if (!lb) $('lbFoot').innerHTML = '<span>Join to put your name on the board.</span><button class="btn" id="lbJoin" type="button">Join</button>';
    else if (me && me.flagged) $('lbFoot').innerHTML = '<span>Your run today was too quick to rank.</span>';
    else if (!me) $('lbFoot').innerHTML = `<span>${lb.name ? `Playing as <b>${esc(lb.name)}</b>. ` : ''}You have not played today.</span>`;
    else $('lbFoot').innerHTML = `<span>You are <b>#${me.rank}</b> of ${data.players}.${me.percentile ? ` You beat ${me.percentile}% of players.` : ''}</span>`;
    const j = $('lbJoin'); if (j) j.onclick = openDaily;
  }
  $('lbBack').addEventListener('click', () => setView('today'));
  $('lbRefresh').addEventListener('click', loadBoard);

  (async () => {
    if (await maybePrompt()) return;
    await loadDaily();
    await refreshFocus();
    if (location.hash === '#board') setView('board');
  })();
  setInterval(() => {
    if (document.body.classList.contains('compact')) return;
    if (FQ_utcDay() !== dayShown) loadDaily();
    else { const n = $('nextIn'); if (n) n.textContent = `Next challenge in ${until()}`; }
    refreshFocus();
  }, 1000);
})();
