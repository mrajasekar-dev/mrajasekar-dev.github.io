// FocusQuest themes. Each theme is a set of design tokens applied as CSS custom properties.
// `tint` is the RGB used for translucent surfaces (white on dark themes, ink on light ones).
(function (g) {
  const T = (id, name, emoji, dark, c) => ({ id, name, emoji, dark, ...c });
  const THEMES = [
    T('graphite', 'Graphite', '', true, { bg: '#0e0f11', bg2: '#16181b', text: '#ececee', text2: '#a8abb2', text3: '#80838b', accent: '#4c8dff', accent2: '#7eadff', good: '#3ecf8e', bad: '#f0616d', warn: '#f5b544', info: '#58a6ff', aurora: ['#0e0f11', '#0e0f11', '#0e0f11'], grad: ['#4c8dff', '#4c8dff', '#4c8dff'], code: '#0a0b0d' }),
    T('midnight', 'Midnight', '', true, { bg: '#0b1020', bg2: '#121a2e', text: '#e8ecf6', text2: '#a3adc4', text3: '#7c859c', accent: '#5b8cff', accent2: '#8aabff', good: '#34c38f', bad: '#f06a6a', warn: '#f2b84b', info: '#56b6f7', aurora: ['#0b1020', '#0b1020', '#0b1020'], grad: ['#5b8cff', '#5b8cff', '#5b8cff'], code: '#070b16' }),
    T('slate', 'Slate', '', true, { bg: '#111418', bg2: '#191d23', text: '#e6e9ed', text2: '#a2aab4', text3: '#7f8793', accent: '#2bb3a3', accent2: '#6fd3c7', good: '#3ecf8e', bad: '#ef6461', warn: '#e9b44c', info: '#5aa9e6', aurora: ['#111418', '#111418', '#111418'], grad: ['#2bb3a3', '#2bb3a3', '#2bb3a3'], code: '#0b0e11' }),
    T('cloud', 'Cloud', '', false, { bg: '#f3f4f6', bg2: '#ffffff', text: '#181b20', text2: '#4b5260', text3: '#656c76', accent: '#0176d3', accent2: '#1b8ae6', good: '#1f8a5b', bad: '#d23b3b', warn: '#b7791f', info: '#0b72c5', aurora: ['#f3f4f6', '#f3f4f6', '#f3f4f6'], grad: ['#0176d3', '#0176d3', '#0176d3'], code: '#161a22', tint: '20,30,50' }),
    T('paper', 'Paper', '', false, { bg: '#fafaf9', bg2: '#ffffff', text: '#1c1917', text2: '#57534e', text3: '#75706a', accent: '#18181b', accent2: '#3f3f46', good: '#15803d', bad: '#c62828', warn: '#a16207', info: '#1d4ed8', aurora: ['#fafaf9', '#fafaf9', '#fafaf9'], grad: ['#18181b', '#18181b', '#18181b'], code: '#18181b', tint: '28,25,23' })
  ];
  const AUTO = { id: 'auto', name: 'System', emoji: '' };

  const FONTS = {
    rounded: { name: 'Rounded', stack: 'ui-rounded, "SF Pro Rounded", -apple-system, BlinkMacSystemFont, "Segoe UI Variable Display", "Segoe UI", Inter, Roboto, system-ui, sans-serif' },
    system: { name: 'Inter / System', stack: 'Inter, "SF Pro Text", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif' },
    serif: { name: 'Serif', stack: 'ui-serif, "New York", "Iowan Old Style", Georgia, Cambria, "Times New Roman", serif' },
    mono: { name: 'Mono', stack: 'ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace' },
    readable: { name: 'Readable', stack: 'Verdana, "Atkinson Hyperlegible", Tahoma, "Trebuchet MS", sans-serif' }
  };
  const RADII = { sharp: .3, round: 1, pill: 1.5 };
  // Radius for buttons, switches, chips, inputs and other small controls (--rc). Soft is capped at 14px (not a capsule) so it sits
  // beside cards, which scale with --rk (12px * 1.5 = 18px). Segmented switches use --rc outside and --rc minus their padding inside.
  const CONTROL_RADII = { sharp: '3px', round: '10px', pill: '14px' };

  const byId = id => THEMES.find(t => t.id === id) || THEMES[0];
  function resolve(prefs) {
    const p = prefs || {};
    let id = p.theme || 'graphite';
    if (id === 'auto') id = (g.matchMedia && g.matchMedia('(prefers-color-scheme: light)').matches) ? 'cloud' : 'graphite';
    return byId(id);
  }

  // Three-way colour mode: System / Light / Dark. The stored value stays a theme id ('auto' follows the device).
  const MODES = [['auto', 'System'], ['light', 'Light'], ['dark', 'Dark']];
  const modeOf = prefs => { const id = (prefs || {}).theme || 'graphite'; return id === 'auto' ? 'auto' : (byId(id).dark ? 'dark' : 'light'); };
  // Keeps the current theme when it already matches the mode, so picking Dark while on Midnight stays on Midnight.
  const themeFor = (mode, prefs) => {
    if (mode === 'auto') return 'auto';
    const cur = (prefs || {}).theme;
    if (cur && cur !== 'auto' && modeOf(prefs) === mode) return cur;
    return mode === 'light' ? 'cloud' : 'graphite';
  };
  // Quiet three-button control for the quiz pages. Writes prefs.theme; theme-boot repaints every open page.
  function mountModeSwitch(el) {
    if (!el) return;
    el.setAttribute('role', 'radiogroup'); el.setAttribute('aria-label', 'Theme');
    el.innerHTML = MODES.map(([v, l]) => `<button type="button" role="radio" data-mode="${v}" aria-checked="false">${l}</button>`).join('');
    const paint = prefs => el.querySelectorAll('button').forEach(b => b.setAttribute('aria-checked', String(b.dataset.mode === modeOf(prefs))));
    const hasExt = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
    const read = async () => hasExt ? ((await chrome.storage.local.get('prefs')).prefs || {}) : {};
    read().then(paint);
    if (hasExt) chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.prefs) paint(ch.prefs.newValue || {}); });
    el.addEventListener('click', async e => {
      const b = e.target.closest('button[data-mode]'); if (!b || !hasExt) return;
      const prefs = await read();
      const next = { ...prefs, theme: themeFor(b.dataset.mode, prefs) };
      paint(next);
      await chrome.storage.local.set({ prefs: next });
    });
  }

  // Tokens for one theme (+ optional custom accent).
  function tokens(theme, accent) {
    const t = theme;
    const a = accent || t.accent;
    const mixWith = t.dark ? '#ffffff' : '#000000';
    return {
      '--bg': t.bg, '--bg-2': t.bg2, '--text': t.text, '--text-2': t.text2, '--text-3': t.text3,
      '--accent': a, '--accent-2': accent ? `color-mix(in srgb, ${a} 62%, ${mixWith})` : t.accent2,
      '--good': t.good, '--bad': t.bad, '--warn': t.warn, '--info': t.info,
      '--a1': accent ? a : t.aurora[0], '--a2': t.aurora[1], '--a3': t.aurora[2],
      '--g1': accent ? `color-mix(in srgb, ${a} 70%, #ffffff)` : t.grad[0], '--g2': accent ? a : t.grad[1], '--g3': accent ? `color-mix(in srgb, ${a} 55%, ${t.bad})` : t.grad[2],
      '--code-bg': t.code, '--tint': t.tint || '255,255,255', '--on-accent': accent ? '#ffffff' : (t.onAccent || '#ffffff')
    };
  }

  function apply(prefs, root) {
    const el = root || g.document.documentElement;
    const p = { ...(g.FQ_PREFS || {}), ...(prefs || {}) };
    const theme = resolve(p);
    const tk = tokens(theme, p.accent);
    for (const k in tk) el.style.setProperty(k, tk[k]);
    const fontId = p.font === 'theme' || !p.font ? (theme.font || 'system') : p.font;
    el.style.setProperty('--font', (FONTS[fontId] || FONTS.rounded).stack);
    el.style.setProperty('--rk', RADII[p.radius] ?? 1);
    el.style.setProperty('--rc', CONTROL_RADII[p.radius] || CONTROL_RADII.round);
    el.style.setProperty('--zoom', String((Number(p.scale) || 100) / 100));
    el.style.colorScheme = theme.dark ? 'dark' : 'light';
    el.dataset.mode = theme.dark ? 'dark' : 'light';
    el.dataset.theme = theme.id;
    el.dataset.motion = p.motion || 'calm';
    el.dataset.bg = ['plain', 'grid'].includes(p.background) ? p.background : 'plain';
    return theme;
  }

  // Apply stored prefs now and whenever they change (in any page).
  function boot(onChange) {
    const run = prefs => { const t = apply(prefs); if (onChange) onChange(prefs, t); };
    const hasExt = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
    if (hasExt) {
      chrome.storage.local.get('prefs').then(({ prefs }) => run(prefs || {}));
      chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.prefs) run(ch.prefs.newValue || {}); });
    } else {
      let prefs = {};
      try { prefs = (JSON.parse(localStorage.fq || '{}').prefs) || {}; } catch (_) {}
      run(prefs);
    }
    if (g.matchMedia) g.matchMedia('(prefers-color-scheme: light)').addEventListener('change', async () => {
      const { prefs } = hasExt ? await chrome.storage.local.get('prefs') : { prefs: {} };
      if ((prefs || {}).theme === 'auto') run(prefs);
    });
  }

  Object.assign(g, { FQ_THEMES: THEMES, FQ_THEME_AUTO: AUTO, FQ_FONTS: FONTS, FQ_theme: { apply, boot, resolve, tokens, byId, MODES, modeOf, themeFor, mountModeSwitch } });
})(typeof globalThis !== 'undefined' ? globalThis : self);
