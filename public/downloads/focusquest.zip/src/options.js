// FocusQuest options: every rule, look and question bank in one place. Changes save instantly.
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rich = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>');
  const send = msg => chrome.runtime.sendMessage(msg).catch(() => null);
  const KEYS = 'ABCDEF';
  const mins = ms => { const m = Math.round(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };
  const colorOf = t => { let h = 0; for (const ch of String(t)) h = (h * 31 + ch.charCodeAt(0)) % 360; return `hsl(${h} 75% 62%)`; };

  let pub = {}, settings = { ...FQ_DEFAULTS }, prefs = { ...FQ_PREFS }, stats = {}, qstats = {}, starred = new Set();
  let builtin = [], custom = [];
  let frozen = false;
  let libQuery = '', libTopic = '', libLimit = 40;

  const SECTIONS = [
    { id: 'look', e: '🎨', t: 'Look & feel', s: 'Themes, colours, type and sound. These work any time, even while a quiz is due.' },
    { id: 'time', e: '⏱️', t: 'Time rules', s: 'How much scrolling you get and what happens when it runs out.' },
    { id: 'sites', e: '🌐', t: 'Sites', s: 'Which sites share the timer, plus places that never count.' },
    { id: 'schedule', e: '🗓️', t: 'Schedule', s: 'Only enforce FocusQuest during the hours that matter.' },
    { id: 'quiz', e: '🧩', t: 'Quiz rules', s: 'Length, pass mark, lives, lifelines, timers and difficulty.' },
    { id: 'bank', e: '📚', t: 'Question bank', s: 'Use the built-in Salesforce set, your own questions, or both.' },
    { id: 'you', e: '🙋', t: 'You', s: 'Your name, your reason, your daily goal.' },
    { id: 'progress', e: '📈', t: 'Progress', s: 'Where your time goes and how your brain is doing.' },
    { id: 'data', e: '💾', t: 'Backup & reset', s: 'Everything lives on this device. Export it, move it, or wipe it.' },
    { id: 'about', e: 'ℹ️', t: 'About', s: '' }
  ];

  // ---------- tiny component kit ----------
  const row = (label, sub, ctl, o = {}) => `<div class="row${o.rule ? ' rule' : ''}${o.stack ? ' stack' : ''}"${o.id ? ` id="${o.id}"` : ''}>
      <div class="lbl"><b>${label}</b>${sub ? `<small>${sub}</small>` : ''}</div><div class="ctl">${ctl}</div></div>`;
  const seg = (kind, key, items, cur) => `<div class="seg" role="radiogroup" data-kind="${kind}" data-key="${key}">${items.map(([v, l]) =>
      `<button type="button" role="radio" data-v="${esc(JSON.stringify(v))}" aria-checked="${JSON.stringify(v) === JSON.stringify(cur)}">${l}</button>`).join('')}</div>`;
  const toggle = (kind, key, on) => `<label class="switch"><input type="checkbox" role="switch" data-kind="${kind}" data-key="${key}" ${on ? 'checked' : ''}><i></i></label>`;
  const slider = (kind, key, min, max, step, v, unit = '') => `<div class="slider"><input type="range" data-kind="${kind}" data-key="${key}" data-unit="${unit}" min="${min}" max="${max}" step="${step}" value="${v}"><output>${v}${unit}</output></div>`;
  const multi = (key, items, cur) => `<div class="chips" data-key="${key}">${items.map(([v, l, c]) =>
      `<button type="button" class="chip" data-v="${esc(JSON.stringify(v))}" aria-pressed="${cur.map(String).includes(String(v))}"${c ? ` style="--c:${c}"` : ''}>${l}</button>`).join('')}</div>`;

  // ---------- saving ----------
  let savedTimer = 0;
  function flash(msg = 'Saved ✓', err = false) {
    const el = $('saved'); el.textContent = msg; el.classList.toggle('err', err); el.classList.add('show');
    clearTimeout(savedTimer); savedTimer = setTimeout(() => el.classList.remove('show'), err ? 3200 : 1300);
  }
  async function saveSettings(patch, rerender) {
    const res = await send({ type: 'fq:saveSettings', settings: patch });
    if (res && res.ok) {
      settings = res.settings; pub = { ...pub, ...res };
      flash(res.partial ? 'Saved the parts that are not frozen' : 'Saved ✓');
      paintDerived();
      (rerender || []).forEach(renderSection);
    } else {
      flash((res && res.reason) || 'Could not save', true);
      renderAll();
    }
  }
  async function savePrefs(patch) {
    prefs = { ...prefs, ...patch };
    await chrome.storage.local.set({ prefs });
    flash();
  }
  const saveBy = (kind, key, value, rerender) => kind === 'pref' ? savePrefs({ [key]: value }) : saveSettings({ [key]: value }, rerender);

  // ---------- sections ----------
  const R = {};

  R.look = () => {
    const cur = prefs.theme || 'aurora';
    const themes = [...FQ_THEMES, FQ_THEME_AUTO].map(t => {
      if (t.id === 'auto') return `<button class="theme" type="button" data-theme="auto" aria-pressed="${cur === 'auto'}">
        <div class="pv" style="background:linear-gradient(135deg,#0b0a1a 50%,#f6f3ec 50%);--pa:#7c5cff"><i class="l1" style="background:#fff"></i><i class="l2" style="background:#1f1b16"></i><span class="pill" style="background:linear-gradient(90deg,#7c5cff,#d9480f)"></span></div>
        <div class="nm">🌓 Auto <small>follows system</small></div></button>`;
      return `<button class="theme" type="button" data-theme="${t.id}" aria-pressed="${cur === t.id}">
        <div class="pv" style="background:${t.bg};--pa:${t.aurora[0]}"><i class="l1" style="background:${t.text}"></i><i class="l2" style="background:${t.text2}"></i>
          <span class="pill" style="background:linear-gradient(90deg,${t.grad.join(',')})"></span>
          <span class="dots"><b style="background:${t.good}"></b><b style="background:${t.bad}"></b><b style="background:${t.warn}"></b></span></div>
        <div class="nm">${t.emoji} ${t.name} <small>${t.dark ? 'dark' : 'light'}</small></div></button>`;
    }).join('');
    const ACC = ['#7c5cff', '#3b82f6', '#06b6d4', '#14b8a6', '#22c55e', '#eab308', '#f97316', '#ef4444', '#ec4899', '#a855f7'];
    const accents = `<div class="accents"><button class="chip" type="button" data-accent="" aria-pressed="${!prefs.accent}">Theme default</button>
      ${ACC.map(c => `<button class="dot" type="button" data-accent="${c}" style="background:${c}" aria-label="Accent ${c}" aria-pressed="${prefs.accent === c}"></button>`).join('')}
      <input type="color" id="accentPick" value="${prefs.accent || '#7c5cff'}" title="Pick any colour"></div>`;
    return `<div class="card pad"><div class="card-title" style="margin-top:0">Theme</div><div class="themes">${themes}</div>
        ${row('Accent colour', 'Recolour buttons, rings and highlights on top of any theme.', accents, { stack: true })}</div>
      <div class="card">
        ${row('Font', 'Theme picks one for you (Terminal goes mono).', seg('pref', 'font', [['theme', 'Theme'], ['rounded', 'Rounded'], ['system', 'System'], ['serif', 'Serif'], ['mono', 'Mono'], ['readable', 'Readable']], prefs.font || 'theme'))}
        ${row('Text size', 'Scales the quiz and this page.', slider('pref', 'scale', 85, 130, 5, prefs.scale || 100, '%'))}
        ${row('Corners', '', seg('pref', 'radius', [['sharp', '◻︎ Sharp'], ['round', '▢ Round'], ['pill', '⬭ Pill']], prefs.radius || 'round'))}
        ${row('Motion', 'Calm keeps the fun but drops the wobble. Off is fully still.', seg('pref', 'motion', [['full', 'Full'], ['calm', 'Calm'], ['off', 'Off']], prefs.motion || 'full'))}
        ${row('Background', '', seg('pref', 'background', [['aurora', '🌌 Aurora'], ['stars', '✨ Stars'], ['grid', '▦ Grid'], ['plain', '▢ Plain']], prefs.background || 'aurora'))}
        ${row('Confetti', 'Bursts on right answers, cannons when you pass.', toggle('pref', 'confetti', prefs.confetti !== false))}
      </div>
      <div class="card">
        ${row('Sound effects', '', toggle('pref', 'sound', prefs.sound !== false))}
        ${row('Sound pack', '', seg('pref', 'soundPack', [['arcade', '🕹️ Arcade'], ['soft', '🎐 Soft'], ['retro', '👾 8-bit']], prefs.soundPack || 'arcade') + '<button class="btn ghost" type="button" id="testSound">▶ Test</button>')}
        ${row('Volume', '', slider('pref', 'volume', 0, 100, 5, prefs.volume ?? 70, '%'))}
        ${row('Try it', 'Open a practice round to see your look in action.', '<button class="btn" type="button" data-open="practice">🧠 Preview in practice</button>')}
      </div>`;
  };

  R.time = () => `<div class="card">
      ${row('Social time before a quiz', 'The allowance you start each day (or each reset) with.', slider('set', 'limitMinutes', 5, 240, 5, settings.limitMinutes, ' min'), { rule: true })}
      ${row('Time earned per pass', 'How much you unlock each time you pass. Make it shorter to quiz more often.', slider('set', 'rewardMinutes', 5, 240, 5, settings.rewardMinutes, ' min'), { rule: true })}
      ${row('Fresh start every midnight', 'Refill the allowance at 00:00, even if a quiz is pending.', toggle('set', 'dailyReset', settings.dailyReset), { rule: true })}
    </div>
    <div class="card">
      ${row('Heads-up warnings', 'A small pop-up before the quiz lands.', multi('warnAt', [[15, '15 min'], [10, '10 min'], [5, '5 min'], [1, '1 min']], settings.warnAt), { rule: true })}
      ${row('Warning position', '', seg('set', 'toastPosition', [['tl', '↖ Top left'], ['tr', '↗ Top right'], ['bl', '↙ Bottom left'], ['br', '↘ Bottom right']], settings.toastPosition), { rule: true })}
    </div>
    <div class="card">
      ${row('Cooldown after a failed round', 'Stops rapid-fire guessing. Take a breath, read the misses.', seg('set', 'retryCooldown', [[0, 'None'], [1, '1 min'], [2, '2 min'], [5, '5 min'], [10, '10 min']], settings.retryCooldown), { rule: true })}
      ${row('Emergency passes per week', 'Skip the quiz for a few minutes when you really need to. You type a phrase to confirm.', seg('set', 'emergencyPerWeek', [[0, 'None'], [1, '1'], [2, '2'], [3, '3'], [5, '5'], [7, '7']], settings.emergencyPerWeek), { rule: true })}
      ${row('Emergency pass length', '', seg('set', 'emergencyMinutes', [[1, '1 min'], [3, '3 min'], [5, '5 min'], [10, '10 min'], [15, '15 min']], settings.emergencyMinutes), { rule: true })}
    </div>`;

  R.sites = () => {
    const builtins = FQ_SITES.map(s => `<label class="site"><input type="checkbox" data-site="${s.id}" ${settings.disabledSites.includes(s.id) ? '' : 'checked'}><span>${s.emoji} ${s.name}</span></label>`).join('');
    const customs = settings.customSites.map(c => `<div class="item"><span>${esc(c.emoji)} ${esc(c.name)}</span><small>${settings.disabledSites.includes(c.id) ? 'paused' : 'tracked'}</small><button class="x" type="button" data-rm-site="${esc(c.id)}" title="Remove">✕</button></div>`).join('');
    const allows = settings.allowList.map((p, i) => `<div class="item"><span>✅ ${esc(p)}</span><button class="x" type="button" data-rm-allow="${i}" title="Remove">✕</button></div>`).join('');
    return `<div class="card">
        <div class="row rule stack"><div class="lbl"><b>Built-in sites</b><small>All ticked sites share one timer.</small></div><div class="sites">${builtins}</div></div>
      </div>
      <div class="card">
        ${row('Add your own sites', 'Netflix, news, shopping, anything. Chrome will ask permission for just that site.',
          `<div class="addrow"><input class="text" id="siteInput" placeholder="e.g. netflix.com" autocomplete="off"><button class="btn" type="button" id="siteAdd">Add site</button></div>
           <div class="list">${customs || '<p class="note">No custom sites yet.</p>'}</div><p class="note" id="siteMsg"></p>`, { rule: true, stack: true })}
      </div>
      <div class="card">
        ${row('Always allowed', 'URLs that never count or lock, such as a learning channel. Use * as a wildcard.',
          `<div class="addrow"><input class="text" id="allowInput" placeholder="e.g. youtube.com/@salesforce or reddit.com/r/salesforce*" autocomplete="off"><button class="btn" type="button" id="allowAdd">Allow</button></div>
           <div class="list">${allows || '<p class="note">Nothing allowed yet. Everything on tracked sites counts.</p>'}</div>`, { rule: true, stack: true })}
      </div>`;
  };

  R.schedule = () => `<div class="card">
      ${row('Only enforce on a schedule', 'Outside these hours nothing counts and nothing locks.', toggle('set', 'scheduleOn', settings.scheduleOn), { rule: true })}
      ${row('Days', '', multi('scheduleDays', FQ_WEEKDAYS.map((d, i) => [i, d]), settings.scheduleDays), { rule: true })}
      ${row('Hours', 'Overnight windows work too, e.g. 21:00 to 02:00.', `<input type="time" class="text" data-time="scheduleFrom" value="${settings.scheduleFrom}"> <span>to</span> <input type="time" class="text" data-time="scheduleTo" value="${settings.scheduleTo}">`, { rule: true })}
      <div class="summary" id="schedNow"></div>
      ${row('Quick presets', '', `<div class="chips"><button class="chip" type="button" data-preset="work">💼 Work hours</button><button class="chip" type="button" data-preset="study">📖 Evenings</button><button class="chip" type="button" data-preset="school">🎒 School days</button><button class="chip" type="button" data-preset="always">♾️ Always</button></div>`, { rule: true })}
    </div>`;

  R.quiz = () => {
    const topics = [...new Set(bank().map(q => q.topic))].sort();
    const counts = {}; bank().forEach(q => counts[q.topic] = (counts[q.topic] || 0) + 1);
    const lt = settings.lockTopics || topics;
    return `<div class="card">
        ${row('Questions per quiz', '', slider('set', 'questionsPerQuiz', 3, 60, 1, settings.questionsPerQuiz, ''), { rule: true })}
        ${row('Pass mark', '', slider('set', 'passPercent', 40, 100, 5, settings.passPercent, '%'), { rule: true })}
        <div class="summary" id="quizSummary"></div>
        ${row('Lives', 'On: the round ends once passing is impossible. Off: you always answer every question.', toggle('set', 'livesOn', settings.livesOn), { rule: true })}
      </div>
      <div class="card">
        ${row('50:50 lifelines', 'Removes wrong answers. Halves the points for that question.', seg('set', 'fiftyCount', [0, 1, 2, 3, 5].map(n => [n, n === 0 ? 'None' : n]), settings.fiftyCount), { rule: true })}
        ${row('Swap lifelines', 'Trade the current question for a different one.', seg('set', 'skipCount', [0, 1, 2, 3, 5].map(n => [n, n === 0 ? 'None' : n]), settings.skipCount), { rule: true })}
        ${row('Timer per question', 'Run out and it counts as wrong. Fast answers earn a 25% speed bonus.', seg('set', 'questionTimer', [[0, 'Off'], [15, '15s'], [20, '20s'], [30, '30s'], [45, '45s'], [60, '60s'], [90, '90s']], settings.questionTimer), { rule: true })}
        ${row('Difficulty', 'Ramp starts easy and climbs. Hard skips the easy ones.', seg('set', 'difficulty', [['ramp', '📈 Ramp'], ['mixed', '🎲 Mixed'], ['easy', '🌱 Gentle'], ['hard', '🔥 Hard']], settings.difficulty), { rule: true })}
      </div>
      <div class="card">
        ${row('Explanations', 'When to show the “why” after each answer.', seg('set', 'explanations', [['always', 'Always'], ['wrong', 'Only when wrong'], ['never', 'Never']], settings.explanations), { rule: true })}
        ${row('Auto-advance on correct answers', 'Keeps the pace up. Wrong answers always wait for you.', toggle('set', 'autoAdvance', settings.autoAdvance), { rule: true })}
        ${row('Shuffle answer order', 'Turn off for banks with “All of the above” style options.', toggle('set', 'shuffleOptions', settings.shuffleOptions), { rule: true })}
      </div>
      <div class="card">
        <div class="row rule stack"><div class="lbl"><b>Topics in lock-screen quizzes</b><small>Practice rounds let you choose separately. <button class="chip" type="button" data-topics="all">All</button> <button class="chip" type="button" data-topics="none">None</button></small></div>
        ${multi('lockTopics', topics.map(t => [t, `${esc(t)}<small>${counts[t]}</small>`, colorOf(t)]), lt)}</div>
      </div>`;
  };

  R.bank = () => {
    const topics = [...new Set(bank().map(q => q.topic))].sort();
    return `<div class="card">
        ${row('Questions come from', `Built-in: ${builtin.length} Salesforce scenarios. Yours: ${custom.length}.`, seg('set', 'bankSource', [['builtin', '☁️ Built-in'], ['custom', '✍️ Mine'], ['both', '🔀 Both']], settings.bankSource), { rule: true })}
      </div>
      <div class="card pad">
        <div class="card-title" style="margin-top:0">Import your own questions</div>
        <div class="row rule stack" style="border:0;padding-top:6px">
          <div class="drop" id="drop" tabindex="0" role="button"><b>Drop a .json or .csv file</b> or click to choose<br><small>Study anything: AWS, languages, medicine, trivia.</small></div>
          <textarea class="text" id="pasteBox" placeholder='Or paste JSON / CSV here…&#10;[{"q":"2 + 2?","options":["3","4","5","22"],"answer":1,"explanation":"Basic maths.","topic":"Maths"}]'></textarea>
          <div class="ctl"><button class="btn" type="button" id="importAdd">Add to my bank</button><button class="btn ghost" type="button" id="importReplace">Replace my bank</button>
            <button class="btn ghost" type="button" id="tplJson">⬇ JSON template</button><button class="btn ghost" type="button" id="tplCsv">⬇ CSV template</button></div>
          <p class="note" id="importMsg">JSON: an array of { q, options[2–6], answer (0-based index or letter), explanation?, topic?, difficulty? (easy|medium|hard), code? }. CSV columns: question, a, b, c, d, answer (letter), explanation, topic, difficulty.</p>
        </div>
        <div class="ctl" style="justify-content:flex-start"><button class="btn ghost" type="button" id="exportMine" ${custom.length ? '' : 'disabled'}>⬇ Export my ${custom.length} questions</button>
          <button class="btn danger" type="button" id="clearMine" ${custom.length ? '' : 'disabled'}>Delete my questions</button></div>
      </div>
      <div class="card pad">
        <div class="card-title" style="margin-top:0">Library <small style="text-transform:none;letter-spacing:0">(☆ to bookmark for practice)</small></div>
        <div class="lib-tools"><input class="text" id="libSearch" placeholder="Search ${bank().length} questions…" value="${esc(libQuery)}" autocomplete="off">
          <select class="text" id="libTopic"><option value="">All topics</option>${topics.map(t => `<option ${t === libTopic ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>
        <div class="lib" id="lib"></div>
        <div class="ctl" style="justify-content:flex-start;margin-top:10px"><button class="btn" type="button" data-open="starred">⭐ Practice my ${starred.size} bookmarks</button><button class="btn ghost" type="button" data-open="mistakes">🩹 Practice my mistakes</button></div>
      </div>`;
  };

  R.you = () => `<div class="card">
      ${row('Your name', 'Used in greetings and warnings.', `<input class="text" data-text="displayName" maxlength="40" value="${esc(settings.displayName)}" placeholder="e.g. Raj" style="max-width:260px">`)}
      ${row('Your why', 'Shown on the lock screen. Future you will read this mid-scroll.', `<textarea class="text prose" data-text="why" maxlength="240" placeholder="e.g. Land a Salesforce architect role by March.">${esc(settings.why)}</textarea>`, { stack: true })}
      ${row('Daily question goal', 'Hit it every day to grow your day streak. 0 turns it off.', slider('set', 'dailyGoal', 0, 200, 5, settings.dailyGoal, ''))}
    </div>`;

  R.progress = () => {
    const acc = stats.answered ? Math.round(stats.correct / stats.answered * 100) + '%' : '—';
    const lvl = FQ_levelOf(stats.xp || 0);
    const week = (stats.emergencyLog || []).filter(t => Date.now() - t < 7 * 864e5).length;
    const tiles = [
      [`${lvl[2]}`, lvl[1]], [(stats.xp || 0).toLocaleString(), 'total XP'], [stats.quizzesPassed || 0, 'lock quizzes passed'], [stats.quizzesTaken || 0, 'rounds played'],
      [(stats.answered || 0).toLocaleString(), 'questions answered'], [acc, 'accuracy'], [stats.bestStreak || 0, 'best streak 🔥'],
      [FQ_dayStreak(stats.answeredByDay, settings.dailyGoal), 'day streak 📅'], [week, 'emergency passes this week']
    ].map(([b, s]) => `<div class="tile"><b>${b}</b><span>${s}</span></div>`).join('');

    const days = []; for (let i = 29; i >= 0; i--) days.push(Date.now() - i * 864e5);
    const chart = (by, fmt) => {
      const vals = days.map(t => (by || {})[FQ_dayKey(t)] || 0), max = Math.max(...vals, 1);
      return `<div class="chart">${vals.map((v, i) => `<div class="c${i === 29 ? ' t' : ''}" title="${new Date(days[i]).toDateString()}: ${fmt(v)}"><i style="height:${Math.max(2, v / max * 100)}%"></i></div>`).join('')}</div>
        <div class="chart-legend"><span>30 days ago</span><span>today</span></div>`;
    };
    const siteNames = Object.fromEntries(FQ_SITES.concat(settings.customSites).map(s => [s.id, `${s.emoji} ${s.name}`]));
    const perSite = Object.entries(stats.perSite || {}).sort((a, b) => b[1] - a[1]);
    const siteMax = perSite.length ? perSite[0][1] : 1;
    const topicAgg = {};
    for (const q of bank()) { const s = qstats[q.id]; if (!s) continue; const t = topicAgg[q.topic] = topicAgg[q.topic] || { seen: 0, ok: 0 }; t.seen += s.seen; t.ok += s.correct; }
    const topicRows = Object.entries(topicAgg).sort((a, b) => a[1].ok / a[1].seen - b[1].ok / b[1].seen);
    const got = stats.achievements || {};
    const trophies = FQ_ACHIEVEMENTS.map(a => `<div class="trophy${got[a.id] ? ' got' : ''}"><span class="te">${a.emoji}</span><div><b>${esc(a.name)}</b><small>${esc(a.desc)}${got[a.id] ? `<br>✓ ${new Date(got[a.id]).toLocaleDateString()}` : ''}</small></div></div>`).join('');
    const hist = (stats.history || []).slice(-15).reverse().map(h => `<tr><td>${new Date(h.at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</td><td>${h.mode === 'lock' ? '🔒 Lock' : '🧠 Practice'}</td><td>${h.score}/${h.total}</td><td class="${h.passed ? 'pass' : 'failc'}">${h.passed ? 'Pass' : 'Miss'}</td></tr>`).join('');
    return `<div class="tiles">${tiles}</div>
      <div class="card pad" style="margin-top:12px"><div class="card-title" style="margin-top:0">Social time, last 30 days</div>${chart(stats.byDay, mins)}</div>
      <div class="card pad"><div class="card-title" style="margin-top:0">Questions answered, last 30 days</div>${chart(stats.answeredByDay, v => v + ' questions')}</div>
      <div class="card pad"><div class="card-title" style="margin-top:0">Time by site</div><div class="bars">${perSite.map(([id, ms]) => `<div><div class="bar-head"><span>${esc(siteNames[id] || id)}</span><b>${mins(ms)}</b></div><div class="bar"><i style="width:${ms / siteMax * 100}%"></i></div></div>`).join('') || '<p class="note">No social time tracked yet.</p>'}</div></div>
      <div class="card pad"><div class="card-title" style="margin-top:0">Topic mastery (weakest first)</div><div class="bars">${topicRows.map(([t, v]) => `<div><div class="bar-head"><span>${esc(t)}</span><b>${Math.round(v.ok / v.seen * 100)}% · ${v.seen}</b></div><div class="bar"><i style="--c:${colorOf(t)};width:${v.ok / v.seen * 100}%"></i></div></div>`).join('') || '<p class="note">Answer a few questions to see this.</p>'}</div></div>
      <div class="card pad"><div class="card-title" style="margin-top:0">Achievements · ${Object.keys(got).length}/${FQ_ACHIEVEMENTS.length}</div><div class="trophies">${trophies}</div></div>
      <div class="card pad"><div class="card-title" style="margin-top:0">Recent rounds</div>${hist ? `<table class="hist"><tr><th>When</th><th>Type</th><th>Score</th><th>Result</th></tr>${hist}</table>` : '<p class="note">No rounds yet.</p>'}</div>`;
  };

  R.data = () => `<div class="card">
      ${row('Export a backup', 'Settings, look, progress, bookmarks and your questions, as one JSON file.', '<button class="btn" type="button" id="exportAll">⬇ Export backup</button>')}
      ${row('Restore a backup', 'Replaces what is in the file. The current timer is kept.', '<button class="btn ghost" type="button" id="importAll">⬆ Restore…</button>', { rule: true })}
      <p class="note" id="dataMsg"></p>
    </div>
    <div class="card">
      ${row('Reset progress', 'Clears XP, stats, achievements and bookmarks. Keeps settings and your questions.', '<button class="btn danger" type="button" id="resetProgress">Reset progress</button>', { rule: true })}
      ${row('Reset everything', 'Back to a fresh install. Your questions go too.', '<button class="btn danger" type="button" id="resetAll">Reset everything</button>', { rule: true })}
    </div>`;

  R.about = () => `<div class="card pad">
      <div class="about-hero"><img src="../icons/icon128.png" alt=""><div><h3>FocusQuest <small style="color:var(--text-3)">v${chrome.runtime.getManifest().version}</small></h3><p>Earn your scroll. Made by Rajasekar M.</p></div></div>
      <div class="ctl" style="justify-content:flex-start"><a class="btn" href="${FQ_HOME}" target="_blank" rel="noopener">🌐 Website</a><a class="btn ghost" href="${FQ_PRIVACY}" target="_blank" rel="noopener">🔐 Privacy policy</a><button class="btn ghost" type="button" data-open="welcome">👋 Welcome tour</button><button class="btn ghost" type="button" id="shortcuts">⌨️ Change shortcuts</button></div>
      <p class="note">Everything stays in this browser. No accounts, no servers, no tracking.</p>
      <div class="card-title">Keyboard</div>
      <div class="keys">
        <span><span class="kbd">Alt</span>+<span class="kbd">Shift</span>+<span class="kbd">F</span></span><span>Open the FocusQuest popup</span>
        <span><span class="kbd">Alt</span>+<span class="kbd">Shift</span>+<span class="kbd">P</span></span><span>Start a practice round</span>
        <span><span class="kbd">Alt</span>+<span class="kbd">Shift</span>+<span class="kbd">O</span></span><span>Open these options</span>
        <span><span class="kbd">A</span>–<span class="kbd">F</span> / <span class="kbd">1</span>–<span class="kbd">6</span></span><span>Answer</span>
        <span><span class="kbd">Enter</span></span><span>Next question</span>
        <span><span class="kbd">F</span> · <span class="kbd">W</span> · <span class="kbd">B</span> · <span class="kbd">M</span></span><span>50:50 · swap · bookmark · mute</span>
      </div>
    </div>`;

  // ---------- rendering ----------
  function renderSection(id) {
    const s = SECTIONS.find(x => x.id === id);
    const el = document.querySelector(`section[data-sec="${id}"] .body`);
    if (!el) return;
    el.innerHTML = R[id]();
    el.parentElement.classList.toggle('frozen', frozen);
    if (id === 'bank') renderLib();
    if (s) paintDerived();
  }
  function renderAll() {
    $('sections').innerHTML = SECTIONS.map(s => `<section class="sec" id="${s.id}" data-sec="${s.id}">
      <div class="sec-head"><h2>${s.e} ${s.t}</h2>${s.s ? `<p>${s.s}</p>` : ''}</div><div class="body"></div></section>`).join('');
    SECTIONS.forEach(s => renderSection(s.id));
    $('lockbar').hidden = !frozen;
    $('rank').textContent = FQ_levelOf(stats.xp || 0).slice(1).reverse().join(' ');
  }
  function paintDerived() {
    const qs = $('quizSummary');
    if (qs) {
      const n = settings.questionsPerQuiz, need = Math.ceil(n * settings.passPercent / 100);
      qs.innerHTML = `Score <b>${need} of ${n}</b> to pass. ${settings.livesOn ? `That's <b>${n - need + 1}</b> lives, so you can miss ${n - need}.` : 'No lives: every question gets answered.'}`;
    }
    const sn = $('schedNow');
    if (sn) sn.innerHTML = settings.scheduleOn
      ? (FQ_inSchedule(settings) ? '🟢 Right now: <b>enforcing</b>. Time on tracked sites counts.' : '😴 Right now: <b>resting</b>. Nothing counts until your hours start.')
      : '♾️ No schedule: FocusQuest is <b>always on</b>.';
  }

  function renderLib() {
    const box = $('lib'); if (!box) return;
    const q = libQuery.trim().toLowerCase();
    const list = bank().filter(x => (!libTopic || x.topic === libTopic) && (!q || (x.q + ' ' + x.options.join(' ') + ' ' + (x.explanation || '')).toLowerCase().includes(q)));
    box.innerHTML = list.slice(0, libLimit).map(x => {
      const s = qstats[x.id];
      return `<details class="lq"><summary><button class="st" type="button" data-star="${esc(x.id)}" aria-pressed="${starred.has(x.id)}" title="Bookmark">${starred.has(x.id) ? '★' : '☆'}</button><span class="t">${rich(x.q)}</span><span class="tag" style="--c:${colorOf(x.topic)}">${esc(x.topic)}</span></summary>
        <div class="body"><ol type="A">${x.options.map((o, i) => `<li class="${i === x.answer ? 'ok' : ''}">${rich(o)}</li>`).join('')}</ol>${x.explanation ? `<p>${rich(x.explanation)}</p>` : ''}
        <p class="note">${x.difficulty} · ${s ? `seen ${s.seen}×, right ${s.correct}×` : 'not seen yet'}</p></div></details>`;
    }).join('') + (list.length > libLimit ? `<button class="btn ghost" type="button" id="libMore">Show more (${list.length - libLimit} left)</button>` : '') || '<p class="note">No questions match.</p>';
  }

  // ---------- data ----------
  const bank = () => settings.bankSource === 'custom' && custom.length ? custom : settings.bankSource === 'both' ? builtin.concat(custom) : builtin;

  function normalize(q, i) {
    if (!q || typeof q !== 'object') return { err: 'not an object' };
    const text = q.q || q.question;
    let options = Array.isArray(q.options) ? q.options : ['a', 'b', 'c', 'd', 'e', 'f'].map(k => q[k] ?? q['option ' + k] ?? q['option' + k.toUpperCase()]).filter(v => v !== undefined && v !== '');
    options = options.map(String).filter(o => o.trim()).slice(0, 6);
    let ans = q.answer ?? q.correct;
    if (typeof ans === 'string' && /^[A-Fa-f]$/.test(ans.trim())) ans = KEYS.indexOf(ans.trim().toUpperCase());
    else if (typeof ans === 'string' && /^\d+$/.test(ans.trim())) ans = Number(ans) - (q.__csv ? 1 : 0);
    else if (typeof ans === 'string') ans = options.findIndex(o => o.trim().toLowerCase() === ans.trim().toLowerCase());
    ans = Number(ans);
    if (!text) return { err: 'missing question text' };
    if (options.length < 2) return { err: 'needs at least 2 options' };
    if (!(ans >= 0 && ans < options.length)) return { err: 'answer does not point at an option' };
    const diff = String(q.difficulty || 'medium').toLowerCase();
    return { q: {
      id: 'u-' + Date.now().toString(36) + '-' + i, topic: String(q.topic || 'My questions').slice(0, 60),
      difficulty: ['easy', 'medium', 'hard'].includes(diff) ? diff : 'medium', q: String(text), code: q.code ? String(q.code) : undefined,
      options, answer: ans, explanation: q.explanation ? String(q.explanation) : ''
    } };
  }
  function parseCSV(text) {
    const rows = []; let row = [], f = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"' && text[i + 1] === '"') { f += '"'; i++; } else if (c === '"') q = false; else f += c; }
      else if (c === '"') q = true;
      else if (c === ',') { row.push(f); f = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(f); rows.push(row); row = []; f = ''; }
      else f += c;
    }
    if (f || row.length) { row.push(f); rows.push(row); }
    const clean = rows.filter(r => r.some(x => x.trim()));
    if (!clean.length) return [];
    const head = clean[0].map(h => h.trim().toLowerCase().replace(/^option\s*/, ''));
    return clean.slice(1).map(r => { const o = { __csv: true }; head.forEach((h, i) => { o[h === 'question' ? 'q' : h] = (r[i] || '').trim(); }); return o; });
  }
  function parseAny(text) {
    const t = text.trim();
    if (!t) return { items: [], errors: ['Nothing to import.'] };
    let raw;
    if (t[0] === '[' || t[0] === '{') {
      try { raw = JSON.parse(t); } catch (e) { return { items: [], errors: ['That JSON did not parse: ' + e.message] }; }
      if (!Array.isArray(raw)) raw = raw.questions || raw.data || [raw];
    } else raw = parseCSV(t);
    const items = [], errors = [];
    raw.forEach((r, i) => { const n = normalize(r, i); if (n.q) items.push(n.q); else errors.push(`Row ${i + 1}: ${n.err}`); });
    return { items, errors };
  }
  async function importText(text, replace) {
    const msg = $('importMsg');
    const { items, errors } = parseAny(text);
    if (!items.length) { msg.className = 'note err'; msg.textContent = errors.slice(0, 4).join(' · ') || 'No valid questions found.'; return; }
    const next = replace ? items : custom.concat(items);
    const res = await send({ type: 'fq:setCustomBank', bank: next });
    if (!res || !res.ok) { msg.className = 'note err'; msg.textContent = (res && res.reason) || 'Import failed.'; return; }
    custom = next;
    if (settings.bankSource === 'builtin') await saveSettings({ bankSource: 'both' });
    msg.className = 'note ok';
    msg.textContent = `Imported ${items.length} question${items.length === 1 ? '' : 's'}${errors.length ? `, skipped ${errors.length} (${errors.slice(0, 2).join('; ')})` : ''}. You now have ${custom.length}.`;
    const keep = msg.outerHTML;
    renderSection('bank'); renderSection('quiz');
    $('importMsg').outerHTML = keep;
  }
  function download(name, text, type = 'application/json') {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function pickFile(accept, cb) {
    const inp = $('fileInput'); inp.accept = accept; inp.value = '';
    inp.onchange = async () => { const f = inp.files[0]; if (f) cb(await f.text(), f.name); };
    inp.click();
  }

  // ---------- events ----------
  document.addEventListener('click', async e => {
    const t = e.target;
    const segBtn = t.closest('.seg button');
    if (segBtn) {
      const g = segBtn.parentElement;
      g.querySelectorAll('button').forEach(b => b.setAttribute('aria-checked', b === segBtn));
      const v = JSON.parse(segBtn.dataset.v);
      if (g.dataset.key === 'bankSource') return saveBy(g.dataset.kind, g.dataset.key, v, ['bank', 'quiz']);
      return saveBy(g.dataset.kind, g.dataset.key, v);
    }
    const chipBtn = t.closest('.chips[data-key] .chip');
    if (chipBtn) {
      const g = chipBtn.parentElement;
      chipBtn.setAttribute('aria-pressed', chipBtn.getAttribute('aria-pressed') !== 'true');
      const vals = [...g.querySelectorAll('.chip[aria-pressed="true"]')].map(b => JSON.parse(b.dataset.v));
      if (g.dataset.key === 'lockTopics' && !vals.length) { chipBtn.setAttribute('aria-pressed', 'true'); return flash('Keep at least one topic', true); }
      const all = g.querySelectorAll('.chip').length;
      return saveSettings({ [g.dataset.key]: g.dataset.key === 'lockTopics' && vals.length === all ? null : vals });
    }
    const th = t.closest('.theme');
    if (th) { document.querySelectorAll('.theme').forEach(b => b.setAttribute('aria-pressed', b === th)); return savePrefs({ theme: th.dataset.theme }); }
    const acc = t.closest('[data-accent]');
    if (acc) { await savePrefs({ accent: acc.dataset.accent }); return renderSection('look'); }
    const open = t.closest('[data-open]');
    if (open) {
      const w = open.dataset.open;
      if (w === 'welcome') return chrome.tabs.create({ url: chrome.runtime.getURL('src/quiz.html?mode=welcome') });
      return send({ type: 'fq:openPractice', query: w === 'practice' ? '' : 'pmode=' + w });
    }
    const star = t.closest('[data-star]');
    if (star) {
      e.preventDefault();
      const id = star.dataset.star;
      starred.has(id) ? starred.delete(id) : starred.add(id);
      star.textContent = starred.has(id) ? '★' : '☆'; star.setAttribute('aria-pressed', starred.has(id));
      return chrome.storage.local.set({ starred: [...starred] });
    }
    const rmSite = t.closest('[data-rm-site]');
    if (rmSite) {
      const id = rmSite.dataset.rmSite, c = settings.customSites.find(x => x.id === id);
      await saveSettings({ customSites: settings.customSites.filter(x => x.id !== id), disabledSites: settings.disabledSites.filter(x => x !== id) }, ['sites']);
      if (c) chrome.permissions.remove({ origins: c.hosts.flatMap(h => [`*://${h}/*`, `*://*.${h}/*`]) }).catch(() => {});
      return;
    }
    const rmAllow = t.closest('[data-rm-allow]');
    if (rmAllow) return saveSettings({ allowList: settings.allowList.filter((_, i) => i !== +rmAllow.dataset.rmAllow) }, ['sites']);
    const preset = t.closest('[data-preset]');
    if (preset) {
      const P = { work: { scheduleOn: true, scheduleDays: [1, 2, 3, 4, 5], scheduleFrom: '09:00', scheduleTo: '18:00' }, study: { scheduleOn: true, scheduleDays: [0, 1, 2, 3, 4, 5, 6], scheduleFrom: '18:00', scheduleTo: '23:00' },
        school: { scheduleOn: true, scheduleDays: [1, 2, 3, 4, 5], scheduleFrom: '07:00', scheduleTo: '21:00' }, always: { scheduleOn: false } }[preset.dataset.preset];
      return saveSettings(P, ['schedule']);
    }
    const tp = t.closest('[data-topics]');
    if (tp) {
      if (tp.dataset.topics === 'none') return flash('Keep at least one topic: tap the ones you want', true);
      return saveSettings({ lockTopics: null }, ['quiz']);
    }

    switch (t.id) {
      case 'siteAdd': return addSite();
      case 'allowAdd': return addAllow();
      case 'testSound': return testSound();
      case 'libMore': libLimit += 40; return renderLib();
      case 'drop': return pickFile('.json,.csv,.txt', text => importText(text, false));
      case 'importAdd': return importText($('pasteBox').value, false);
      case 'importReplace': return importText($('pasteBox').value, true);
      case 'tplJson': return download('focusquest-questions-template.json', JSON.stringify([
        { topic: 'Geography', difficulty: 'easy', q: 'What is the capital of Australia?', options: ['Sydney', 'Canberra', 'Melbourne', 'Perth'], answer: 1, explanation: 'Canberra was purpose-built as the capital in 1913.' },
        { topic: 'JavaScript', difficulty: 'medium', q: 'What does this log?', code: 'console.log(typeof null);', options: ['"null"', '"object"', '"undefined"', 'It throws'], answer: 'B', explanation: 'A long-standing quirk: typeof null is "object".' }
      ], null, 2));
      case 'tplCsv': return download('focusquest-questions-template.csv', 'question,a,b,c,d,answer,explanation,topic,difficulty\n"What is the capital of Australia?",Sydney,Canberra,Melbourne,Perth,B,"Canberra was purpose-built as the capital in 1913.",Geography,easy\n"Which planet is known as the Red Planet?",Venus,Jupiter,Mars,Saturn,C,"Iron oxide dust gives Mars its colour.",Science,easy\n', 'text/csv');
      case 'exportMine': return download('focusquest-my-questions.json', JSON.stringify(custom.map(({ id, ...q }) => q), null, 2));
      case 'clearMine':
        if (!confirm(`Delete all ${custom.length} of your questions?`)) return;
        { const r = await send({ type: 'fq:setCustomBank', bank: [] }); if (r && r.ok) { custom = []; if (settings.bankSource === 'custom') await saveSettings({ bankSource: 'builtin' }); renderSection('bank'); renderSection('quiz'); flash('Deleted'); } else flash((r && r.reason) || 'Could not delete', true); }
        return;
      case 'exportAll': { const b = await send({ type: 'fq:export' }); return download(`focusquest-backup-${FQ_dayKey()}.json`, JSON.stringify(b, null, 2)); }
      case 'importAll': return pickFile('.json', async text => {
        let b; try { b = JSON.parse(text); } catch (_) { return flash('That file is not valid JSON', true); }
        const r = await send({ type: 'fq:import', backup: b });
        if (r && r.ok) { flash('Backup restored ✓'); await loadAll(); } else flash((r && r.reason) || 'Restore failed', true);
      });
      case 'resetProgress':
        if (!confirm('Reset XP, stats, achievements and bookmarks? This cannot be undone.')) return;
        { const r = await send({ type: 'fq:reset', scope: 'progress' }); if (r && r.ok) { flash('Progress reset'); await loadAll(); } else flash((r && r.reason) || 'Could not reset', true); }
        return;
      case 'resetAll':
        if (!confirm('Reset EVERYTHING back to a fresh install? Settings, progress and your questions will be erased.')) return;
        { const r = await send({ type: 'fq:reset', scope: 'all' }); if (r && r.ok) { flash('Everything reset'); await loadAll(); } else flash((r && r.reason) || 'Could not reset', true); }
        return;
      case 'shortcuts': return chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
    }
  });

  document.addEventListener('change', e => {
    const t = e.target;
    if (t.matches('.switch input')) return saveBy(t.dataset.kind, t.dataset.key, t.checked);
    if (t.matches('input[type="range"]')) return saveBy(t.dataset.kind, t.dataset.key, Number(t.value));
    if (t.matches('[data-site]')) {
      const off = new Set(settings.disabledSites);
      t.checked ? off.delete(t.dataset.site) : off.add(t.dataset.site);
      return saveSettings({ disabledSites: [...off] });
    }
    if (t.matches('[data-time]')) return saveSettings({ [t.dataset.time]: t.value });
    if (t.matches('[data-text]')) return saveSettings({ [t.dataset.text]: t.value.trim() });
    if (t.id === 'accentPick') return savePrefs({ accent: t.value }).then(() => renderSection('look'));
    if (t.id === 'libTopic') { libTopic = t.value; libLimit = 40; return renderLib(); }
  });
  document.addEventListener('input', e => {
    const t = e.target;
    if (t.matches('input[type="range"]')) {
      t.nextElementSibling.textContent = t.value + (t.dataset.unit || '');
      if (t.dataset.key === 'questionsPerQuiz' || t.dataset.key === 'passPercent') { settings = { ...settings, [t.dataset.key]: +t.value }; paintDerived(); }
    }
    if (t.id === 'libSearch') { libQuery = t.value; libLimit = 40; renderLib(); }
  });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'siteInput') addSite();
    if (e.target.id === 'allowInput') addAllow();
    if (e.target.id === 'drop') $('drop').click();
  });
  document.addEventListener('dragover', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) { e.preventDefault(); d.classList.add('over'); } });
  document.addEventListener('dragleave', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) d.classList.remove('over'); });
  document.addEventListener('drop', async e => {
    const d = e.target.closest && e.target.closest('#drop'); if (!d) return;
    e.preventDefault(); d.classList.remove('over');
    const f = e.dataTransfer.files[0]; if (f) importText(await f.text(), false);
  });

  function addSite() {
    const inp = $('siteInput'), msg = $('siteMsg');
    const host = FQ_normalizeHost(inp.value);
    msg.className = 'note err';
    if (!host) { msg.textContent = 'That does not look like a website address.'; return; }
    if (FQ_siteForHost(host)) { msg.textContent = `${host} is already built in. Tick it above.`; return; }
    if (settings.customSites.some(c => c.hosts.includes(host))) { msg.textContent = `${host} is already on your list.`; return; }
    // permissions.request must run straight from the click, before any other await.
    chrome.permissions.request({ origins: [`*://${host}/*`, `*://*.${host}/*`] }).then(async granted => {
      if (!granted) { msg.textContent = 'Chrome permission was not granted, so FocusQuest cannot see that site.'; return; }
      await saveSettings({ customSites: settings.customSites.concat({ name: host, emoji: '🌐', hosts: [host] }) }, ['sites']);
      const m = $('siteMsg'); if (m) { m.className = 'note ok'; m.textContent = `Now tracking ${host}. Open tabs pick it up right away.`; }
    }).catch(err => { msg.textContent = String(err.message || err); });
  }
  function addAllow() {
    const v = $('allowInput').value.trim();
    if (!v) return;
    if (settings.allowList.includes(v)) return flash('Already allowed', true);
    saveSettings({ allowList: settings.allowList.concat(v) }, ['sites']);
  }
  function testSound() {
    if (prefs.sound === false) return flash('Sound is off', true);
    const c = new AudioContext(), vol = (prefs.volume ?? 70) / 100;
    [523, 659, 784, 1047].forEach((f, i) => {
      const o = c.createOscillator(), g = c.createGain();
      o.type = prefs.soundPack === 'retro' ? 'square' : prefs.soundPack === 'soft' ? 'sine' : 'triangle';
      const v = .14 * vol * (prefs.soundPack === 'retro' ? .4 : prefs.soundPack === 'soft' ? .6 : 1);
      o.frequency.value = f * (prefs.soundPack === 'soft' ? .8 : 1);
      g.gain.setValueAtTime(.0001, c.currentTime + i * .09); g.gain.exponentialRampToValueAtTime(Math.max(.0002, v), c.currentTime + i * .09 + .02);
      g.gain.exponentialRampToValueAtTime(.0001, c.currentTime + i * .09 + .35);
      o.connect(g).connect(c.destination); o.start(c.currentTime + i * .09); o.stop(c.currentTime + i * .09 + .4);
    });
  }

  // ---------- nav ----------
  function buildNav() {
    $('nav').innerHTML = SECTIONS.map(s => `<a href="#${s.id}" data-nav="${s.id}"><span class="ne">${s.e}</span>${s.t}</a>`).join('');
    const links = [...document.querySelectorAll('[data-nav]')];
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => { if (en.isIntersecting) links.forEach(a => a.classList.toggle('on', a.dataset.nav === en.target.id)); });
    }, { rootMargin: '-20% 0px -70% 0px' });
    document.querySelectorAll('section.sec').forEach(s => io.observe(s));
  }

  // ---------- boot ----------
  async function loadAll() {
    const [st, local] = await Promise.all([send({ type: 'fq:state' }), chrome.storage.local.get(['prefs', 'qstats', 'starred', 'customBank'])]);
    pub = st || {}; settings = { ...FQ_DEFAULTS, ...(pub.settings || {}) }; stats = pub.stats || {};
    prefs = { ...FQ_PREFS, ...(local.prefs || {}) }; qstats = local.qstats || {}; starred = new Set(local.starred || []);
    custom = (local.customBank || []).map((q, i) => ({ ...q, id: q.id || `u-${i}` }));
    if (!builtin.length) { try { builtin = await (await fetch(chrome.runtime.getURL('data/questions.json'))).json(); } catch (_) { builtin = []; } }
    frozen = !!pub.locked;
    renderAll();
    buildNav();
    if (location.hash) document.getElementById(location.hash.slice(1))?.scrollIntoView();
  }
  $('homeLink').href = FQ_HOME;
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.timer) { const was = frozen; frozen = !!(ch.timer.newValue && ch.timer.newValue.locked); if (was !== frozen) { $('lockbar').hidden = !frozen; document.querySelectorAll('section.sec').forEach(s => s.classList.toggle('frozen', frozen)); } }
    if (ch.prefs) { prefs = { ...FQ_PREFS, ...(ch.prefs.newValue || {}) }; if (!document.activeElement || !document.activeElement.closest('[data-sec="look"]')) renderSection('look'); }
  });
  loadAll();
})();
