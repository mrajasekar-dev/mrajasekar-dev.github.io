// FocusQuest content script: reports watch time and drops the quiz wall when time is up.
(async () => {
  if (window.top !== window || window.__focusQuest) return;
  window.__focusQuest = true;

  const HEARTBEAT_MS = 5000;
  let site = FQ_siteForHost(location.hostname);
  let prefs = {};
  let settings = FQ_DEFAULTS;
  let isLocked = false;
  let host = null;        // overlay host element
  let pauseTimer = null;
  let resumeList = [];    // media that was playing when we locked
  let beatTimer = null;
  let dead = false;       // extension reloaded/removed => stop quietly

  const send = msg => new Promise(resolve => {
    try {
      chrome.runtime.sendMessage(msg, res => {
        if (chrome.runtime.lastError) return resolve(null);
        resolve(res);
      });
    } catch (e) {
      dead = true; // "Extension context invalidated"
      resolve(null);
    }
  });

  // Custom sites live in settings; built-ins resolve synchronously above.
  if (!site) {
    try {
      const { settings: s } = await chrome.storage.local.get('settings');
      site = FQ_siteForHost(location.hostname, (s && s.customSites) || []);
    } catch (_) {}
  }
  if (!site) return;

  const media = () => Array.from(document.querySelectorAll('video, audio'));
  const mediaPlaying = () => media().some(m => !m.paused && !m.ended && m.readyState > 2 && !m.muted && m.volume > 0);

  // ---------- heartbeat ----------
  async function beat() {
    if (dead) { clearInterval(beatTimer); return; }
    const visible = document.visibilityState === 'visible';
    const playing = mediaPlaying();
    if (!visible && !playing && !isLocked) return;
    const res = await send({ type: 'fq:heartbeat', siteId: site.id, url: location.href, visible, mediaPlaying: playing });
    if (!res) return;
    if (res.settings) settings = res.settings;
    if (!res.tracked) { if (isLocked) unlock(); return; }
    if (res.locked) lock();
    else if (res.hold) { /* passed — wall stays until the results screen is dismissed */ }
    else {
      if (isLocked) unlock();
      if (res.warn) toast(res.warn);
    }
  }

  // ---------- lock overlay ----------
  function lock() {
    if (isLocked && host && host.isConnected) return;
    isLocked = true;
    if (!resumeList.length) resumeList = media().filter(m => !m.paused && !m.ended);
    pauseAll();
    clearInterval(pauseTimer);
    pauseTimer = setInterval(pauseAll, 400);
    mount();
  }

  function pauseAll() {
    for (const m of media()) { try { if (!m.paused) m.pause(); } catch (_) {} }
    if (host && !host.isConnected) mount(); // someone removed the wall — put it back
  }

  function themeColors() {
    const t = FQ_theme.resolve(prefs);
    return { bg: t.bg, bg2: t.bg2, a: prefs.accent || t.aurora[0], g: [prefs.accent || t.grad[0], prefs.accent || t.grad[1], t.grad[2]] };
  }

  function mount() {
    const root = document.documentElement;
    if (!root) { requestAnimationFrame(mount); return; }
    if (!host) {
      const c = themeColors();
      host = document.createElement('focusquest-wall');
      const shadow = host.attachShadow({ mode: 'closed' });
      shadow.innerHTML = `
        <style>
          :host { all: initial; position: fixed !important; inset: 0 !important; z-index: 2147483647 !important; display: block !important; }
          .bg { position: absolute; inset: 0; background: radial-gradient(1200px 700px at 20% 10%, color-mix(in srgb, ${c.a} 35%, ${c.bg}) 0%, ${c.bg} 55%, ${c.bg2} 100%); animation: in .45s ease both; }
          iframe { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; background: transparent; animation: in .6s .1s ease both; }
          @keyframes in { from { opacity: 0; transform: scale(1.02); } to { opacity: 1; transform: none; } }
        </style>
        <div class="bg"></div>
        <iframe allow="autoplay; clipboard-write" title="FocusQuest quiz"></iframe>`;
      const frame = shadow.querySelector('iframe');
      frame.src = chrome.runtime.getURL('src/quiz.html?mode=lock&site=' + encodeURIComponent(site.id));
      frame.addEventListener('load', () => { try { frame.focus(); } catch (_) {} });
    }
    root.appendChild(host);
    root.style.setProperty('overflow', 'hidden', 'important');
  }

  function unlock() {
    if (!isLocked) return;
    isLocked = false;
    clearInterval(pauseTimer);
    if (host) {
      host.style.transition = 'opacity .5s ease';
      host.style.opacity = '0';
      const h = host; host = null;
      setTimeout(() => h.remove(), 520);
    }
    document.documentElement.style.removeProperty('overflow');
    const toResume = resumeList; resumeList = [];
    for (const m of toResume) { try { m.play().catch(() => {}); } catch (_) {} }
  }

  // ---------- friendly warning toast ----------
  function toast(minutes) {
    const c = themeColors();
    const pos = settings.toastPosition || 'br';
    const v = pos[0] === 't' ? 'top' : 'bottom', h = pos[1] === 'l' ? 'left' : 'right';
    const el = document.createElement('focusquest-toast');
    const sh = el.attachShadow({ mode: 'closed' });
    const who = settings.displayName ? `${settings.displayName}, ` : '';
    const msg = minutes === 1
      ? `${who}last minute! Quiz time is up next 🧠`
      : `${who}${minutes} minutes of scroll time left ⏳`;
    sh.innerHTML = `
      <style>
        :host { all: initial; position: fixed; z-index: 2147483646; ${v}: 24px; ${h}: 24px; }
        .t { font: 600 14px/1.35 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, Roboto, sans-serif; color: #fff;
             display: flex; gap: 12px; align-items: center; padding: 14px 18px; border-radius: 16px; max-width: 340px;
             background: linear-gradient(135deg, ${c.g[0]}, ${c.g[1]} 55%, ${c.g[2]});
             box-shadow: 0 18px 50px -12px rgba(0,0,0,.45), 0 0 0 1px rgba(255,255,255,.15) inset;
             animation: pop .5s cubic-bezier(.2,1.4,.4,1) both, out .4s ease 5.6s forwards; }
        .i { font-size: 22px; }
        small { display: block; font-weight: 500; opacity: .85; font-size: 12px; margin-top: 2px; }
        @keyframes pop { from { transform: translateY(${v === 'top' ? '-' : ''}20px) scale(.9); opacity: 0; } to { transform: none; opacity: 1; } }
        @keyframes out { to { transform: translateY(${v === 'top' ? '-' : ''}10px); opacity: 0; } }
      </style>
      <div class="t"><span class="i">🎯</span><div></div></div>`;
    const body = sh.querySelector('.t div');
    body.textContent = msg;
    const small = document.createElement('small');
    small.textContent = 'FocusQuest · quiz incoming';
    body.appendChild(small);
    (document.body || document.documentElement).appendChild(el);
    setTimeout(() => el.remove(), 6200);
  }

  // ---------- wiring ----------
  chrome.runtime.onMessage.addListener(msg => {
    if (!msg) return;
    if (msg.type === 'fq:lock') send({ type: 'fq:check', siteId: site.id, url: location.href }).then(r => { if (r && r.lock) lock(); });
    if (msg.type === 'fq:unlock') unlock();
    if (msg.type === 'fq:settings') beat();
  });
  try {
    chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.prefs) prefs = ch.prefs.newValue || {}; });
  } catch (_) {}

  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') beat(); });

  // Ask immediately on load so a locked site never flashes content.
  const first = await send({ type: 'fq:check', siteId: site.id, url: location.href });
  if (first) {
    prefs = first.prefs || {};
    settings = first.settings || settings;
    if (first.lock) lock();
  }
  beatTimer = setInterval(beat, HEARTBEAT_MS);
})();
