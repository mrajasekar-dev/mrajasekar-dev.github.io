// FocusQuest popup: countdown ring, today's numbers and a quick theme switcher.
(() => {
  const $ = id => document.getElementById(id);
  const C = 2 * Math.PI * 50;

  const fmt = ms => {
    const s = Math.max(0, Math.round(ms / 1000));
    return s > 3600 ? `${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}` : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  };
  const mins = ms => {
    const m = Math.round(ms / 60000);
    return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`;
  };

  async function refresh() {
    const state = await chrome.runtime.sendMessage({ type: 'fq:state' });
    if (!state) return;
    const { remainingMs, limitMs, locked, stats = {}, settings, emergencyUntil, inSchedule } = state;
    const now = Date.now();
    const ring = $('ring');
    ring.style.strokeDasharray = C;
    ring.classList.remove('low', 'out', 'sos', 'off');

    if (!inSchedule) {
      ring.style.strokeDashoffset = 0; ring.classList.add('off');
      $('remain').textContent = '😴'; $('remainSub').textContent = 'outside your schedule';
      $('status').textContent = 'FocusQuest is resting. Nothing counts until your focus hours start.';
    } else if (emergencyUntil) {
      ring.style.strokeDashoffset = 0; ring.classList.add('sos');
      $('remain').textContent = fmt(emergencyUntil - now); $('remainSub').textContent = 'emergency pass';
      $('status').textContent = 'The quiz is back when the pass runs out 🚨';
    } else if (locked) {
      ring.style.strokeDashoffset = C; ring.classList.add('out');
      $('remain').textContent = '🔒'; $('remainSub').textContent = 'quiz due';
      $('status').textContent = 'Social time is used up. Open any tracked site to take the quiz.';
    } else {
      ring.style.strokeDashoffset = C * (1 - remainingMs / limitMs);
      if (remainingMs < 5 * 60000) ring.classList.add('low');
      $('remain').textContent = fmt(remainingMs);
      $('remainSub').textContent = `of ${Math.round(limitMs / 60000)} min left`;
      $('status').textContent = remainingMs < 5 * 60000 ? 'Nearly out. A quiz is coming up ⏳'
        : settings.displayName ? `Hi ${settings.displayName}! The timer only runs on tracked sites.` : 'The timer only runs while a tracked site is open and active.';
    }

    const dk = FQ_dayKey();
    $('today').textContent = mins((stats.byDay || {})[dk] || 0);
    $('passed').textContent = stats.quizzesPassed || 0;
    $('acc').textContent = stats.answered ? Math.round(stats.correct / stats.answered * 100) + '%' : '—';
    $('dayStreak').textContent = FQ_dayStreak(stats.answeredByDay, settings.dailyGoal);

    const goal = settings.dailyGoal, done = (stats.answeredByDay || {})[dk] || 0;
    $('goalName').parentElement.hidden = !goal; $('goalBar').parentElement.hidden = !goal;
    $('goalText').textContent = `${Math.min(done, goal)}/${goal}${done >= goal && goal ? ' ✓' : ''}`;
    $('goalBar').style.width = goal ? Math.min(100, done / goal * 100) + '%' : 0;

    const xp = stats.xp || 0;
    let cur = FQ_LEVELS[0], nxt = null;
    FQ_LEVELS.forEach((l, i) => { if (xp >= l[0]) { cur = l; nxt = FQ_LEVELS[i + 1] || null; } });
    $('lvlName').textContent = `${cur[2]} ${cur[1]}`;
    $('lvlXp').textContent = `${xp.toLocaleString()} XP`;
    $('lvlBar').style.width = nxt ? `${Math.round((xp - cur[0]) / (nxt[0] - cur[0]) * 100)}%` : '100%';
    $('lvlNext').textContent = nxt ? `${(nxt[0] - xp).toLocaleString()} XP to ${nxt[2]} ${nxt[1]}` : 'Max rank. You are the legend.';

    const days = [];
    for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
    const vals = days.map(d => (stats.byDay || {})[FQ_dayKey(d.getTime())] || 0);
    const max = Math.max(...vals, 60000);
    $('week').innerHTML = days.map((d, i) => `
      <div class="day${i === 6 ? ' today' : ''}" title="${mins(vals[i])}">
        <i style="height:${Math.max(4, vals[i] / max * 56)}px"></i>
        <span>${'SMTWTFS'[d.getDay()]}</span>
      </div>`).join('');
  }

  // ---------- quick theme switcher ----------
  async function paintSwatches() {
    const { prefs = {} } = await chrome.storage.local.get('prefs');
    const cur = prefs.theme || 'aurora';
    const list = [...FQ_THEMES, FQ_THEME_AUTO];
    $('swatches').innerHTML = list.map(t => {
      const bgc = t.id === 'auto' ? 'linear-gradient(135deg,#0b0a1a 50%,#f6f3ec 50%)' : `linear-gradient(135deg, ${t.bg} 45%, ${t.accent} 45%, ${t.grad[2]})`;
      return `<button class="sw" type="button" data-id="${t.id}" title="${t.name}" aria-label="${t.name} theme" aria-pressed="${t.id === cur}" style="background:${bgc}">${t.id === 'auto' ? '<span>🌓</span>' : ''}</button>`;
    }).join('');
  }
  $('swatches').addEventListener('click', async e => {
    const b = e.target.closest('.sw'); if (!b) return;
    const { prefs = {} } = await chrome.storage.local.get('prefs');
    await chrome.storage.local.set({ prefs: { ...prefs, theme: b.dataset.id, accent: '' } });
    paintSwatches();
  });
  $('themeToggle').addEventListener('click', () => {
    const open = $('swatches').hidden;
    $('swatches').hidden = !open;
    $('themeToggle').setAttribute('aria-expanded', open);
    if (open) paintSwatches();
  });

  const openOptions = () => { chrome.runtime.openOptionsPage(); window.close(); };
  $('optionsBtn').addEventListener('click', openOptions);
  $('options2').addEventListener('click', openOptions);
  $('practice').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'fq:openPractice' });
    window.close();
  });
  $('homeLink').href = FQ_HOME;
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;

  refresh();
  setInterval(refresh, 1000);
})();
