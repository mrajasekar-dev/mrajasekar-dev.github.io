// FocusQuest themes. Each theme is a set of design tokens applied as CSS custom properties.
// `tint` is the RGB used for translucent surfaces (white on dark themes, ink on light ones).
(function (g) {
  const T = (id, name, emoji, dark, c) => ({ id, name, emoji, dark, ...c });
  const THEMES = [
    T('aurora', 'Aurora', '🌌', true, { bg: '#0b0a1a', bg2: '#120f2a', text: '#f4f2ff', text2: '#c3bedf', text3: '#8f89b3', accent: '#7c5cff', accent2: '#a58bff', good: '#2ee6a6', bad: '#ff4d6d', warn: '#ffb020', info: '#38bdf8', aurora: ['#5b3cff', '#ff3d7f', '#10c9a0'], grad: ['#8a6bff', '#6a45ff', '#ff4d8d'], code: '#0a0918' }),
    T('midnight', 'Midnight', '🌃', true, { bg: '#060b18', bg2: '#0b1426', text: '#eaf2ff', text2: '#b4c3de', text3: '#7688a8', accent: '#3b82f6', accent2: '#7cb4ff', good: '#34d399', bad: '#fb7185', warn: '#fbbf24', info: '#22d3ee', aurora: ['#1d4ed8', '#0891b2', '#6d28d9'], grad: ['#60a5fa', '#2563eb', '#06b6d4'], code: '#050914' }),
    T('sunset', 'Sunset', '🌇', true, { bg: '#1a0b12', bg2: '#24101a', text: '#fff1ea', text2: '#f0c6b8', text3: '#b58a82', accent: '#ff6b4a', accent2: '#ffa07a', good: '#4ade80', bad: '#ff3d6e', warn: '#ffd166', info: '#7dd3fc', aurora: ['#ff4d6d', '#ff9f1c', '#9d4edd'], grad: ['#ffb347', '#ff6b4a', '#e0457b'], code: '#140810' }),
    T('forest', 'Forest', '🌲', true, { bg: '#07140e', bg2: '#0c1f16', text: '#eafff3', text2: '#b5d9c4', text3: '#7ca28c', accent: '#22c55e', accent2: '#86efac', good: '#4ade80', bad: '#f87171', warn: '#facc15', info: '#5eead4', aurora: ['#15803d', '#0d9488', '#65a30d'], grad: ['#4ade80', '#16a34a', '#0d9488'], code: '#051009' }),
    T('ocean', 'Deep Sea', '🐋', true, { bg: '#03161d', bg2: '#06222b', text: '#e6fbff', text2: '#a9d6e0', text3: '#6f9ca8', accent: '#14b8a6', accent2: '#5eead4', good: '#34d399', bad: '#fb7185', warn: '#fcd34d', info: '#38bdf8', aurora: ['#0e7490', '#14b8a6', '#1e40af'], grad: ['#2dd4bf', '#0ea5e9', '#6366f1'], code: '#021015' }),
    T('cyber', 'Cyberpunk', '🦾', true, { bg: '#07030f', bg2: '#0e0620', text: '#f5f0ff', text2: '#cbbef0', text3: '#8a7bb5', accent: '#ff2bd6', accent2: '#ff7ae8', good: '#00ffa3', bad: '#ff3860', warn: '#fff04d', info: '#00e5ff', aurora: ['#ff00c8', '#00e5ff', '#7a00ff'], grad: ['#ff2bd6', '#a100ff', '#00e5ff'], code: '#05020c' }),
    T('dracula', 'Dracula', '🧛', true, { bg: '#1e1f29', bg2: '#282a36', text: '#f8f8f2', text2: '#d6d6e6', text3: '#8a8fb0', accent: '#bd93f9', accent2: '#d6b8ff', good: '#50fa7b', bad: '#ff5555', warn: '#f1fa8c', info: '#8be9fd', aurora: ['#bd93f9', '#ff79c6', '#8be9fd'], grad: ['#ff79c6', '#bd93f9', '#8be9fd'], code: '#191a21' }),
    T('nord', 'Nord', '🏔️', true, { bg: '#242933', bg2: '#2e3440', text: '#eceff4', text2: '#d8dee9', text3: '#8e99ad', accent: '#88c0d0', accent2: '#a3d4e0', good: '#a3be8c', bad: '#bf616a', warn: '#ebcb8b', info: '#81a1c1', aurora: ['#5e81ac', '#88c0d0', '#b48ead'], grad: ['#8fbcbb', '#5e81ac', '#b48ead'], code: '#1f232b', onAccent: '#1b1f27' }),
    T('mocha', 'Mocha', '☕', true, { bg: '#1a1410', bg2: '#241b15', text: '#f7eee6', text2: '#d9c4b3', text3: '#a08878', accent: '#d4a373', accent2: '#e9c46a', good: '#8ab17d', bad: '#e76f51', warn: '#f4a261', info: '#7fb3d5', aurora: ['#9c6644', '#e76f51', '#bc6c25'], grad: ['#e9c46a', '#d4a373', '#e76f51'], code: '#130e0b', onAccent: '#1a1410' }),
    T('terminal', 'Terminal', '💻', true, { bg: '#020a03', bg2: '#041206', text: '#c8ffcf', text2: '#8fe39c', text3: '#4f9a5b', accent: '#22ff66', accent2: '#7dffa3', good: '#22ff66', bad: '#ff5f56', warn: '#ffd75f', info: '#5fd7ff', aurora: ['#0f5a1f', '#136b2a', '#0a3d15'], grad: ['#3dff7a', '#12b848', '#0a8f3a'], code: '#010601', font: 'mono', onAccent: '#021204' }),
    T('paper', 'Paper', '📜', false, { bg: '#f6f3ec', bg2: '#efe9dd', text: '#1f1b16', text2: '#4a4238', text3: '#857a6c', accent: '#d9480f', accent2: '#f08c4a', good: '#2f9e44', bad: '#e03131', warn: '#e8890c', info: '#1c7ed6', aurora: ['#ffd8a8', '#ffc9c9', '#d3f9d8'], grad: ['#f76707', '#d9480f', '#c2255c'], code: '#1f1b2e', tint: '60,40,20' }),
    T('sky', 'Sky', '☁️', false, { bg: '#f3f8ff', bg2: '#e6f0ff', text: '#0b1b33', text2: '#33496b', text3: '#6b7f9e', accent: '#0b72e7', accent2: '#4c9bf5', good: '#0f9d58', bad: '#e5484d', warn: '#d97706', info: '#0891b2', aurora: ['#bfdbfe', '#c7d2fe', '#a5f3fc'], grad: ['#38bdf8', '#0b72e7', '#6366f1'], code: '#0f172a', tint: '20,50,110' }),
    T('sakura', 'Sakura', '🌸', false, { bg: '#fff5f8', bg2: '#ffe8ef', text: '#3a1426', text2: '#6e3a52', text3: '#a67a8e', accent: '#e64980', accent2: '#f783ac', good: '#20a36b', bad: '#e03131', warn: '#e67700', info: '#7048e8', aurora: ['#ffc2d9', '#e5dbff', '#ffe3e3'], grad: ['#f783ac', '#e64980', '#9c36b5'], code: '#2b1020', tint: '120,30,70' }),
    T('solar', 'Solarized', '🌞', false, { bg: '#fdf6e3', bg2: '#eee8d5', text: '#073642', text2: '#405a60', text3: '#7b8b8d', accent: '#268bd2', accent2: '#6c71c4', good: '#859900', bad: '#dc322f', warn: '#b58900', info: '#2aa198', aurora: ['#eee8d5', '#fce8b2', '#d9ecf2'], grad: ['#2aa198', '#268bd2', '#6c71c4'], code: '#002b36', tint: '7,54,66' }),
    T('mono', 'Contrast', '◐', false, { bg: '#ffffff', bg2: '#f2f2f2', text: '#000000', text2: '#1a1a1a', text3: '#4d4d4d', accent: '#000000', accent2: '#333333', good: '#006d32', bad: '#c00018', warn: '#8a5a00', info: '#0040a0', aurora: ['#eeeeee', '#e5e5e5', '#f0f0f0'], grad: ['#222222', '#000000', '#333333'], code: '#111111', tint: '0,0,0' })
  ];
  const AUTO = { id: 'auto', name: 'Auto', emoji: '🌓' };

  const FONTS = {
    rounded: { name: 'Rounded', stack: 'ui-rounded, "SF Pro Rounded", -apple-system, BlinkMacSystemFont, "Segoe UI Variable Display", "Segoe UI", Inter, Roboto, system-ui, sans-serif' },
    system: { name: 'System', stack: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif' },
    serif: { name: 'Serif', stack: 'ui-serif, "New York", "Iowan Old Style", Georgia, Cambria, "Times New Roman", serif' },
    mono: { name: 'Mono', stack: 'ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace' },
    readable: { name: 'Readable', stack: 'Verdana, "Atkinson Hyperlegible", Tahoma, "Trebuchet MS", sans-serif' }
  };
  const RADII = { sharp: .3, round: 1, pill: 1.5 };

  const byId = id => THEMES.find(t => t.id === id) || THEMES[0];
  function resolve(prefs) {
    const p = prefs || {};
    let id = p.theme || 'aurora';
    if (id === 'auto') id = (g.matchMedia && g.matchMedia('(prefers-color-scheme: light)').matches) ? 'paper' : 'aurora';
    return byId(id);
  }

  // Tokens for one theme (+ optional custom accent).
  function tokens(theme, accent) {
    const t = theme;
    const a = accent || t.accent;
    const mixWith = t.dark ? '#ffffff' : '#000000';
    return {
      '--bg': t.bg, '--bg-2': t.bg2, '--text': t.text, '--text-2': t.text2, '--text-3': t.text3,
      '--accent': a, '--accent-2': accent ? `color-mix(in srgb, ${a} 62%, ${mixWith})` : t.accent2,
      '--good': t.good, '--bad': t.bad, '--warn': t.warn, '--info': t.info,
      '--a1': accent ? a : t.aurora[0], '--a2': t.aurora[1], '--a3': t.aurora[2],
      '--g1': accent ? `color-mix(in srgb, ${a} 70%, #ffffff)` : t.grad[0], '--g2': accent ? a : t.grad[1], '--g3': accent ? `color-mix(in srgb, ${a} 55%, ${t.bad})` : t.grad[2],
      '--code-bg': t.code, '--tint': t.tint || '255,255,255', '--on-accent': accent ? '#ffffff' : (t.onAccent || '#ffffff')
    };
  }

  function apply(prefs, root) {
    const el = root || g.document.documentElement;
    const p = { ...(g.FQ_PREFS || {}), ...(prefs || {}) };
    const theme = resolve(p);
    const tk = tokens(theme, p.accent);
    for (const k in tk) el.style.setProperty(k, tk[k]);
    const fontId = p.font === 'theme' || !p.font ? (theme.font || 'rounded') : p.font;
    el.style.setProperty('--font', (FONTS[fontId] || FONTS.rounded).stack);
    el.style.setProperty('--rk', RADII[p.radius] ?? 1);
    el.style.setProperty('--zoom', String((Number(p.scale) || 100) / 100));
    el.style.colorScheme = theme.dark ? 'dark' : 'light';
    el.dataset.mode = theme.dark ? 'dark' : 'light';
    el.dataset.theme = theme.id;
    el.dataset.motion = p.motion || 'full';
    el.dataset.bg = p.background || 'aurora';
    return theme;
  }

  // Apply stored prefs now and whenever they change (in any page).
  function boot(onChange) {
    const run = prefs => { const t = apply(prefs); if (onChange) onChange(prefs, t); };
    const hasExt = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
    if (hasExt) {
      chrome.storage.local.get('prefs').then(({ prefs }) => run(prefs || {}));
      chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.prefs) run(ch.prefs.newValue || {}); });
    } else {
      let prefs = {};
      try { prefs = (JSON.parse(localStorage.fq || '{}').prefs) || {}; } catch (_) {}
      run(prefs);
    }
    if (g.matchMedia) g.matchMedia('(prefers-color-scheme: light)').addEventListener('change', async () => {
      const { prefs } = hasExt ? await chrome.storage.local.get('prefs') : { prefs: {} };
      if ((prefs || {}).theme === 'auto') run(prefs);
    });
  }

  Object.assign(g, { FQ_THEMES: THEMES, FQ_THEME_AUTO: AUTO, FQ_FONTS: FONTS, FQ_theme: { apply, boot, resolve, tokens, byId } });
})(typeof globalThis !== 'undefined' ? globalThis : self);
